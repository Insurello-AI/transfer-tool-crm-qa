(function () {
  if (globalThis.__crmProtectorPortalContentLoaded) return;
  globalThis.__crmProtectorPortalContentLoaded = true;

  const contracts = globalThis.__crmProtectorContracts;
  let busy = false;
  let lastCompletedToken = null;
  let timer = null;
  let overlay = null;
  let passiveQaEnabled = false;
  let passiveQaRunId = null;
  let passiveQaCurrentPath = null;
  let portalReadinessWait = null;
  let automationPaused = false;
  let pauseToggleBusy = false;
  let activeRunId = null;
  let pauseSource = null;
  let pauseReason = null;
  let pauseNote = null;
  const PORTAL_READINESS_TIMEOUT_MS = 3000;

  function normalize(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLocaleLowerCase("sv-SE");
  }

  function assertAutomationRunning() {
    if (automationPaused) throw new Error("AUTOMATION_PAUSED");
  }

  function ensureOverlay() {
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "crm-protector-status";
      overlay.setAttribute("role", "status");
      overlay.setAttribute("aria-live", "polite");
      Object.assign(overlay.style, {
        position: "fixed",
        right: "12px",
        top: "12px",
        zIndex: "2147483647",
        width: "360px",
        maxWidth: "calc(100vw - 24px)",
        maxHeight: "44vh",
        overflow: "hidden",
        boxSizing: "border-box",
        padding: "10px 11px",
        border: "1px solid #d1d5db",
        borderLeft: "4px solid #d97706",
        borderRadius: "10px",
        boxShadow: "0 8px 24px rgba(15,23,42,.16)",
        background: "#fff",
        color: "#111827",
        font: "12.5px/1.35 system-ui, -apple-system, sans-serif"
      });
      document.documentElement.appendChild(overlay);
    }
    return overlay;
  }

  function pauseLabel() {
    return automationPaused ? "Fortsätt" : "Pausa";
  }

  function pausedMessage() {
    return "Automation pausad. Du kan backa, ändra och navigera fritt.";
  }

  async function toggleAutomationPause() {
    if (pauseToggleBusy) return;
    pauseToggleBusy = true;
    const requestedPaused = !automationPaused;

    // Stop locally immediately. The background state below makes the pause
    // survive route changes and reloads.
    if (requestedPaused) automationPaused = true;
    showMessage(requestedPaused ? "Pausar automation…" : "Återupptar automation…", "warn", { showControl: true });

    try {
      const response = await chrome.runtime.sendMessage({
        type: "PROTECTOR_PORTAL_SET_PAUSED",
        payload: {
          paused: requestedPaused,
          source: "USER",
          path: contracts?.normalizePath?.(location.href) || location.pathname
        }
      });
      if (!response?.ok) throw new Error(response?.message || "PAUSE_STATE_SYNC_FAILED");

      activeRunId = response.runId || activeRunId;
      automationPaused = response.automationPaused === true;
      pauseSource = automationPaused ? (response.pauseSource || "USER") : null;
      pauseReason = automationPaused ? (response.pauseReason || null) : null;
      pauseNote = automationPaused ? (response.pauseNote || null) : null;
      portalReadinessWait = null;

      if (automationPaused) {
        showMessage(pausedMessage(), "warn", { showControl: true });
      } else {
        lastCompletedToken = null;
        showMessage("Kör automatiskt.", "running", { showControl: true });
        scheduleReconcile();
      }
    } catch (error) {
      // Fail closed. If pause state cannot be synchronized, never resume local
      // automation on our own.
      automationPaused = true;
      pauseSource = "USER";
      pauseReason = "PAUSE_STATE_SYNC_FAILED";
      pauseNote = null;
      showMessage("Kunde inte synka pausläget. Automation hålls pausad i den här fliken.", "error", { showControl: true });
    } finally {
      pauseToggleBusy = false;
      if (overlay) {
        const button = overlay.querySelector("button[data-protector-pause-control='true']");
        if (button instanceof HTMLButtonElement) button.disabled = false;
      }
    }
  }

  function showMessage(message, level, options = {}) {
    const root = ensureOverlay();
    const hasContext = Boolean(options.context && Array.isArray(options.context.sections) && options.context.sections.length > 0);
    const palette = level === "error"
      ? { accent: "#b91c1c", border: "#fecaca", background: "#fffafa", pillBackground: "#fee2e2", pillColor: "#991b1b" }
      : level === "success"
        ? { accent: "#15803d", border: "#bbf7d0", background: "#fff", pillBackground: "#dcfce7", pillColor: "#166534" }
        : level === "running"
          ? { accent: "#475569", border: "#d1d5db", background: "#fff", pillBackground: "#f1f5f9", pillColor: "#475569" }
          : { accent: "#d97706", border: "#fde68a", background: "#fff", pillBackground: "#fef3c7", pillColor: "#92400e" };
    root.style.background = palette.background;
    root.style.borderColor = palette.border;
    root.style.borderLeftColor = palette.accent;
    root.style.color = "#111827";
    root.setAttribute("role", level === "error" ? "alert" : "status");
    root.setAttribute("aria-live", level === "error" ? "assertive" : "polite");
    root.replaceChildren();

    const row = document.createElement("div");
    Object.assign(row.style, { display: "flex", alignItems: "flex-start", gap: "8px" });

    const copy = document.createElement("div");
    copy.style.minWidth = "0";
    copy.style.flex = "1 1 auto";

    const heading = document.createElement("div");
    Object.assign(heading.style, { display: "flex", alignItems: "center", gap: "7px", minWidth: "0", marginBottom: "2px" });

    const title = document.createElement("div");
    title.textContent = "Protector";
    Object.assign(title.style, { fontWeight: "700", fontSize: "12.5px", color: "#111827" });

    const status = document.createElement("span");
    status.textContent = hasContext
      ? "Manuellt val"
      : level === "error"
        ? "Stoppad"
        : level === "success"
          ? "Klart"
          : level === "running"
            ? "Automatik"
            : "Kontroll";
    Object.assign(status.style, {
      display: "inline-flex",
      alignItems: "center",
      flex: "0 0 auto",
      padding: "2px 6px",
      borderRadius: "999px",
      background: palette.pillBackground,
      color: palette.pillColor,
      font: "600 10.5px/1.35 system-ui, -apple-system, sans-serif"
    });
    heading.append(title, status);

    const body = document.createElement("div");
    body.textContent = message;
    Object.assign(body.style, {
      color: "#4b5563",
      overflowWrap: "anywhere"
    });
    copy.append(heading, body);
    row.appendChild(copy);

    if (options.showControl === true) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.protectorPauseControl = "true";
      button.textContent = pauseLabel();
      button.disabled = pauseToggleBusy;
      Object.assign(button.style, {
        flex: "0 0 auto",
        border: "1px solid #d1d5db",
        borderRadius: "6px",
        padding: "5px 7px",
        background: "#fff",
        color: "#374151",
        font: "600 11px/1 system-ui, -apple-system, sans-serif",
        cursor: "pointer"
      });
      button.addEventListener("click", toggleAutomationPause);
      row.appendChild(button);
    }

    root.appendChild(row);

    const context = options.context;
    if (context && Array.isArray(context.sections) && context.sections.length > 0) {
      const contextRoot = document.createElement("div");
      Object.assign(contextRoot.style, {
        marginTop: "8px",
        paddingTop: "7px",
        paddingRight: "3px",
        borderTop: "1px solid #e5e7eb",
        maxHeight: "30vh",
        overflowY: "auto",
        overscrollBehavior: "contain",
        scrollbarGutter: "stable"
      });

      const contextTitle = document.createElement("div");
      contextTitle.textContent = String(context.title || "Underlag från CRM");
      Object.assign(contextTitle.style, {
        color: "#6b7280",
        font: "700 10px/1.3 system-ui, -apple-system, sans-serif",
        letterSpacing: ".035em",
        textTransform: "uppercase",
        marginBottom: "3px"
      });
      contextRoot.appendChild(contextTitle);

      for (const section of context.sections) {
        const values = (Array.isArray(section?.values) ? section.values : [])
          .map((value) => String(value || "").trim())
          .filter(Boolean);
        const detailValues = (Array.isArray(section?.detailValues) ? section.detailValues : [])
          .map((value) => String(value || "").trim())
          .filter(Boolean);
        if (values.length === 0 && detailValues.length === 0) continue;
        const sectionRoot = document.createElement("div");
        sectionRoot.style.marginTop = "5px";
        const label = document.createElement("div");
        label.textContent = String(section?.label || "CRM");
        Object.assign(label.style, { color: "#374151", fontWeight: "650", fontSize: "11px" });
        sectionRoot.appendChild(label);
        for (const value of values) {
          const line = document.createElement("div");
          line.textContent = value;
          Object.assign(line.style, {
            color: "#111827",
            marginTop: "1px",
            whiteSpace: "pre-wrap",
            overflowWrap: "anywhere"
          });
          sectionRoot.appendChild(line);
        }
        for (const value of detailValues) {
          const line = document.createElement("div");
          line.textContent = value;
          Object.assign(line.style, {
            color: "#4b5563",
            marginTop: "1px",
            whiteSpace: "pre-wrap",
            overflowWrap: "anywhere",
            fontStyle: "italic",
            fontSize: "11.5px"
          });
          sectionRoot.appendChild(line);
        }
        contextRoot.appendChild(sectionRoot);
      }
      root.appendChild(contextRoot);
    }
  }

  function sanitizeAction(action) {
    if (!action || typeof action !== "object") return null;
    const sanitized = { type: String(action.type || "") };
    if (action.id) sanitized.id = String(action.id);
    if (action.name) sanitized.name = String(action.name);
    if (Array.isArray(action.selectors)) sanitized.selectors = action.selectors.map(String).slice(0, 12);
    if (Array.isArray(action.fields)) sanitized.fieldIds = action.fields.map((field) => String(field?.id || "")).filter(Boolean).slice(0, 20);
    if (action.text) sanitized.text = String(action.text);
    if (Object.prototype.hasOwnProperty.call(action, "value")) {
      sanitized.valueRedacted = true;
      sanitized.valueLength = String(action.value || "").length;
    }
    return sanitized;
  }

  function capturePortalSnapshot(includeText) {
    const buttons = Array.from(document.querySelectorAll("button")).slice(0, 80).map((button) => ({
      text: String(button.innerText || "").replace(/\s+/g, " ").trim().slice(0, 160),
      ariaLabel: String(button.getAttribute("aria-label") || "").slice(0, 160),
      disabled: button.disabled,
      pressed: button.getAttribute("aria-pressed") === "true"
    }));
    const inputs = Array.from(document.querySelectorAll("input,textarea,select")).slice(0, 80).map((input) => ({
      id: String(input.id || "").slice(0, 120),
      name: String(input.getAttribute("name") || "").slice(0, 120),
      type: String(input.getAttribute("type") || input.tagName || "").slice(0, 40),
      disabled: Boolean(input.disabled),
      checked: input instanceof HTMLInputElement && /^(checkbox|radio)$/.test(input.type) ? input.checked : null,
      selectedText: input instanceof HTMLSelectElement
        ? Array.from(input.selectedOptions).map((option) => String(option.textContent || "").trim().slice(0, 160)).slice(0, 20)
        : [],
      value: input instanceof HTMLInputElement && /^(date|time|datetime-local|month|week|number|radio|checkbox)$/.test(input.type)
        ? String(input.value || "").slice(0, 160)
        : null,
      valueRedacted: (input instanceof HTMLTextAreaElement) ||
        (input instanceof HTMLInputElement && !/^(date|time|datetime-local|month|week|number|radio|checkbox|hidden|button|submit)$/.test(input.type)),
      valueLength: "value" in input ? String(input.value || "").length : 0
    }));
    const snapshot = {
      heading: String(document.querySelector("main h1")?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 240),
      buttons,
      inputs
    };
    if (includeText) {
      snapshot.textSnippet = String(document.querySelector("main")?.innerText || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 800);
    }
    return snapshot;
  }

  function collectVisibleValidationErrors() {
    const errors = new Set();
    const add = (value) => {
      const text = String(value || "").replace(/\s+/g, " ").trim();
      if (text) errors.add(text.slice(0, 240));
    };
    const isVisible = (element) => {
      if (!(element instanceof HTMLElement) || element.hidden || element.getAttribute("aria-hidden") === "true") return false;
      let current = element;
      while (current instanceof HTMLElement) {
        const style = getComputedStyle(current);
        if (style.display === "none" || style.visibility === "hidden") return false;
        current = current.parentElement;
      }
      return true;
    };
    for (const element of document.querySelectorAll("[role='alert'], .MuiFormHelperText-root, [aria-invalid='true']")) {
      if (!(element instanceof HTMLElement) || !isVisible(element)) continue;
      const text = element.textContent;
      const ariaInvalid = element.getAttribute("aria-invalid") === "true";
      const roleAlert = element.getAttribute("role") === "alert";
      const activeHelper = element.classList.contains("Mui-error") || Boolean(
        element.id && Array.from(document.querySelectorAll("[aria-invalid='true'][aria-describedby]")).some((control) =>
          String(control.getAttribute("aria-describedby") || "").split(/\s+/).includes(element.id)
        )
      );
      if (
        (ariaInvalid || roleAlert || activeHelper) &&
        /is not valid|inte giltig|ogiltig|felaktig|required|obligatorisk/i.test(String(text || ""))
      ) add(text);
      if (ariaInvalid) {
        const describedBy = element.getAttribute("aria-describedby");
        if (describedBy) add(document.getElementById(describedBy)?.textContent);
        if (!describedBy && !text) add(`${element.id || "field"}: aria-invalid`);
      }
    }
    if (document.querySelector("[aria-invalid='true']")) {
      const mainLines = String(document.querySelector("main")?.innerText || "").split("\n");
      for (const line of mainLines) {
        if (/is not valid|inte giltig|ogiltig|felaktig|required|obligatorisk/i.test(line)) add(line);
      }
    }
    return [...errors];
  }

  function findExactButton(text) {
    const target = normalize(text);
    const matches = Array.from(document.querySelectorAll("button")).filter((button) => normalize(button.innerText) === target);
    if (matches.length !== 1) throw new Error(`EXPECTED_ONE_BUTTON:${text}:${matches.length}`);
    if (matches[0].disabled) throw new Error(`BUTTON_DISABLED:${text}`);
    return matches[0];
  }

  async function waitForExactEnabledButton(text, timeoutMs = 3000) {
    const target = normalize(text);
    let lastReason = `EXPECTED_ONE_BUTTON:${text}:0`;
    return waitForCondition(() => {
      const matches = Array.from(document.querySelectorAll("button")).filter((button) => normalize(button.innerText) === target);
      if (matches.length !== 1) {
        lastReason = `EXPECTED_ONE_BUTTON:${text}:${matches.length}`;
        return null;
      }
      if (matches[0].disabled) {
        lastReason = `BUTTON_DISABLED:${text}`;
        return null;
      }
      return matches[0];
    }, timeoutMs).catch(() => { throw new Error(lastReason); });
  }

  function findExactElement(selector, text) {
    const target = normalize(text);
    const matches = Array.from(document.querySelectorAll(selector)).filter((element) => normalize(element.textContent) === target);
    if (matches.length !== 1) throw new Error(`EXPECTED_ONE_ELEMENT:${selector}:${text}:${matches.length}`);
    return matches[0];
  }

  function setNativeValue(input, value) {
    const prototype = Object.getPrototypeOf(input);
    const descriptor = prototype ? Object.getOwnPropertyDescriptor(prototype, "value") : null;
    if (descriptor?.set) descriptor.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  function setNativeValueOnly(input, value) {
    const prototype = Object.getPrototypeOf(input);
    const descriptor = prototype ? Object.getOwnPropertyDescriptor(prototype, "value") : null;
    if (descriptor?.set) descriptor.set.call(input, value);
    else input.value = value;
  }

  function fieldMatches(input, expected) {
    if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement)) return false;
    const actual = String(input.value || "");
    const wanted = String(expected || "");
    if (input.id === "nationalIdentity") return actual.replace(/\D/g, "") === wanted.replace(/\D/g, "");
    return normalize(actual) === normalize(wanted);
  }

  async function fillNationalIdentity(action) {
    const expected = String(action.value || "");
    let input = document.getElementById(action.id);
    if (!(input instanceof HTMLInputElement)) throw new Error(`INPUT_MISSING:${action.id}`);
    input.focus();
    setNativeValueOnly(input, "");
    input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward", data: null }));
    let typed = "";
    for (const character of expected) {
      typed += character;
      input = document.getElementById(action.id);
      if (!(input instanceof HTMLInputElement)) throw new Error(`INPUT_MISSING:${action.id}`);
      setNativeValueOnly(input, typed);
      input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: character }));
      await new Promise((resolve) => setTimeout(resolve, 15));
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
    await new Promise((resolve) => setTimeout(resolve, 300));
    await waitForCondition(() => {
      const reconciled = document.getElementById(action.id);
      return fieldMatches(reconciled, expected) ? reconciled : null;
    }, 2000).catch(() => { throw new Error(`FIELD_NOT_PERSISTED:${action.id}`); });
  }

  function waitForElement(id, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    return new Promise((resolve) => {
      const check = () => {
        const element = document.getElementById(id);
        if (element || Date.now() >= deadline) return resolve(element);
        setTimeout(check, 50);
      };
      check();
    });
  }

  function waitForCondition(check, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    return new Promise((resolve, reject) => {
      const poll = () => {
        const result = check();
        if (result) return resolve(result);
        if (Date.now() >= deadline) return reject(new Error("CONDITION_TIMEOUT"));
        setTimeout(poll, 50);
      };
      poll();
    });
  }

  function datePartsFromTimestamp(element) {
    const timestamp = Number(element?.getAttribute?.("data-timestamp"));
    if (!Number.isFinite(timestamp)) return null;
    const date = new Date(timestamp);
    return { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() };
  }

  function visibleCalendarDate() {
    return datePartsFromTimestamp(document.querySelector('[role="gridcell"][data-timestamp]'));
  }

  async function selectCalendarDate(isoDate) {
    const match = String(isoDate || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) throw new Error(`INVALID_DATE:${isoDate}`);
    const target = { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
    const today = new Date();
    const targetDate = new Date(target.year, target.month - 1, target.day);
    if (targetDate > today) throw new Error(`FUTURE_DATE:${isoDate}`);

    let visible = visibleCalendarDate();
    if (!visible) throw new Error("DATE_GRID_MISSING");
    if (visible.year !== target.year) {
      const yearToggle = document.querySelector('button[aria-label="calendar view is open, switch to year view"]');
      if (!(yearToggle instanceof HTMLButtonElement)) throw new Error("YEAR_VIEW_TOGGLE_MISSING");
      yearToggle.click();
      await waitForCondition(() => document.querySelector('[role="radiogroup"]'), 2000);
      const yearOption = findExactElement('[role="radio"]', String(target.year));
      if (yearOption.hasAttribute("disabled")) throw new Error(`YEAR_DISABLED:${target.year}`);
      yearOption.click();
      await waitForCondition(() => visibleCalendarDate()?.year === target.year, 2000);
      visible = visibleCalendarDate();
    }

    const monthDelta = target.month - visible.month;
    const direction = monthDelta < 0 ? "Previous month" : "Next month";
    for (let index = 0; index < Math.abs(monthDelta); index += 1) {
      const previous = visibleCalendarDate();
      const button = document.querySelector(`button[aria-label="${direction}"]`);
      if (!(button instanceof HTMLButtonElement) || button.disabled) throw new Error(`MONTH_NAVIGATION_BLOCKED:${direction}`);
      button.click();
      await waitForCondition(() => {
        const current = visibleCalendarDate();
        return current && (current.year !== previous?.year || current.month !== previous?.month);
      }, 2000);
    }

    const day = Array.from(document.querySelectorAll('[role="gridcell"][data-timestamp]')).find((element) => {
      const parts = datePartsFromTimestamp(element);
      return parts?.year === target.year && parts?.month === target.month && parts?.day === target.day;
    });
    if (!(day instanceof HTMLButtonElement) || day.disabled) throw new Error(`DATE_UNAVAILABLE:${isoDate}`);
    day.click();
    await waitForCondition(() => day.getAttribute("aria-selected") === "true", 2000);
  }

  async function findBodyCheckbox(id) {
    let checkbox = document.getElementById(id);
    if (checkbox) return checkbox;
    const backSide = /-(HEAD_BACK|TORSO_BACK)$/.test(id);
    findExactButton(backSide ? "BAKSIDA" : "FRAMSIDA").click();
    checkbox = await waitForElement(id, 2000);
    return checkbox;
  }

  function normalizeRegistrationIdentity(value) {
    return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  }

  function hasExactRegistrationDescendant(root, registrationNumber) {
    if (!(root instanceof Element)) return false;
    const expected = normalizeRegistrationIdentity(registrationNumber);
    if (!expected) return false;
    const candidates = [root, ...Array.from(root.querySelectorAll("*"))];
    return candidates.some((element) => {
      if (!(element instanceof Element)) return false;
      if (element.children.length > 0) return false;
      return normalizeRegistrationIdentity(element.textContent) === expected;
    });
  }

  function exactButtonsWithin(root, text) {
    const target = normalize(text);
    return Array.from((root || document).querySelectorAll("button")).filter(
      (button) => normalize(button.textContent) === target && !button.disabled
    );
  }

  function closestVehicleCardForButton(button, registrationNumber, buttonText, boundary) {
    let current = button?.parentElement || null;
    while (current && current !== boundary && current !== document.body) {
      if (
        hasExactRegistrationDescendant(current, registrationNumber) &&
        exactButtonsWithin(current, buttonText).length === 1
      ) {
        return current;
      }
      current = current.parentElement;
    }
    return null;
  }

  function findExactVehicleActionCards(registrationNumber, buttonText, boundary) {
    const cards = exactButtonsWithin(boundary || document, buttonText)
      .map((button) => ({
        button,
        card: closestVehicleCardForButton(button, registrationNumber, buttonText, boundary || null)
      }))
      .filter((entry) => entry.card);
    const unique = [];
    for (const entry of cards) {
      if (!unique.some((item) => item.card === entry.card)) unique.push(entry);
    }
    return unique;
  }

  async function vehicleLookupExact(action, path) {
    assertAutomationRunning();
    const registrationNumber = normalizeRegistrationIdentity(action.registrationNumber);
    if (!registrationNumber) throw new Error("USER_REQUIRED:VEHICLE_REGISTRATION_MISSING_OR_INVALID");
    const input = document.getElementById("registrationNumber");
    if (!(input instanceof HTMLInputElement)) throw new Error("INPUT_MISSING:registrationNumber");
    const form = input.closest("form") || document.body;
    const selectText = String(action.selectText || "Välj");
    const continueText = String(action.continueText || "Gå vidare");
    const lookupText = String(action.lookupText || "Sök");

    const clickSelectedContinueIfPresent = async () => {
      const selected = findExactVehicleActionCards(registrationNumber, continueText, form);
      if (selected.length > 1) throw new Error("USER_REQUIRED:VEHICLE_SELECTED_RESULT_AMBIGUOUS");
      if (selected.length !== 1) return false;
      assertAutomationRunning();
      selected[0].button.click();
      await waitForCondition(() => {
        const currentPath = contracts?.normalizePath?.(location.href) || location.pathname;
        return currentPath !== path ? currentPath : null;
      }, 4000).catch(() => { throw new Error("VEHICLE_CONTINUE_DID_NOT_NAVIGATE"); });
      return true;
    };

    if (await clickSelectedContinueIfPresent()) return;

    let matches = findExactVehicleActionCards(registrationNumber, selectText, form);
    if (matches.length === 0) {
      assertAutomationRunning();
      input.focus();
      setNativeValue(input, registrationNumber);
      if (normalizeRegistrationIdentity(input.value) !== registrationNumber) {
        throw new Error("INPUT_POSTCONDITION_FAILED:registrationNumber");
      }

      const lookupButtons = exactButtonsWithin(form, lookupText);
      if (lookupButtons.length !== 1) throw new Error(`EXPECTED_ONE_VEHICLE_LOOKUP_BUTTON:${lookupButtons.length}`);
      assertAutomationRunning();
      lookupButtons[0].click();

      matches = await waitForCondition(() => {
        const currentMatches = findExactVehicleActionCards(registrationNumber, selectText, form);
        if (currentMatches.length > 0) return currentMatches;
        return null;
      }, 7000).catch(() => null);

      if (!matches || matches.length === 0) {
        throw new Error("USER_REQUIRED:VEHICLE_LOOKUP_NO_EXACT_MATCH_OR_TIMEOUT");
      }
    }

    if (matches.length > 1) throw new Error("USER_REQUIRED:VEHICLE_LOOKUP_MULTIPLE_EXACT_MATCHES");
    assertAutomationRunning();
    matches[0].button.click();

    await waitForCondition(() => {
      const selected = findExactVehicleActionCards(registrationNumber, continueText, form);
      if (selected.length > 1) throw new Error("USER_REQUIRED:VEHICLE_SELECTED_RESULT_AMBIGUOUS");
      return selected.length === 1 ? selected[0] : null;
    }, 3000).catch((error) => {
      if (error instanceof Error && error.message.startsWith("USER_REQUIRED:")) throw error;
      throw new Error("USER_REQUIRED:VEHICLE_SELECTION_NOT_CONFIRMED");
    });

    assertAutomationRunning();
    if (!(await clickSelectedContinueIfPresent())) {
      throw new Error("USER_REQUIRED:VEHICLE_SELECTION_NOT_CONFIRMED");
    }
  }

  async function executeAction(action, path, options = {}) {
    assertAutomationRunning();
    if (action.type === "click_text") {
      const button = await waitForExactEnabledButton(action.text);
      button.click();
      if (options.expectNavigation === true) {
        await waitForCondition(() => {
          const currentPath = contracts?.normalizePath?.(location.href) || location.pathname;
          return currentPath !== path ? currentPath : null;
        }, 10000).catch(() => { throw new Error("EXPECTED_NAVIGATION_DID_NOT_OCCUR"); });
      }
      return;
    }
    if (action.type === "check_id") {
      const checkbox = await findBodyCheckbox(action.id);
      if (!(checkbox instanceof HTMLInputElement) || checkbox.type !== "checkbox") {
        throw new Error(`CHECKBOX_MISSING:${action.id}`);
      }
      if (!checkbox.checked) checkbox.click();
      if (!checkbox.checked) throw new Error(`CHECKBOX_NOT_CHECKED:${action.id}`);
      return;
    }
    if (action.type === "fill_id") {
      const input = document.getElementById(action.id);
      if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement)) {
        throw new Error(`INPUT_MISSING:${action.id}`);
      }
      setNativeValue(input, String(action.value || ""));
      if (String(input.value || "") !== String(action.value || "")) {
        throw new Error(`INPUT_POSTCONDITION_FAILED:${action.id}`);
      }
      return;
    }
    if (action.type === "fill_national_identity") {
      await fillNationalIdentity(action);
      return;
    }
    if (action.type === "fill_name") {
      const matches = Array.from(document.querySelectorAll("input[name],textarea[name]")).filter(
        (input) => input.getAttribute("name") === String(action.name || "")
      );
      if (matches.length !== 1 || !(matches[0] instanceof HTMLInputElement || matches[0] instanceof HTMLTextAreaElement)) {
        throw new Error(`EXPECTED_ONE_NAMED_INPUT:${action.name}:${matches.length}`);
      }
      const input = matches[0];
      setNativeValue(input, String(action.value || ""));
      if (String(input.value || "") !== String(action.value || "")) {
        throw new Error(`INPUT_POSTCONDITION_FAILED:${action.name}`);
      }
      return;
    }
    if (action.type === "fill_optional_candidates") {
      const candidates = (Array.isArray(action.selectors) ? action.selectors : [])
        .flatMap((selector) => Array.from(document.querySelectorAll(String(selector))));
      const input = candidates.find((candidate, index) =>
        candidates.indexOf(candidate) === index &&
        (candidate instanceof HTMLInputElement || candidate instanceof HTMLTextAreaElement)
      );
      if (!input) return;
      setNativeValue(input, String(action.value || ""));
      if (String(input.value || "") !== String(action.value || "")) {
        throw new Error(`INPUT_POSTCONDITION_FAILED:${action.selectors?.[0] || "candidate"}`);
      }
      return;
    }
    if (action.type === "select_exact_id") {
      const element = document.getElementById(action.id);
      const expectedValue = String(action.value || "");
      const expectedLabel = String(action.label || "");
      if (element instanceof HTMLSelectElement) {
        const matchingOptions = Array.from(element.options).filter((option) =>
          normalize(option.value) === normalize(expectedValue) ||
          normalize(option.textContent) === normalize(expectedLabel)
        );
        const uniqueMatches = matchingOptions.filter((option, index) => matchingOptions.indexOf(option) === index);
        if (uniqueMatches.length !== 1) {
          throw new Error(`EXPECTED_ONE_SELECT_OPTION:${action.id}:${expectedValue}:${uniqueMatches.length}`);
        }
        const option = uniqueMatches[0];
        setNativeValue(element, option.value);
        await waitForCondition(() => {
          const current = document.getElementById(action.id);
          if (!(current instanceof HTMLSelectElement)) return null;
          const selected = current.selectedOptions?.[0];
          return selected && (
            normalize(selected.value) === normalize(option.value) ||
            normalize(selected.textContent) === normalize(expectedLabel)
          ) ? current : null;
        }, 2000).catch(() => { throw new Error(`SELECT_POSTCONDITION_FAILED:${action.id}`); });
        return;
      }
      if (element instanceof HTMLInputElement) {
        element.focus();
        setNativeValue(element, expectedLabel);
        const option = await waitForCondition(() => {
          const matches = Array.from(document.querySelectorAll('[role="option"]')).filter(
            (candidate) => normalize(candidate.textContent) === normalize(expectedLabel)
          );
          if (matches.length > 1) throw new Error(`EXPECTED_ONE_AUTOCOMPLETE_OPTION:${action.id}:${matches.length}`);
          return matches.length === 1 ? matches[0] : null;
        }, 2500);
        option.click();
        await waitForCondition(() => {
          const current = document.getElementById(action.id);
          return current instanceof HTMLInputElement && normalize(current.value) === normalize(expectedLabel)
            ? current
            : null;
        }, 2000).catch(() => { throw new Error(`AUTOCOMPLETE_POSTCONDITION_FAILED:${action.id}`); });
        return;
      }
      throw new Error(`SELECT_CONTROL_MISSING_OR_UNSUPPORTED:${action.id}`);
    }
    if (action.type === "vehicle_lookup_exact") {
      await vehicleLookupExact(action, path);
      return;
    }
    if (action.type === "select_autocomplete_id") {
      const input = document.getElementById(action.id);
      if (!(input instanceof HTMLInputElement)) throw new Error(`INPUT_MISSING:${action.id}`);
      input.focus();
      setNativeValue(input, String(action.value || ""));
      const option = await waitForCondition(() => {
        const target = normalize(action.value);
        return Array.from(document.querySelectorAll('[role="option"]')).find((element) => normalize(element.textContent) === target);
      }, 2500);
      option.click();
      await waitForCondition(() => normalize(input.value) === normalize(action.value), 2000);
      return;
    }
    if (action.type === "select_date") {
      await selectCalendarDate(action.value);
      return;
    }
    if (action.type === "verify_fields") {
      const fields = Array.isArray(action.fields) ? action.fields : [];
      await new Promise((resolve) => setTimeout(resolve, 300));
      const failed = fields.find((field) => !fieldMatches(document.getElementById(String(field.id || "")), field.value));
      if (failed) throw new Error(`FIELD_NOT_PERSISTED:${failed.id}`);
      return;
    }
    throw new Error(`UNKNOWN_ACTION:${action.type}`);
  }

  async function report(payload) {
    try {
      await chrome.runtime.sendMessage({ type: "PROTECTOR_PORTAL_REPORT", payload });
    } catch {
      // Best-effort diagnostics only. Never continue based on a failed report.
    }
  }

  function describePassiveInteraction(target) {
    if (!(target instanceof Element)) return null;
    let element = target.closest("button,input,textarea,select,label");
    if (element instanceof HTMLLabelElement && element.control) element = element.control;
    if (!element || element.closest("#crm-protector-status")) return null;
    const base = {
      tag: element.tagName.toLowerCase(),
      id: String(element.id || "").slice(0, 120),
      name: String(element.getAttribute("name") || "").slice(0, 120),
      type: String(element.getAttribute("type") || element.tagName || "").slice(0, 40),
      text: String(element.textContent || element.getAttribute("aria-label") || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 240)
    };
    if (element instanceof HTMLInputElement && /^(checkbox|radio)$/.test(element.type)) {
      return { ...base, kind: "choice_change", checked: element.checked, value: String(element.value || "").slice(0, 160) };
    }
    if (element instanceof HTMLSelectElement) {
      return {
        ...base,
        kind: "choice_change",
        selectedText: Array.from(element.selectedOptions).map((option) => String(option.textContent || "").trim().slice(0, 160)).slice(0, 20)
      };
    }
    if (element instanceof HTMLInputElement && /^(date|time|datetime-local|month|week|number)$/.test(element.type)) {
      return { ...base, kind: "input_change", value: String(element.value || "").slice(0, 160) };
    }
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      return { ...base, kind: "input_change", valueRedacted: true, valueLength: String(element.value || "").length };
    }
    return { ...base, kind: "button_click" };
  }

  async function recordPassivePage(path, previousPath) {
    if (!passiveQaEnabled || !path || path === passiveQaCurrentPath) return;
    passiveQaCurrentPath = path;
    showMessage("Automation avstängd. Passiv QA-inspelning pågår.", "warn");
    await report({
      path,
      previousPath: previousPath || null,
      status: "PASSIVE_QA_PAGE",
      reason: "AUTOMATION_DISABLED",
      portal: capturePortalSnapshot(true)
    });
  }

  function enablePassiveQa(runId, currentPath, previousPath) {
    if (!passiveQaEnabled || passiveQaRunId !== runId) {
      passiveQaEnabled = true;
      passiveQaRunId = runId || "replay";
      passiveQaCurrentPath = previousPath || null;
    }
    void recordPassivePage(currentPath, passiveQaCurrentPath || previousPath || null);
  }

  function recordPassiveInteraction(event) {
    if (!passiveQaEnabled) return;
    const path = contracts?.normalizePath?.(location.href) || location.pathname;
    const interaction = describePassiveInteraction(event.target);
    if (!interaction) return;
    window.setTimeout(() => {
      if (!passiveQaEnabled) return;
      void report({
        path,
        status: "PASSIVE_QA_INTERACTION",
        reason: "AUTOMATION_DISABLED",
        interaction: describePassiveInteraction(event.target) || interaction,
        portal: capturePortalSnapshot(false)
      });
    }, 0);
  }

  async function applyStep(step, token, path) {
    const validation = contracts?.validateDocument?.(document, path) || { ok: true };
    if (!validation.ok) {
      const knownRouteStillRendering = validation.reason !== "UNKNOWN_ROUTE" &&
        contracts?.hasMeaningfulPortalDom?.(document) === false;
      if (knownRouteStillRendering) {
        const now = Date.now();
        if (!portalReadinessWait || portalReadinessWait.token !== token) {
          portalReadinessWait = { token, startedAt: now };
          showMessage("Väntar på att portalsidan ska renderas.", "warn", { showControl: true });
          await report({
            path,
            status: "PORTAL_NOT_READY",
            reason: "EMPTY_PORTAL_DOM",
            decision: step.diagnostics || null,
            plannedActions: [...(step.prefill || []), ...(step.actions || [])].map(sanitizeAction),
            contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] },
            portal: capturePortalSnapshot(false)
          });
        }
        if (now - portalReadinessWait.startedAt < PORTAL_READINESS_TIMEOUT_MS) return "RETRY";
      }
      portalReadinessWait = null;
      const status = validation.reason === "UNKNOWN_ROUTE" ? "UNKNOWN_ROUTE" : "PORTAL_SCHEMA_MISMATCH";
      showMessage(
        status === "UNKNOWN_ROUTE"
          ? "Stoppad: portalsidan är ännu inte kartlagd."
          : "Stoppad: portalens struktur känns inte igen.",
        "error"
      );
      await report({
        path,
        status,
        reason: validation.reason,
        decision: step.diagnostics || null,
        plannedActions: [...(step.prefill || []), ...(step.actions || [])].map(sanitizeAction),
        contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] },
        portal: capturePortalSnapshot(true)
      });
      return true;
    }
    portalReadinessWait = null;

    const executeActions = async (actions, phase) => {
      for (let actionIndex = 0; actionIndex < actions.length; actionIndex += 1) {
        if (automationPaused) return "PAUSED";
        const action = actions[actionIndex];
        try {
          const expectNavigation = action?.type === "click_text" && (
            normalize(action?.text) === normalize("Gå vidare") || actions.length === 1
          );
          await executeAction(action, path, { expectNavigation });
          if (automationPaused) return "PAUSED";
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          if (message === "AUTOMATION_PAUSED") return "PAUSED";
          if (message.startsWith("USER_REQUIRED:")) {
            const reason = message.slice("USER_REQUIRED:".length) || "EXECUTION_REQUIRES_USER";
            const manualNote = "Kontrollera fordonsvalet manuellt. Flödet fortsätter automatiskt när du går vidare.";
            showMessage(manualNote, "warn", { showControl: true });
            await report({
              path,
              status: "USER_REQUIRED",
              reason,
              pauseNote: manualNote,
              decision: step.diagnostics || null,
              plannedActions: [...(step.prefill || []), ...(step.actions || [])].map(sanitizeAction),
              contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] },
              executor: { phase, actionIndex, action: sanitizeAction(action) },
              portal: capturePortalSnapshot(false)
            });
            return false;
          }
          showMessage("Stoppad eftersom ett förväntat element saknas. Fortsätt inte automatiskt.", "error");
          await report({
            path,
            status: "EXECUTION_ERROR",
            reason: message,
            decision: step.diagnostics || null,
            plannedActions: [...(step.prefill || []), ...(step.actions || [])].map(sanitizeAction),
            contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] },
            executor: { phase, actionIndex, action: sanitizeAction(action) },
            failure: { type: message.split(":")[0] || "EXECUTION_ERROR", message: message.slice(0, 500) },
            portal: capturePortalSnapshot(true)
          });
          return false;
        }
      }
      return true;
    };

    if (Array.isArray(step.prefill)) {
      const prefillResult = await executeActions(step.prefill, "prefill");
      if (prefillResult === "PAUSED") return "PAUSED";
      if (!prefillResult) return true;
    }

    if (step.execution === "USER_REQUIRED") {
      const manualNote = step.note || "Gör valet manuellt. Flödet fortsätter automatiskt när du går vidare.";
      showMessage(manualNote, "warn", { showControl: true, context: step.manualContext || null });
      await report({
        path,
        status: "USER_REQUIRED",
        reason: step.reason || null,
        pauseNote: manualNote,
        decision: step.diagnostics || null,
        plannedActions: (step.prefill || []).map(sanitizeAction),
        contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] },
        portal: capturePortalSnapshot(false)
      });
      return true;
    }
    if (step.execution === "UNSUPPORTED") {
      showMessage(`Stoppad: ${step.note || "Okänd portalsida."}`, "error");
      await report({ path, status: "UNSUPPORTED", reason: step.reason || null, portal: capturePortalSnapshot(true) });
      return true;
    }

    const actionResult = await executeActions(step.actions || [], "actions");
    if (actionResult === "PAUSED") return "PAUSED";
    if (!actionResult) return true;

    if (step.execution === "HARD_STOP") {
      await new Promise((resolve) => setTimeout(resolve, 250));
      const bankName = document.getElementById("bankName");
      const clearing = document.getElementById("clearingNumber");
      const account = document.getElementById("accountNumber");
      const ownerGivenName = document.getElementById("ownerGivenName");
      const ownerFamilyName = document.getElementById("ownerFamilyName");
      const expectedClearing = (step.actions || []).find((action) => action.id === "clearingNumber")?.value;
      const expectedAccount = (step.actions || []).find((action) => action.id === "accountNumber")?.value;
      const validationErrors = collectVisibleValidationErrors();
      const bankValidation = contracts.validateBankState({
        expectedClearing,
        actualClearing: clearing?.value,
        expectedAccount,
        actualAccount: account?.value,
        expectedBankName: step.expectedBankName,
        actualBankName: bankName?.value,
        ownerFieldsPresent: Boolean(ownerGivenName || ownerFamilyName),
        expectedOwnerGivenName: step.expectedOwnerGivenName,
        actualOwnerGivenName: ownerGivenName?.value,
        expectedOwnerFamilyName: step.expectedOwnerFamilyName,
        actualOwnerFamilyName: ownerFamilyName?.value,
        validationErrors
      });
      if (!bankValidation.ok) {
        showMessage("Stoppad: bankuppgifterna godkänns inte av portalen. Gå inte vidare.", "error");
        await report({
          path,
          status: bankValidation.status,
          reason: bankValidation.failures.join(","),
          decision: step.diagnostics || null,
          validationErrors,
          portal: capturePortalSnapshot(true)
        });
        return true;
      }
      showMessage(step.note || "Kontrollera bankuppgifterna. Gå inte vidare.", "success");
      await report({ path, status: "READY_FOR_REVIEW", decision: step.diagnostics || null, portal: capturePortalSnapshot(false) });
      return true;
    }

    await report({
      path,
      status: "ACTION_COMPLETE",
      decision: step.diagnostics || null,
      plannedActions: (step.actions || []).map(sanitizeAction),
      contract: { matchedSelectors: validation.matched || [], missingSelectors: validation.missing || [] }
    });
    return true;
  }

  async function reconcile() {
    if (automationPaused) return;
    if (busy) return;
    busy = true;
    try {
      const path = contracts?.normalizePath?.(location.href) || location.pathname;
      const response = await chrome.runtime.sendMessage({
        type: "PROTECTOR_PORTAL_REQUEST_ACTION",
        payload: { path }
      });
      if (response?.ok && response?.paused) {
        activeRunId = response.runId || activeRunId;
        automationPaused = true;
        pauseSource = response.pauseSource || "USER";
        pauseReason = response.pauseReason || null;
        pauseNote = response.pauseNote || null;
        showMessage(pausedMessage(), "warn", { showControl: true });
        return;
      }
      if (response?.ok && response?.terminal) {
        activeRunId = response.runId || activeRunId;
        automationPaused = false;
        lastCompletedToken = `${response.runId || "run"}:${path}:terminal:${response.status || "STOPPED"}`;
        showMessage(
          response?.terminalReport?.reason
            ? `Stoppad: ${response.terminalReport.reason}`
            : "Stoppad för kontroll. Ingen ytterligare automation körs.",
          response.status === "READY_FOR_REVIEW" ? "success" : "error"
        );
        if (response.passiveQaEnabled) {
          enablePassiveQa(response.runId, path, response.passiveQaLastPath || null);
        }
        return;
      }
      if (!response?.ok || !response?.step) return;
      activeRunId = response.runId || activeRunId;
      automationPaused = false;
      pauseSource = null;
      pauseReason = null;
      pauseNote = null;
      const token = `${response.runId || "run"}:${path}:${response.step.execution}:${response.step.reason || ""}`;
      if (token === lastCompletedToken) return;
      showMessage("Kör automatiskt.", "running", { showControl: true });
      const completed = await applyStep(response.step, token, path);
      if (completed === "RETRY") {
        scheduleReconcile();
        return;
      }
      if (completed === "PAUSED") return;
      if (completed) lastCompletedToken = token;
      if (response.passiveQaEnabled) window.setTimeout(scheduleReconcile, 250);
    } catch (error) {
      lastCompletedToken = `error:${location.pathname}:terminal`;
      showMessage("Stoppad eftersom ett förväntat element saknas. Fortsätt inte automatiskt.", "error");
      await report({ path: location.pathname, status: "EXECUTION_ERROR", reason: error instanceof Error ? error.message : String(error) });
    } finally {
      busy = false;
    }
  }

  function scheduleReconcile() {
    clearTimeout(timer);
    timer = setTimeout(reconcile, 150);
  }

  new MutationObserver(scheduleReconcile).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("popstate", scheduleReconcile);
  document.addEventListener("click", (event) => {
    if (event.target instanceof Element && event.target.closest("button")) recordPassiveInteraction(event);
  }, true);
  document.addEventListener("change", recordPassiveInteraction, true);
  const scheduleBankRevalidation = (event) => {
    if (!(event.target instanceof Element)) return;
    if (!event.target.matches("#clearingNumber,#accountNumber,#ownerGivenName,#ownerFamilyName")) return;
    const path = contracts?.normalizePath?.(location.href) || location.pathname;
    if (path !== "/swe/sv/5/accident/bank-account-information") return;
    lastCompletedToken = null;
    scheduleReconcile();
  };
  document.addEventListener("input", scheduleBankRevalidation, true);
  document.addEventListener("change", scheduleBankRevalidation, true);
  setInterval(() => {
    const path = contracts?.normalizePath?.(location.href) || location.pathname;
    if (!lastCompletedToken || !lastCompletedToken.includes(`:${path}:`)) scheduleReconcile();
  }, 1000);
  scheduleReconcile();
})();
