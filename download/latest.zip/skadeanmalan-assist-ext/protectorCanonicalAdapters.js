(function (root, factory) {
  const api = factory();
  root.__crmProtectorCanonicalAdapters = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const AUTO = "AUTO";
  const AMBIGUOUS = "AMBIGUOUS";
  const UNKNOWN = "UNKNOWN";

  function fold(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .toLowerCase();
  }

  function compact(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function resolveResidualIssues(input) {
    const raw = Array.isArray(input)
      ? input
      : Array.isArray(input?.injuries?.residualIssues)
      ? input.injuries.residualIssues
      : [];
    const entries = raw.map(fold).filter(Boolean);
    const scarEvidence = entries.some((value) =>
      value === "scar" || /\barr\b/.test(value)
    );
    const positive = entries.some((value) =>
      value === "medical invalidity" ||
      /medicinsk invaliditet|framtida invaliditet/.test(value)
    );
    const negative = entries.some((value) =>
      value === "no residual issues" ||
      /inga kvarstaende besvar|ingen invaliditet/.test(value)
    );
    const explicitlyUnmapped = entries.some((value) =>
      value === "reduced mobility" || value === "reduced function"
    );

    if (positive && negative) {
      return { status: "SOURCE_CONFLICT", value: null, conflict: true, reason: "POSITIVE_AND_NEGATIVE_RESIDUAL_EVIDENCE" };
    }
    if (scarEvidence && negative) {
      return { status: "SOURCE_CONFLICT", value: null, conflict: true, reason: "SCAR_AND_NEGATIVE_RESIDUAL_EVIDENCE" };
    }
    if (positive && explicitlyUnmapped) {
      return { status: "SOURCE_CONFLICT", value: null, conflict: true, reason: "APPROVED_AND_UNMAPPED_RESIDUAL_EVIDENCE" };
    }
    if (positive) return { status: AUTO, value: "Ja", conflict: false, reason: "APPROVED_POSITIVE_RESIDUAL_EVIDENCE" };
    if (negative && explicitlyUnmapped) {
      return { status: "SOURCE_CONFLICT", value: null, conflict: true, reason: "NEGATIVE_AND_UNMAPPED_RESIDUAL_EVIDENCE" };
    }
    if (negative) return { status: AUTO, value: "Nej", conflict: false, reason: "EXPLICIT_NO_RESIDUAL_ISSUES" };
    if (scarEvidence) return { status: UNKNOWN, value: null, conflict: false, reason: "SCAR_ALONE_DOES_NOT_ESTABLISH_INVALIDITY" };
    if (entries.length === 0) return { status: UNKNOWN, value: null, conflict: false, reason: "RESIDUAL_ISSUES_EMPTY" };
    return { status: UNKNOWN, value: null, conflict: false, reason: "RESIDUAL_ISSUES_NOT_MAPPED" };
  }

  const VEHICLE_TYPE_CROSSWALK = Object.freeze({
    no_vehicle: { status: AUTO, involved: false, isMotorcycleOrMoped: null, reason: "Explicit no-vehicle value." },
    motorcycle: { status: AUTO, involved: true, isMotorcycleOrMoped: true, reason: "Explicit motorcycle value." },
    bicycle: { status: AUTO, involved: true, isMotorcycleOrMoped: false, reason: "Explicit bicycle value." },
    electric_scooter: { status: AMBIGUOUS, involved: true, isMotorcycleOrMoped: null, reason: "Protector motorcycle/moped equivalence is unverified." },
    hoverboard: { status: AMBIGUOUS, involved: true, isMotorcycleOrMoped: null, reason: "Protector vehicle branch equivalence is unverified." },
    moped: { status: AMBIGUOUS, involved: true, isMotorcycleOrMoped: null, reason: "Generic moped evidence requires active CRM/business evidence." },
    moped_class_1: { status: AUTO, involved: true, isMotorcycleOrMoped: true, reason: "Exact CRM tag Moped klass 1 maps to Protector motorcycle/moped." }
  });

  function normalizeVehicleType(value) {
    return fold(value).replace(/\s+/g, "_") || null;
  }

  function resolveVehicleType(value) {
    const type = normalizeVehicleType(value);
    const mapped = type ? VEHICLE_TYPE_CROSSWALK[type] : null;
    if (!mapped) return { type, status: UNKNOWN, involved: null, isMotorcycleOrMoped: null, reason: "VEHICLE_TYPE_NOT_MAPPED" };
    return { type, ...mapped };
  }

  function normalizeRegistrationNumber(value) {
    const normalized = compact(value).toUpperCase().replace(/[\s-]+/g, "");
    if (!normalized || !/^[A-Z0-9]{2,12}$/.test(normalized)) return null;
    return normalized;
  }

  function buildCanonicalVehicle(input) {
    const source = input && typeof input === "object" ? input : {};
    const typeResolution = resolveVehicleType(source.type || source.vehicleType);
    const explicitInvolved = typeof source.involved === "boolean" ? source.involved : null;
    const involved = explicitInvolved !== null ? explicitInvolved : typeResolution.involved;
    const registrationNumber = normalizeRegistrationNumber(source.registrationNumber);
    return {
      involved,
      registrationNumber,
      crmType: compact(source.crmType) || null,
      tags: Array.isArray(source.tags) ? source.tags.map((item) => compact(item)).filter(Boolean) : [],
      type: typeResolution.type,
      typeStatus: typeResolution.status,
      isMotorcycleOrMoped: typeof source.isMotorcycleOrMoped === "boolean"
        ? source.isMotorcycleOrMoped
        : typeResolution.isMotorcycleOrMoped,
      personInVehicle: typeof source.personInVehicle === "boolean" ? source.personInVehicle : null,
      isDriver: typeof source.isDriver === "boolean" ? source.isDriver : null,
      policeReported: typeof source.policeReported === "boolean" ? source.policeReported : null,
      hasHelmet: typeof source.hasHelmet === "boolean" ? source.hasHelmet : null,
      hasLicense: typeof source.hasLicense === "boolean" ? source.hasLicense : null,
      evidence: Array.isArray(source.evidence) ? source.evidence.map((item) => compact(item)).filter(Boolean) : []
    };
  }

  function resultRegistrationNumber(result) {
    if (!result || typeof result !== "object") return null;
    return normalizeRegistrationNumber(
      result.registrationNumber || result.registration || result.regNo || result.identity
    );
  }

  function selectExactVehicleResult(requestedRegistrationNumber, results) {
    const requested = normalizeRegistrationNumber(requestedRegistrationNumber);
    if (!requested) return { status: "USER_REQUIRED", reason: "REGISTRATION_NUMBER_MISSING_OR_INVALID", selectedIndex: null };
    const candidates = Array.isArray(results) ? results : [];
    const matchingIndexes = candidates.reduce((indexes, result, index) => {
      if (resultRegistrationNumber(result) === requested) indexes.push(index);
      return indexes;
    }, []);
    if (matchingIndexes.length === 0) return { status: "USER_REQUIRED", reason: "VEHICLE_LOOKUP_NO_EXACT_MATCH", selectedIndex: null };
    if (matchingIndexes.length > 1) return { status: "USER_REQUIRED", reason: "VEHICLE_LOOKUP_MULTIPLE_EXACT_MATCHES", selectedIndex: null };
    return { status: AUTO, reason: "VEHICLE_LOOKUP_EXACT_REGISTRATION_MATCH", selectedIndex: matchingIndexes[0] };
  }

  const CLAIM_CONTEXT_CROSSWALK = Object.freeze({
    school: { status: "CANDIDATE", semantic: "SCHOOL", reason: "Explicit school context; final Protector business policy still required." },
    work: { status: "CANDIDATE", semantic: "WORK", reason: "Explicit work context; final Protector business policy still required." },
    to_from_school: { status: AMBIGUOUS, semantic: "SCHOOL_COMMUTE", reason: "Must not be collapsed into leisure or school without policy." },
    to_from_work: { status: AMBIGUOUS, semantic: "WORK_COMMUTE", reason: "Must not be collapsed into leisure or work without policy." },
    sport: { status: AMBIGUOUS, semantic: "SPORT", reason: "Requires separate sport crosswalk and Protector context policy." },
    abroad: { status: "EVIDENCE_ONLY", semantic: "ABROAD", reason: "Deterministic domestic evidence, not a complete claim-location mapping." },
    military_service: { status: AMBIGUOUS, semantic: "MILITARY_SERVICE", reason: "No approved Protector equivalence." },
    other: { status: AMBIGUOUS, semantic: "OTHER", reason: "Generic context must fail closed." }
  });

  function resolveClaimContext(value) {
    const key = fold(value).replace(/\s+/g, "_");
    return CLAIM_CONTEXT_CROSSWALK[key]
      ? { source: key, ...CLAIM_CONTEXT_CROSSWALK[key] }
      : { source: key || null, status: UNKNOWN, semantic: null, reason: "CLAIM_CONTEXT_NOT_MAPPED" };
  }

  function resolveDomesticEvidence(input) {
    const source = input && typeof input === "object" ? input : {};
    const category = fold(source.category || source.caseCategory);
    const country = fold(source.country || source.incidentCountry);
    const countryDomestic = country ? /^(sverige|sweden)$/.test(country) : null;
    const abroadDomestic = source.abroad === true ? false : source.abroad === false ? true : null;
    const explicitDomestic = abroadDomestic !== null ? abroadDomestic : countryDomestic;

    if (abroadDomestic !== null && countryDomestic !== null && abroadDomestic !== countryDomestic) {
      return { status: AMBIGUOUS, value: null, reason: "COUNTRY_AND_ABROAD_CONFLICT" };
    }
    // Approved Protector business rule: the CRM case category is the source of
    // truth for the Sweden question. Any observed category except Utomlands is
    // domestic. Never apply this rule when category itself is missing.
    if (category) {
      const categoryDomestic = !/^(?:utomlands?|abroad)\b/.test(category);
      if (explicitDomestic !== null && categoryDomestic !== explicitDomestic) {
        return { status: AMBIGUOUS, value: null, reason: "CASE_CATEGORY_LOCATION_CONFLICT" };
      }
      return categoryDomestic
        ? { status: AUTO, value: "Ja", reason: "CASE_CATEGORY_NOT_ABROAD" }
        : { status: AUTO, value: "Nej", reason: "CASE_CATEGORY_ABROAD" };
    }
    // Keep explicit incident evidence as a fallback for older/replay payloads
    // that do not carry the overview category.
    if (explicitDomestic === null) return { status: UNKNOWN, value: null, reason: "DOMESTIC_EVIDENCE_MISSING" };
    if (abroadDomestic !== null) {
      return explicitDomestic
        ? { status: AUTO, value: "Ja", reason: "EXPLICIT_NOT_ABROAD" }
        : { status: AUTO, value: "Nej", reason: "EXPLICIT_ABROAD" };
    }
    return explicitDomestic
      ? { status: AUTO, value: "Ja", reason: "EXPLICIT_SWEDEN" }
      : { status: AUTO, value: "Nej", reason: "EXPLICIT_FOREIGN_COUNTRY" };
  }

  function resolvePreviousInjuryEvidence(input) {
    const value = input?.previousInjuryHad;
    if (value === true) return { status: AUTO, value: "Ja", reason: "EXPLICIT_PREVIOUS_INJURY_TRUE" };
    if (value === false) return { status: AUTO, value: "Nej", reason: "EXPLICIT_PREVIOUS_INJURY_FALSE" };
    return { status: UNKNOWN, value: null, reason: "PREVIOUS_INJURY_BOOLEAN_MISSING" };
  }

  return {
    AUTO,
    AMBIGUOUS,
    UNKNOWN,
    VEHICLE_TYPE_CROSSWALK,
    CLAIM_CONTEXT_CROSSWALK,
    resolveResidualIssues,
    normalizeVehicleType,
    resolveVehicleType,
    normalizeRegistrationNumber,
    buildCanonicalVehicle,
    selectExactVehicleResult,
    resolveClaimContext,
    resolveDomesticEvidence,
    resolvePreviousInjuryEvidence
  };
});
