document.getElementById("start").addEventListener("click", async () => {
  const button = document.getElementById("start"), status = document.getElementById("status");
  button.disabled = true; status.textContent = "Läser ärendet och öppnar QA…";
  try { const result = await chrome.runtime.sendMessage({type:"EXPORT_SKADA_AUTOFILL"});
    status.textContent = result?.ok ? "QA öppnad." : result?.message || "Importen misslyckades.";
  } catch(error) { status.textContent = error.message; } finally { button.disabled = false; }
});