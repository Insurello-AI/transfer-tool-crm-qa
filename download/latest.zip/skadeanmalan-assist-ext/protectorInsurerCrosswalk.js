(function (root, factory) {
  const api = factory();
  root.__crmProtectorInsurerCrosswalk = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const AUTO = "AUTO";
  const UNKNOWN = "UNKNOWN";

  // Closed catalogue statically extracted from the shipped Claims@Net client.
  // This module deliberately never maps an unknown insurer to a nearest match.
  const PROTECTOR_INSURERS = Object.freeze([
    "Accept",
    "AFA Försäkring",
    "Agria Djurförsäkring",
    "Aktsam",
    "Alandia Försäkring",
    "Alecta",
    "Allmänna Änke- och Pupillkassan i Sverige",
    "AMF",
    "Atlantica Båtförsäkring",
    "Bliwa",
    "Dina Försäkringar",
    "Euro Accident",
    "Europeiska ERV",
    "Folksam",
    "Förenade Liv",
    "Gjensidige",
    "Gar-Bo",
    "Gouda Reseförsäkring",
    "Hedvig",
    "Hela Försäkring",
    "Ica Försäkring",
    "Idun Liv",
    "If Skadeförsäkring",
    "Insurify",
    "KPA Pension",
    "Länsförsäkringar",
    "LÖF Patientförsäkring",
    "Moderna Försäkringar",
    "Movestic",
    "Mysafety",
    "Paydrive",
    "PRI Pensionsgaranti",
    "Skandia",
    "Solid Försäkring",
    "SPP Pension & Försäkring",
    "Svedea",
    "Sveland",
    "Swedbank Försäkring",
    "Tre Kronor Försäkring",
    "Trygg-Hansa",
    "Vardia Försäkring",
    "Villaägarna",
    "WaterCircles"
  ]);

  function normalize(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .toLowerCase();
  }

  const byNormalized = new Map(PROTECTOR_INSURERS.map((label) => [normalize(label), label]));
  const ALIASES = new Map([
    ["afa", "AFA Försäkring"],
    ["agria", "Agria Djurförsäkring"],
    ["alandia", "Alandia Försäkring"],
    ["atlantica", "Atlantica Båtförsäkring"],
    ["dina", "Dina Försäkringar"],
    ["europeiska", "Europeiska ERV"],
    ["gouda", "Gouda Reseförsäkring"],
    ["hela", "Hela Försäkring"],
    ["ica", "Ica Försäkring"],
    ["ica forsakring ab", "Ica Försäkring"],
    ["if", "If Skadeförsäkring"],
    ["if forsakring", "If Skadeförsäkring"],
    ["if skadeforsakring ab", "If Skadeförsäkring"],
    ["kpa", "KPA Pension"],
    ["lof", "LÖF Patientförsäkring"],
    ["lof patientforsakring", "LÖF Patientförsäkring"],
    ["moderna", "Moderna Försäkringar"],
    ["pri", "PRI Pensionsgaranti"],
    ["solid", "Solid Försäkring"],
    ["spp", "SPP Pension & Försäkring"],
    ["swedbank", "Swedbank Försäkring"],
    ["tre kronor", "Tre Kronor Försäkring"],
    ["trygg hansa", "Trygg-Hansa"],
    ["vardia", "Vardia Försäkring"]
  ]);

  function resolveInsurer(value) {
    const source = String(value || "").replace(/\s+/g, " ").trim();
    const key = normalize(source);
    if (!key) return { status: UNKNOWN, source: null, protectorValue: null, reason: "INSURER_MISSING" };

    const exact = byNormalized.get(key);
    if (exact) return { status: AUTO, source, protectorValue: exact, reason: "EXACT_PROTECTOR_CATALOG_MATCH" };

    const alias = ALIASES.get(key);
    if (alias) return { status: AUTO, source, protectorValue: alias, reason: "REVIEWED_INSURER_ALIAS" };

    // Regional Länsförsäkringar entities all map to the single closed Protector
    // catalogue entry. The prefix is specific enough to avoid fuzzy matching.
    if (/^lansforsakringar\b/.test(key)) {
      return { status: AUTO, source, protectorValue: "Länsförsäkringar", reason: "REVIEWED_LF_REGIONAL_ALIAS" };
    }

    return { status: UNKNOWN, source, protectorValue: null, reason: "INSURER_NOT_IN_REVIEWED_CROSSWALK" };
  }

  return { AUTO, UNKNOWN, PROTECTOR_INSURERS, resolveInsurer, __test: { normalize } };
});
