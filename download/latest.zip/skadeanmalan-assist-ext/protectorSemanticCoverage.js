(function (root, factory) {
  const api = factory();
  root.__crmProtectorSemanticCoverage = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const AUTO_GLOBAL = "AUTO_GLOBAL";
  const AUTO_CONDITIONAL = "AUTO_CONDITIONAL";
  const BUSINESS_RULE_REQUIRED = "BUSINESS_RULE_REQUIRED";
  const SOURCE_MISSING = "SOURCE_MISSING";
  const MANUAL_BY_DESIGN = "MANUAL_BY_DESIGN";
  const HARD_STOP = "HARD_STOP";

  const accident = (slug) => `/swe/sv/5/accident/${slug}`;
  const groups = {
    [AUTO_GLOBAL]: [
      "claim-date", "claim-time-of-day", "vehicle-information", "date-of-previous-injury",
      "date-of-treatment", "medical-institution-information", "situation-summary",
      "claimant-information", "reporter-information", "has-attachment"
    ],
    [AUTO_CONDITIONAL]: [
      "claim-reporter-role", "claim-reporter", "insurance-type", "privacy", "claim-location",
      "is-vehicle-involved", "is-vehicle-motorcycle", "person-in-vehicle", "happen-domestically",
      "during-sport", "type-of-sport", "teeth-or-body", "body-parts", "claim-cause",
      "claim-cause-consequences", "has-plaster-treatment", "weeks-of-plaster-treatment",
      "previous-injury", "is-doctor-contacted", "is-dentist-contacted", "date-of-dentist-treatment",
      "dentist-information", "type-of-medical-institution", "finished-treatment", "invalidity",
      "has-expenses", "in-elementary-school", "upload-receipt", "has-other-insurance",
      "other-insurance-company", "is-municipality", "school-information",
      "association-information"
    ],
    [BUSINESS_RULE_REQUIRED]: ["need-transport", "has-other-expenses"],
    [SOURCE_MISSING]: ["has-license", "has-helmet", "teeth", "company-information"],
    [MANUAL_BY_DESIGN]: ["upload-medical-certificate", "upload-attachment", "final-summary", "report-completed"],
    [HARD_STOP]: ["bank-account-information"]
  };

  const ROUTE_POLICY = Object.freeze(Object.fromEntries(
    Object.entries(groups).flatMap(([classification, slugs]) =>
      slugs.map((slug) => [accident(slug), Object.freeze({ classification })])
    )
  ));

  function getRoutePolicy(route) {
    return ROUTE_POLICY[String(route || "").replace(/\/+$/, "")] || null;
  }

  function summarizeStaticCoverage() {
    const counts = {
      [AUTO_GLOBAL]: 0,
      [AUTO_CONDITIONAL]: 0,
      [BUSINESS_RULE_REQUIRED]: 0,
      [SOURCE_MISSING]: 0,
      [MANUAL_BY_DESIGN]: 0,
      [HARD_STOP]: 0
    };
    for (const policy of Object.values(ROUTE_POLICY)) counts[policy.classification] += 1;
    return { routeCount: Object.keys(ROUTE_POLICY).length, counts };
  }

  function summarizePlan(steps) {
    const actual = { AUTO: 0, USER_REQUIRED: 0, UNSUPPORTED: 0, HARD_STOP: 0, OTHER: 0 };
    const manualReasons = [];
    for (const [route, step] of Object.entries(steps || {})) {
      if (!route.includes("/5/accident/")) continue;
      const execution = String(step?.execution || "OTHER");
      if (Object.prototype.hasOwnProperty.call(actual, execution)) actual[execution] += 1;
      else actual.OTHER += 1;
      if (execution === "USER_REQUIRED") {
        manualReasons.push({
          route,
          reason: step?.reason || null,
          policy: getRoutePolicy(route)?.classification || null
        });
      }
    }
    return { ...summarizeStaticCoverage(), actual, manualReasons };
  }

  return {
    AUTO_GLOBAL,
    AUTO_CONDITIONAL,
    BUSINESS_RULE_REQUIRED,
    SOURCE_MISSING,
    MANUAL_BY_DESIGN,
    HARD_STOP,
    ROUTE_POLICY,
    getRoutePolicy,
    summarizeStaticCoverage,
    summarizePlan
  };
});
