(function (root, factory) {
  const api = factory(root);

  // Expose in the injected execution context (isolated world) so executeScript() functions can use it.
  root.__crmFritidCanonical = api;

  // Export for Node tests / tooling.
  if (typeof module === "object" && module && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  const ALLOWED_LABELS = {
    claimant: new Set(["Namn", "Barnets namn", "Personnummer", "Ålder vid skadetillfälle", "Folkbokföringskommun"]),
    customer: new Set(["Namn", "Personnummer", "E-post"]),
    incident: new Set([
      "Händelsen inträffade",
      "Plats där händelsen inträffade",
      "Land",
      "Land där händelsen inträffade",
      "Datum och tidpunkt",
      "Beskrivning",
      "Övrig information från kund",
      "Kompletteringar",
      "Skola",
      "Skolans adress",
      "Skoladress",
      "Skolans postadress",
      "Skolans gatuadress",
      "Skolans postnummer och ort",
      "Verksamhetens adress",
      "Adress till skolan",
      "Utbildningsnivå",
      "Skolans försäkringstagare",
      "Besöksadress",
      // Sports-category fields
      "Idrott",
      "Klubb",
      "Serie",
      "Träningsanläggning",
      "Roll",
      "Typ av idrottare"
    ]),
    injuries: new Set(["Kvarstående besvär", "Kroppsskador"]),
    expenses: new Set(["Typ av utgift", "Datum för utgift", "Kostnad", "Har kvitto", "Antal mil"]),
    overview: new Set([
      "Kategori",
      "Status",
      "Försäkringsärenden",
      "Ärende skapades",
      "Skapad av",
      "Skapat av",
      "Ärende skapades av",
      "Ärende blev redo",
      "Fullmakt",
      "Kundens Mina Sidor"
    ]),
    employment: new Set([
      "Sysselsättning",
      "Arbetsgivare",
      "Medlem i fack",
      "Detaljer",
      // Some CRM variants show school-related fields under the Employment card.
      "Skola",
      "Skolans adress",
      "Skoladress",
      "Skolans postadress",
      "Skolans gatuadress",
      "Skolans postnummer och ort",
      "Verksamhetens adress",
      "Adress till skolan",
      "Utbildningsnivå",
      "Skolans försäkringstagare",
      "Besöksadress"
    ]),
    sickLeave: new Set(["Status", "Datum", "Procent", "Årsinkomst"])
  };

  const IGNORE_LABELS_BY_CARD_ID = {
    "overview-card": new Set(["Gå till kort"]),
    "incident-case-card": new Set(["Gå till kort"]),
    "claimant-card": new Set(["Gå till kort"]),
    "customer-card": new Set(["Gå till kort"]),
    "treatments-case-card": new Set(["Gå till kort"]),
    "visited-healthcare-providers-card": new Set(["Gå till kort"]),
    "expenses-case-card": new Set(["Gå till kort"]),
    "residual-issues-case-card": new Set(["Gå till kort"]),
    // CRM uses "-case-card" ids; keep both keys to avoid unmapped noise when the fallback id is used.
    "sick-leave-case-card": new Set(["Gå till kort", "Begär läkarintyg"]),
    "sick-leave-card": new Set(["Gå till kort", "Begär läkarintyg"])
  };

  const IGNORE_LABELS_BY_CARD_TITLE = {
    Översikt: new Set(["Gå till kort"])
  };

  const IGNORE_LABEL_PATTERNS = [/^Gå till kort$/i, /^Visa kundens Mina Sidor/i];
  const INSURANCE_IGNORE_PATTERNS = [
    /^Övertagande ej anmält$/i,
    /^Skada ej anmäld$/i,
    /^Anmält skada$/i,
    /^Kvarstående besvär är redo$/i,
    /^\d+\s+utbetalning registrerad$/i,
    /^Gå till kort$/i
  ];

  const UI_TEXT_BLACKLIST = new Set(["Kopiera till urklipp", "Redigera"]);
  const INSURANCE_CARD_HEADER_SKIP_PATTERNS = [
    /^Tillagd av systemet$/i,
    /^Bekräftat skadeanmälan$/i,
    /^Försäkringsförfrågan$/i,
    /^Skadeanmälan\/Övertagande\/Komplettering$/i,
    /^Fyll i skadeanmälan till\b/i,
    /^Obs\./i,
    /^Bekräfta$/i
  ];
  const INSURANCE_CARD_NUMBER_LABEL = "Ärendenummer hos försäkringsbolaget";

  function normalizeInline(text) {
    return String(text ?? "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizePreserveNewlines(text) {
    const helper = root.__crmTextCleaning?.normalizePreserveNewlines;
    if (typeof helper === "function") {
      return helper(text, { dropUiLines: true });
    }

    const lines = String(text ?? "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .split("\n")
      .map((line) => line.replace(/[ \t\u00a0]+/g, " ").trim())
      .filter((line) => line.length > 0);

    return lines.join("\n").trim();
  }

  function buildValuePreview(value, maxLength = 180) {
    const raw = String(value ?? "");
    if (!raw) return { valuePreview: null, valueLength: 0, truncated: false };
    const normalized = normalizePreserveNewlines(raw);
    if (normalized.length <= maxLength) {
      return { valuePreview: normalized, valueLength: normalized.length, truncated: false };
    }
    return {
      valuePreview: normalized.slice(0, maxLength) + "…",
      valueLength: normalized.length,
      truncated: true
    };
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function cleanText(text, { stopMarkers = [], stripUi = true, cardId = null } = {}) {
    const cleaner = root.__crmTextCleaning?.cleanCollectorText;
    if (typeof cleaner === "function") {
      return cleaner(text, { stopMarkers, stripUi, cardId });
    }

    let raw = String(text ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    for (const marker of Array.isArray(stopMarkers) ? stopMarkers : []) {
      const markerText = String(marker ?? "").trim().toLowerCase();
      const lines = raw.split("\n");
      const idx = lines.findIndex((line) => {
        const trimmed = String(line ?? "").trim();
        if (!trimmed) return false;
        if (markerText === "* * *") return /^\*\s*\*\s*\*$/.test(trimmed);
        const lower = trimmed.toLowerCase();
        return lower === markerText || lower.startsWith(`${markerText} `);
      });
      if (idx !== -1) raw = lines.slice(0, idx).join("\n");
    }
    return normalizePreserveNewlines(raw);
  }

  function caseNumberFromUrl(url) {
    try {
      const parsed = new URL(url);
      const parts = parsed.pathname.split("/").filter(Boolean);
      const idx = parts.indexOf("case");
      if (idx === -1) return null;
      return parts[idx + 1] || null;
    } catch {
      return null;
    }
  }

  function safeParseJsonLike(raw) {
    const value = String(raw ?? "").trim();
    if (!value) return null;

    try {
      return JSON.parse(value);
    } catch {
      // Try a controlled single-quote to double-quote transform.
      try {
        const normalized = value.replace(/'([^']*)'/g, (_, inner) => {
          const escaped = String(inner ?? "").replace(/\\/g, "\\\\").replace(/\"/g, '\\"');
          return `"${escaped}"`;
        });
        return JSON.parse(normalized);
      } catch {
        return null;
      }
    }
  }

  function parseSwedishDateTime(text) {
    const raw = normalizeInline(text);
    if (!raw) return { date: null, time: null };

    const dateMatch = raw.match(/\b\d{4}-\d{2}-\d{2}\b/);
    const timeMatch = raw.match(/\b\d{2}:\d{2}\b/);

    return {
      date: dateMatch ? dateMatch[0] : null,
      time: timeMatch ? timeMatch[0] : null
    };
  }

  function parseDateOrInterval(text) {
    const raw = normalizeInline(text);
    if (!raw) return { date: null, dateFrom: null, dateTo: null };

    const dates = raw.match(/\b\d{4}-\d{2}-\d{2}\b/g) || [];
    if (dates.length >= 2) {
      return { date: null, dateFrom: dates[0], dateTo: dates[1] };
    }
    if (dates.length === 1) {
      return { date: dates[0], dateFrom: null, dateTo: null };
    }
    return { date: null, dateFrom: null, dateTo: null };
  }

  function normalizeIsoDate(value) {
    const raw = normalizeInline(value);
    if (!raw) return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(raw) ? raw : null;
  }

  function foldSwedishText(value) {
    return normalizeInline(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  }

  function normalizeGridCellValue(text) {
    const raw = normalizeInline(text);
    if (!raw) return null;
    if (raw === "-" || /^Vet\s+ej$/i.test(raw)) return null;
    return raw;
  }

  function normalizeVisitReason(text) {
    const raw = normalizeGridCellValue(text);
    if (!raw) return null;
    // In CRM grids, "Första vårdbesöket" can appear as a marker in the reason column.
    // The canonical first-visit signal is visits[].isFirstVisit, so keep reason clean.
    if (/^Första\s+vårdbesöket$/i.test(raw)) return null;
    return raw;
  }

  function parseMoney(text) {
    const raw = normalizeInline(text);
    if (!raw) return { amount: null, currency: null };

    const numberMatch = raw.match(/\d+[\d\s\u00a0,.]*/);
    if (!numberMatch) return { amount: null, currency: null };

    const numeric = numberMatch[0]
      .replace(/[\s\u00a0]/g, "")
      .replace(/\.(?=\d{3}\b)/g, "")
      .replace(/,(?=\d{3}\b)/g, "")
      .replace(/,/g, ".");

    const amount = Number(numeric);
    if (!Number.isFinite(amount)) return { amount: null, currency: null };

    const currency = /SEK|kr/i.test(raw) ? "SEK" : "SEK";
    return { amount, currency };
  }

  function toBool(text) {
    const raw = foldSwedishText(text);
    if (!raw) return null;
    if (/^ja\b/.test(raw)) return true;
    if (/^nej\b/.test(raw)) return false;
    if (/^(inte|ej)\b/.test(raw)) return false;
    if (/^(inga|ingen|inget)\b/.test(raw)) return false;
    return null;
  }

  function isPreviousInjuryDateQaRow(qaKey, previousQaKey) {
    return qaKey === "vid ja datum" &&
      String(previousQaKey || "").includes("skadad kroppsdel tidigare varit utsatt");
  }

  function splitListValue(value) {
    const raw = normalizePreserveNewlines(value);
    if (!raw) return [];
    const lines = raw.split("\n").map((line) => line.trim()).filter(Boolean);
    return lines.length > 0 ? lines : [];
  }

  function applySchoolFieldRow(current, row) {
    const school = current || {
      name: null,
      educationLevel: null,
      policyholder: null,
      address: null,
      streetAddress: null,
      postalAddress: null,
      postalCode: null,
      city: null
    };
    const value = row?.value || null;
    switch (row?.label) {
      case "Skola":
        school.name = value;
        break;
      case "Utbildningsnivå":
        school.educationLevel = value;
        break;
      case "Skolans försäkringstagare":
        school.policyholder = value;
        break;
      case "Skolans adress":
      case "Skoladress":
      case "Skolans postadress":
      case "Verksamhetens adress":
      case "Adress till skolan":
      case "Besöksadress":
        school.address = value;
        if (value) {
          const parts = String(value).split(",").map((part) => part.trim()).filter(Boolean);
          const postalMatch = String(value).match(/\b(\d{3})\s?(\d{2})\b/);
          if (parts.length >= 2) school.streetAddress = parts[0] || school.streetAddress;
          if (postalMatch) school.postalCode = `${postalMatch[1]}${postalMatch[2]}`;
          if (parts.length >= 3) school.city = parts[parts.length - 1] || school.city;
          if (postalMatch) {
            const afterPostal = String(value).slice((postalMatch.index || 0) + postalMatch[0].length).replace(/^[,\s]+/, "").trim();
            if (afterPostal) school.city = afterPostal;
            school.postalAddress = [school.postalCode, school.city].filter(Boolean).join(" ");
          }
        }
        break;
      case "Skolans gatuadress":
        school.streetAddress = value;
        break;
      case "Skolans postnummer och ort":
        school.postalAddress = value;
        break;
    }
    return school;
  }

  function extractPrimaryInjuryHeadings(valueEl, fallbackValue) {
    const uniqueHeadings = [];
    const seen = new Set();
    const push = (raw) => {
      const text = normalizeInline(raw);
      if (!text || text === "Kroppsskador" || seen.has(text)) return false;
      seen.add(text);
      uniqueHeadings.push(text);
      return true;
    };

    if (valueEl) {
      // Preferred: only pick entries that have their own copy button in the injuries list.
      const copyButtons = Array.from(valueEl.querySelectorAll('[title="Kopiera till urklipp"]'));
      for (const button of copyButtons) {
        const directRow = button.closest(".hc.spacing-8-8.s.r.wc.cl.ccy");
        if (directRow) {
          const directText = directRow.textContent || "";
          if (normalizeInline(directText)) {
            push(directText);
            continue;
          }

          const heading = directRow.querySelector(".s.t.wc.hc");
          if (heading) {
            push(heading.textContent || "");
            continue;
          }
        }

        // Fallback traversal for minor CRM DOM variations.
        let parent = button.parentElement;
        while (parent && parent !== valueEl) {
          const heading = parent.querySelector(".s.t.wc.hc");
          if (heading) {
            push(heading.textContent || "");
            break;
          }
          parent = parent.parentElement;
        }
      }

      if (uniqueHeadings.length > 0) return uniqueHeadings;
    }

    return splitListValue(fallbackValue);
  }

  function extractKnownInjuryConsequences(value) {
    const text = normalizeInline(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
    const consequences = [];
    if (/sarskada|\bsar\b/.test(text)) consequences.push("Sårskada");
    if (/mjukdel|muskel|sena|menisk|korsband|ligament|ruptur|kontusion|svullnad|blamarke/.test(text)) consequences.push("Mjukdelsskada");
    if (/stukning|vrickning|strackning/.test(text)) consequences.push("Stukning");
    if (/ur led|luxation|dislokation/.test(text)) consequences.push("Urledvridning");
    if (/spricka/.test(text)) consequences.push("Spricka");
    if (/fraktur|brott|brutet|bruten|brutna|brutit/.test(text)) consequences.push("Fraktur");
    if (/kross/.test(text)) consequences.push("Kross-skada");
    return [...new Set(consequences)];
  }

  function classifyInjuryDetailEvidence(detailTexts) {
    const details = (Array.isArray(detailTexts) ? detailTexts : [])
      .map((value) => normalizeInline(value))
      .filter(Boolean);
    const consequences = [...new Set(details.flatMap(extractKnownInjuryConsequences))];
    const unclassified = details.filter((value) => extractKnownInjuryConsequences(value).length === 0);
    return {
      consequences,
      complete: unclassified.length === 0,
      unclassifiedCount: unclassified.length
    };
  }

  function assessInjuryConsequenceSources(primaryHeadings, rawValue, explicitDetailTexts) {
    const consequenceSourceTexts = [...new Set([
      ...splitListValue(rawValue || ""),
      ...(Array.isArray(explicitDetailTexts) ? explicitDetailTexts : [])
    ].map(normalizeInline).filter(Boolean))];
    const assessment = classifyInjuryDetailEvidence(consequenceSourceTexts);
    return {
      consequencesEvidence: assessment.consequences,
      consequencesEvidenceComplete: consequenceSourceTexts.length > 0 && assessment.complete,
      consequenceSourceTexts,
      primaryHeadings: (Array.isArray(primaryHeadings) ? primaryHeadings : []).map(normalizeInline).filter(Boolean)
    };
  }

  function extractInjuryDetailTextsFromCardText(rawText, primaryHeadings) {
    const lines = normalizePreserveNewlines(rawText)
      .split("\n")
      .map(normalizeInline)
      .filter(Boolean);
    const bodyIndex = lines.findIndex((line) => normalizeQaLabel(line) === "kroppsskador");
    if (bodyIndex < 0) return [];
    const primary = new Set((Array.isArray(primaryHeadings) ? primaryHeadings : []).map(normalizeInline));
    const details = [];
    for (const line of lines.slice(bodyIndex + 1)) {
      const key = normalizeQaLabel(line);
      if (key === "fragor svar" || key.startsWith("fragor svar ")) break;
      if (!line || primary.has(line) || /^kopiera till urklipp$/i.test(line)) continue;
      if (!details.includes(line)) details.push(line);
    }
    return details;
  }

  function extractInjuryDetailTextsFromValueElement(valueEl, primaryHeadings) {
    if (!valueEl?.querySelectorAll) return [];
    const primary = new Set(
      (Array.isArray(primaryHeadings) ? primaryHeadings : [])
        .map(normalizeInline)
        .filter(Boolean)
    );
    const details = [];
    const push = (raw) => {
      const text = normalizeInline(raw);
      if (!text || primary.has(text) || UI_TEXT_BLACKLIST.has(text)) return;
      if (/^(?:Kopiera till urklipp|Redigera)$/i.test(text)) return;
      if (!details.includes(text)) details.push(text);
    };

    // Current CRM injury DOM (observed 2026-09-03): the primary injury is a
    // pre-wrap <span>, while its human-readable detail rows are plain
    // `.s.t.wc.hc` divs, e.g. "Bruten hand" and "Spricka i hand". Older DOM
    // variants used list items/data attributes, so keep both sources.
    for (const element of Array.from(
      valueEl.querySelectorAll(".s.t.wc.hc,li,[role='listitem'],[data-injury-detail]") || []
    )) {
      push(element?.textContent || element?.innerText || "");
    }
    return details;
  }

  function findExactLabelValuePairs(labelText, rootNode = document) {
    if (!rootNode?.querySelectorAll) return [];
    const target = normalizeInline(labelText);
    if (!target) return [];
    const pairs = [];
    for (const labelEl of Array.from(rootNode.querySelectorAll(".width-fill-4") || [])) {
      if (normalizeInline(labelEl?.textContent || labelEl?.innerText || "") !== target) continue;
      let ancestor = labelEl;
      for (let depth = 0; depth < 14; depth += 1) {
        ancestor = ancestor?.parentElement;
        if (!ancestor) break;
        const labels = Array.from(ancestor.querySelectorAll?.(".width-fill-4") || []);
        const values = Array.from(ancestor.querySelectorAll?.(".width-fill-8") || []);
        if (labels.length === 1 && labels[0] === labelEl && values.length >= 1) {
          pairs.push({ labelEl, rowEl: ancestor, valueEl: values[0] });
          break;
        }
      }
    }
    return pairs;
  }

  function findInjuryLabelValuePair(labelText) {
    const pairs = findExactLabelValuePairs(labelText, document);
    if (pairs.length === 0) return null;
    if (pairs.length === 1) return pairs[0];

    // Prefer the exact row that lives inside an ancestor containing the injury
    // section heading. The real CRM card has no stable card id/class, so this
    // deliberately uses semantic ancestry rather than a brittle card selector.
    const headingText = "Skador i samband med händelse";
    const contextual = pairs.filter(({ rowEl }) => {
      let ancestor = rowEl;
      for (let depth = 0; depth < 16; depth += 1) {
        if (!ancestor) break;
        const headings = Array.from(
          ancestor.querySelectorAll?.("h1,h2,h3,h4,h5,h6,[role='heading'],[aria-level],.s.t.wc.hc") || []
        );
        if (headings.some((node) => normalizeInline(node?.textContent || node?.innerText || "") === headingText)) {
          return true;
        }
        ancestor = ancestor.parentElement;
      }
      return false;
    });
    return contextual.length === 1 ? contextual[0] : null;
  }

  function getCompleteInjuryCardText(cardRoot, primaryHeadings = []) {
    if (!cardRoot) return "";
    const visible = normalizePreserveNewlines(cardRoot.innerText || "");
    const complete = normalizePreserveNewlines(cardRoot.textContent || "");
    // CRM has two observed DOM shapes:
    // 1) hidden/collapsed details exist only in textContent;
    // 2) textContent collapses block boundaries while innerText preserves the
    //    line-separated injury list. Choose the representation that yields
    //    the most bounded detail rows instead of blindly preferring one API.
    const candidates = [visible, complete].filter(Boolean);
    if (candidates.length <= 1) return candidates[0] || "";
    return candidates
      .map((text, index) => ({
        text,
        index,
        detailCount: extractInjuryDetailTextsFromCardText(text, primaryHeadings).length
      }))
      .sort((a, b) => b.detailCount - a.detailCount || a.index - b.index)[0].text;
  }

  function splitInsuranceLines(rawText) {
    if (!rawText) return [];
    let text = normalizePreserveNewlines(rawText);
    if (!text) return [];

    let lines = text.split("\n").map((line) => line.trim()).filter(Boolean);

    if (lines.length === 1) {
      const noiseTokens = [
        "Skada ej anmäld",
        "Övertagande ej anmält",
        "Gå till kort",
        "Anmält skada",
        "Kvarstående besvär är redo"
      ];
      let expanded = lines[0];
      for (const token of noiseTokens) {
        expanded = expanded.replace(new RegExp(token, "gi"), `\n${token}\n`);
      }
      lines = expanded.split("\n").map((line) => line.trim()).filter(Boolean);
    }

    return lines;
  }

  function isInsuranceStatusLine(line) {
    const value = normalizeInline(line);
    if (!value) return false;
    return (
      /Övertagande ej anmält/i.test(value) ||
      /Skada ej anmäld/i.test(value) ||
      /Anmält skada/i.test(value) ||
      /Kvarstående besvär är redo/i.test(value) ||
      /utbetalning registrerad/i.test(value)
    );
  }

  function deriveInsuranceStateKind(stateTitle, iconHref) {
    const title = normalizeInline(stateTitle);
    if (/^Avfärdat\b/i.test(title)) return "dismissed";
    if (/^Ej påbörjat$/i.test(title)) return "not_started";
    if (/^Pågående$/i.test(title)) return "active";

    const href = normalizeInline(iconHref);
    if (/#ac$/i.test(href)) return "dismissed";
    if (/#ah$/i.test(href)) return "not_started";
    if (/#ag$/i.test(href)) return "active";
    return "unknown";
  }

  function extractInsuranceEntriesFromDom(insuranceEl) {
    if (!insuranceEl || typeof insuranceEl.querySelectorAll !== "function") return [];

    const iconEls = Array.from(insuranceEl.querySelectorAll("[title]")).filter((el) => {
      const title = typeof el?.getAttribute === "function" ? el.getAttribute("title") || "" : "";
      return /^Pågående$/i.test(title) || /^Ej påbörjat$/i.test(title) || /^Avfärdat\b/i.test(title);
    });
    if (iconEls.length === 0) return [];

    const seenRows = new Set();
    const entries = [];

    for (const iconEl of iconEls) {
      const rowEl = iconEl?.parentElement || null;
      if (!rowEl || seenRows.has(rowEl)) continue;
      seenRows.add(rowEl);

      const rowRaw = rowEl.innerText || rowEl.textContent || "";
      const lines = splitInsuranceLines(rowRaw);
      const displayName = lines.find((line) => line.includes(" - ")) || null;
      if (!displayName) continue;

      const statusText = lines.find((line) => isInsuranceStatusLine(line)) || null;
      const stateTitle = typeof iconEl?.getAttribute === "function" ? iconEl.getAttribute("title") || null : null;
      const useEl = typeof iconEl?.querySelector === "function" ? iconEl.querySelector("use") : null;
      const iconHref = useEl?.getAttribute?.("href") || useEl?.getAttribute?.("xlink:href") || null;

      entries.push({
        displayName,
        statusText,
        stateTitle,
        stateKind: deriveInsuranceStateKind(stateTitle, iconHref)
      });
    }

    return entries;
  }

  function extractInsuranceEntries(insuranceEl, insuranceRaw) {
    const domEntries = extractInsuranceEntriesFromDom(insuranceEl);
    if (domEntries.length > 0) return domEntries;

    const raw = insuranceEl ? insuranceEl.innerText || insuranceEl.textContent || "" : insuranceRaw || "";
    const lines = splitInsuranceLines(raw);
    if (lines.length === 0) return [];

    const entries = [];
    let current = null;

    for (const line of lines) {
      if (line.includes(" - ")) {
        if (current?.displayName) entries.push(current);
        current = { displayName: line, statusText: null, stateTitle: null, stateKind: "unknown" };
        continue;
      }

      if (!current) continue;
      if (/^Gå till kort$/i.test(line)) continue;
      if (!current.statusText && isInsuranceStatusLine(line)) {
        current.statusText = line;
      }
    }

    if (current?.displayName) entries.push(current);
    return entries;
  }

  function extractInsuranceDisplayName(insuranceEl, insuranceRaw) {
    const entries = extractInsuranceEntries(insuranceEl, insuranceRaw);
    if (entries.length === 0) return { displayName: null, displayNames: [], entries: [] };

    const displayNames = [];
    for (const entry of entries) {
      if (displayNames.includes(entry.displayName)) continue;
      displayNames.push(entry.displayName);
    }

    return {
      displayName: displayNames[0] || null,
      displayNames,
      entries
    };
  }

  function isInsuranceCardHeaderSkipLine(line) {
    const value = normalizeInline(line);
    if (!value) return true;
    if (UI_TEXT_BLACKLIST.has(value)) return true;
    if (isInsuranceStatusLine(value)) return true;
    return INSURANCE_CARD_HEADER_SKIP_PATTERNS.some((pattern) => pattern.test(value));
  }

  function extractInsuranceCardFromText(rawText, links = []) {
    const lines = normalizePreserveNewlines(rawText)
      .split("\n")
      .map((line) => normalizeInline(line))
      .filter((line) => line.length > 0);

    if (lines.length === 0) return null;

    const headerLines = [];
    for (const line of lines) {
      if (isInsuranceCardHeaderSkipLine(line)) continue;
      headerLines.push(line);
      if (headerLines.length >= 2) break;
    }

    const insurer = headerLines[0] || null;
    const product = headerLines[1] || null;
    const displayName =
      insurer && product ? `${insurer} - ${product}` : insurer || product || null;

    let claimNumber = null;
    const claimLabelIndex = lines.findIndex((line) => line === INSURANCE_CARD_NUMBER_LABEL);
    if (claimLabelIndex >= 0) {
      for (let index = claimLabelIndex + 1; index < lines.length; index += 1) {
        const candidate = lines[index];
        if (!candidate || candidate === INSURANCE_CARD_NUMBER_LABEL) continue;
        if (UI_TEXT_BLACKLIST.has(candidate)) continue;
        if (/^Fyll i skadeanmälan till\b/i.test(candidate)) continue;
        claimNumber = candidate;
        break;
      }
    }

    const normalizedLinks = Array.isArray(links)
      ? links
          .map((link) => ({
            href: typeof link?.href === "string" ? link.href : null,
            text: normalizeInline(link?.textContent || "")
          }))
          .filter((link) => link.href)
      : [];

    const claimLink =
      normalizedLinks.find((link) => /insurance-claim|anmalanolf-ombud/i.test(link.href || ""))?.href || null;
    const inquiryLink =
      normalizedLinks.find((link) => /insurance-inquiry-form/i.test(link.href || ""))?.href || null;

    if (!displayName && !claimNumber && !claimLink && !inquiryLink) return null;

    return {
      insurer,
      product,
      displayName,
      claimNumber,
      claimLink,
      inquiryLink
    };
  }

  function looksLikeInsuranceCardRoot(cardRoot) {
    if (!cardRoot) return false;
    const rawText = cardRoot.innerText || cardRoot.textContent || "";
    const text = normalizePreserveNewlines(rawText);
    if (!text) return false;
    return (
      text.includes(INSURANCE_CARD_NUMBER_LABEL) ||
      /Försäkringsförfrågan/i.test(text) ||
      /Skadeanmälan\/Övertagande\/Komplettering/i.test(text) ||
      /Fyll i skadeanmälan till\b/i.test(text)
    );
  }

  function findInsuranceCardRoots() {
    const roots = new Set();
    const seedSelectors = [
      `a[href*="insurance-claim"]`,
      `a[href*="insurance-inquiry-form"]`,
      `a[href*="anmalanolf-ombud"]`
    ];

    const seeds = [];
    for (const selector of seedSelectors) {
      for (const node of document.querySelectorAll(selector)) {
        seeds.push(node);
      }
    }

    const numberLabels = Array.from(document.querySelectorAll("div, span, p, strong")).filter(
      (node) => normalizeInline(node.textContent) === INSURANCE_CARD_NUMBER_LABEL
    );
    seeds.push(...numberLabels);

    for (const seed of seeds) {
      let current =
        typeof seed?.closest === "function" ? seed.closest(".hf.s.c.wf.ct.cl") : null;
      while (current) {
        if (looksLikeInsuranceCardRoot(current)) {
          roots.add(current);
          break;
        }
        current = current.parentElement?.closest?.(".hf.s.c.wf.ct.cl") || null;
      }
    }

    return Array.from(roots);
  }

  function extractInsuranceCards() {
    const roots = findInsuranceCardRoots();
    const cards = [];

    for (const rootEl of roots) {
      const card = extractInsuranceCardFromText(
        rootEl.innerText || rootEl.textContent || "",
        Array.from(rootEl.querySelectorAll("a[href]"))
      );
      if (!card) continue;
      cards.push(card);
    }

    return cards;
  }

  function parseSelfDeclarationSignedAt(text) {
    const raw = normalizeInline(text);
    const match = raw.match(/\b(\d{4}-\d{2}-\d{2})(?:\s+kl\.?\s*(\d{1,2}:\d{2}))?\b/i);
    if (!match) return null;
    return match[2] ? `${match[1]} ${match[2]}` : match[1];
  }

  function extractSelfDeclarationPdfInfoFromText(rawText, href) {
    const lines = normalizePreserveNewlines(rawText)
      .split("\n")
      .map((line) => normalizeInline(line))
      .filter(Boolean)
      .filter((line) => !UI_TEXT_BLACKLIST.has(line));

    const linkLineIndex = lines.findIndex((line) => /^Underskrivet\b/i.test(line) || /Egenintyg/i.test(line));
    const title = lines.find((line) => /^Underskrivet\b/i.test(line)) || lines[linkLineIndex] || null;
    const signedLine = lines.find((line) => /Ifyllt och underskrivet/i.test(line)) || null;
    const insurerFromTitle = title?.match(/till\s+(.+)$/i)?.[1] || null;

    let bodyPart = null;
    for (let index = Math.max(0, linkLineIndex - 4); index < (linkLineIndex >= 0 ? linkLineIndex : lines.length); index += 1) {
      const candidate = lines[index];
      if (!candidate) continue;
      if (/Egenintyg|Ifyllt|Underskrivet|Trygg[-\s]?Hansa/i.test(candidate)) continue;
      bodyPart = candidate;
      break;
    }

    const filenameMatch = String(href || "").match(/filename=([^&#]+)/i);
    const filename = filenameMatch ? decodeURIComponent(filenameMatch[1].replace(/\+/g, " ")) : null;

    return {
      href: href || null,
      label: title,
      title: filename || title,
      bodyPart,
      insurer: insurerFromTitle,
      signedAt: parseSelfDeclarationSignedAt(signedLine || rawText)
    };
  }

  function extractSelfDeclarationPdfs() {
    const cardRoot = document.querySelector("#self-declarations-card") || findCardByHeadingText("Egenintyg");
    if (!cardRoot) return [];

    const links = Array.from(cardRoot.querySelectorAll("a[href]")).filter((link) => {
      const text = normalizeInline(link.textContent || "");
      const href = String(link.href || "");
      if (/^Ej\s+underskrivet/i.test(text)) return false;
      return /Underskrivet|Egenintyg|self-declaration|signed-documents/i.test(`${text} ${href}`);
    });

    const seen = new Set();
    const result = [];
    for (const link of links) {
      const href = link.href || link.getAttribute?.("href") || "";
      if (!href || seen.has(href)) continue;
      seen.add(href);

      const block =
        link.closest?.('[id^="self-declarations-card-"]') ||
        link.closest?.(".bg-246-249-253-255") ||
        link.parentElement ||
        cardRoot;
      const info = extractSelfDeclarationPdfInfoFromText(block?.innerText || block?.textContent || link.textContent || "", href);
      if (info.href || info.label || info.title) result.push(info);
    }

    return result;
  }

  function parseMiles(value) {
    const raw = normalizeInline(value);
    if (!raw) return null;
    const match = raw.match(/\d+/);
    if (!match) return null;
    const parsed = Number(match[0]);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function parsePercentMax(value) {
    const raw = normalizeInline(value);
    if (!raw) return null;
    const match = raw.match(/(\d{1,3})\s*%/);
    const fallback = match ? null : raw.match(/\d{1,3}/);
    const num = Number(match ? match[1] : fallback ? fallback[0] : NaN);
    return Number.isFinite(num) ? num : null;
  }

  function normalizePersonNumber(value) {
    const raw = normalizeInline(value);
    if (!raw) return null;

    const digits = raw.replace(/\D/g, "");
    if (digits.length === 12) return `${digits.slice(0, 8)}-${digits.slice(8)}`;
    if (digits.length === 10) return `${digits.slice(0, 6)}-${digits.slice(6)}`;
    return raw;
  }

  function initCanonical({ caseId, caseNumber, url }) {
    return {
      meta: {
        caseId: caseId ?? null,
        caseNumber: caseNumber ?? null,
        url: url ?? null,
        collectedAt: new Date().toISOString(),
        category: null,
        status: null,
        insuranceMatter: {
          displayName: null,
          displayNames: [],
          entries: [],
          cards: [],
          sourceStatus: "MISSING",
          insurer: null,
          product: null
        },
        createdByName: null,
        createdAt: null,
        readyAt: null,
        powerOfAttorneyPdfUrl: null,
        customerPortalUrl: null,
        selfDeclarationPdfs: []
      },
      // CRM "Kund" (often the reporter/guardian). This can be the same as claimant, but not always.
      customer: {
        name: null,
        personNumber: null,
        email: null
      },
      reporter: {
        name: null,
        personNumber: null,
        email: null,
        relationship: null,
        source: null
      },
      claimant: {
        name: null,
        personNumber: null,
        email: null,
        ageAtIncident: null,
        municipality: null
      },
      employment: {
        employmentStatus: null,
        employer: null,
        unionMemberText: null,
        details: null
      },
      incident: {
        context: null,
        country: null,
        abroad: null,
        date: null,
        time: null,
        place: null,
        description: null,
        customerAdditionalInfo: null,
        supplements: null,
        hasDoctorVisit: null,
        firstDoctorName: null,
        gipsed: null,
        gipsWeeks: null,
        schoolTransportOrdered: null,
        hospitalized: null,
        hospitalizedWhere: null,
        hospitalizedFrom: null,
        hospitalizedTo: null,
        policeReported: null,
        previousInjuryHad: null,
        previousInjuryDate: null,
        previousInjuryDoctorConsulted: null,
        previousInjuries: null,
        intoxicatedAtAccident: null,
        school: null,
        sport: {
          sportType: null,
          club: null,
          league: null,
          trainingFacility: null,
          role: null,
          athleteType: null
        }
      },
      injuries: {
        bodyInjuries: [],
        residualIssues: [],
        consequencesEvidence: [],
        consequencesEvidenceComplete: null,
        consequenceSourceTexts: []
      },
      care: {
        journalCoverSheetUrl: null,
        additionalProvidersReportedCount: null,
        providers: []
      },
      treatments: {
        performed: [],
        planned: {
          status: null,
          details: null,
          followUpDate: null
        }
      },
      sickLeave: {
        hasSickLeave: null,
        statusText: null,
        date: null,
        dateFrom: null,
        dateTo: null,
        maxPercent: null,
        percentText: null,
        annualIncome: { amount: null, currency: "SEK" }
      },
      expenses: [],
      expensesMeta: {
        carTravelMiles: null,
        sourceStatus: null
      },
      vehicle: {
        involved: null,
        details: null,
        registrationNumber: null,
        crmType: null,
        tags: [],
        personInVehicle: null,
        isDriver: null,
        policeReported: null
      },
      otherAccidentInsurance: {
        hasOther: null,
        insurer: null,
        type: null,
        reported: null,
        claimNumber: null
      }
    };
  }

  function pruneCanonical(canonical) {
    const base = initCanonical({
      caseId: canonical?.meta?.caseId ?? null,
      caseNumber: canonical?.meta?.caseNumber ?? null,
      url: canonical?.meta?.url ?? null
    });

    return {
      meta: {
        ...base.meta,
        collectedAt: canonical?.meta?.collectedAt ?? base.meta.collectedAt,
        category: canonical?.meta?.category ?? base.meta.category,
        status: canonical?.meta?.status ?? null,
        insuranceMatter: {
          displayName: canonical?.meta?.insuranceMatter?.displayName ?? null,
          displayNames: Array.isArray(canonical?.meta?.insuranceMatter?.displayNames)
            ? canonical.meta.insuranceMatter.displayNames
            : [],
          entries: Array.isArray(canonical?.meta?.insuranceMatter?.entries)
            ? canonical.meta.insuranceMatter.entries
                .map((entry) => ({
                  displayName: entry?.displayName ?? null,
                  statusText: entry?.statusText ?? null,
                  stateTitle: entry?.stateTitle ?? null,
                  stateKind: entry?.stateKind ?? "unknown"
                }))
                .filter((entry) => typeof entry.displayName === "string" && entry.displayName.trim())
            : [],
          cards: Array.isArray(canonical?.meta?.insuranceMatter?.cards)
            ? canonical.meta.insuranceMatter.cards
                .map((card) => ({
                  insurer: card?.insurer ?? null,
                  product: card?.product ?? null,
                  displayName: card?.displayName ?? null,
                  claimNumber: card?.claimNumber ?? null,
                  claimLink: card?.claimLink ?? null,
                  inquiryLink: card?.inquiryLink ?? null
                }))
                .filter((card) => card.displayName || card.claimNumber || card.claimLink || card.inquiryLink)
            : [],
          sourceStatus: canonical?.meta?.insuranceMatter?.sourceStatus ?? "MISSING",
          insurer: canonical?.meta?.insuranceMatter?.insurer ?? null,
          product: canonical?.meta?.insuranceMatter?.product ?? null
        },
        createdByName: canonical?.meta?.createdByName ?? null,
        createdAt: canonical?.meta?.createdAt ?? null,
        readyAt: canonical?.meta?.readyAt ?? null,
        powerOfAttorneyPdfUrl: canonical?.meta?.powerOfAttorneyPdfUrl ?? null,
        customerPortalUrl: canonical?.meta?.customerPortalUrl ?? null,
        selfDeclarationPdfs: Array.isArray(canonical?.meta?.selfDeclarationPdfs)
          ? canonical.meta.selfDeclarationPdfs
              .map((item) => ({
                href: item?.href ?? null,
                label: item?.label ?? null,
                title: item?.title ?? null,
                bodyPart: item?.bodyPart ?? null,
                insurer: item?.insurer ?? null,
                signedAt: item?.signedAt ?? null
              }))
              .filter((item) => item.href || item.label || item.title)
          : []
      },
      customer: {
        name: canonical?.customer?.name ?? null,
        personNumber: canonical?.customer?.personNumber ?? null,
        email: canonical?.customer?.email ?? null
      },
      reporter: {
        name: canonical?.reporter?.name ?? null,
        personNumber: canonical?.reporter?.personNumber ?? null,
        email: canonical?.reporter?.email ?? null,
        relationship: canonical?.reporter?.relationship ?? null,
        source: canonical?.reporter?.source ?? null
      },
      claimant: {
        name: canonical?.claimant?.name ?? null,
        personNumber: canonical?.claimant?.personNumber ?? null,
        email: canonical?.claimant?.email ?? null,
        ageAtIncident: canonical?.claimant?.ageAtIncident ?? null,
        municipality: canonical?.claimant?.municipality ?? null
      },
      employment: {
        employmentStatus: canonical?.employment?.employmentStatus ?? null,
        employer: canonical?.employment?.employer ?? null,
        unionMemberText: canonical?.employment?.unionMemberText ?? null,
        details: canonical?.employment?.details ?? null
      },
      incident: {
        context: canonical?.incident?.context ?? null,
        country: canonical?.incident?.country ?? null,
        abroad: canonical?.incident?.abroad ?? null,
        date: canonical?.incident?.date ?? null,
        time: canonical?.incident?.time ?? null,
        place: canonical?.incident?.place ?? null,
        description: canonical?.incident?.description ?? null,
        customerAdditionalInfo: canonical?.incident?.customerAdditionalInfo ?? null,
        supplements: canonical?.incident?.supplements ?? null,
        hasDoctorVisit: canonical?.incident?.hasDoctorVisit ?? null,
        firstDoctorName: canonical?.incident?.firstDoctorName ?? null,
        gipsed: canonical?.incident?.gipsed ?? null,
        gipsWeeks: canonical?.incident?.gipsWeeks ?? null,
        schoolTransportOrdered: canonical?.incident?.schoolTransportOrdered ?? null,
        hospitalized: canonical?.incident?.hospitalized ?? null,
        hospitalizedWhere: canonical?.incident?.hospitalizedWhere ?? null,
        hospitalizedFrom: canonical?.incident?.hospitalizedFrom ?? null,
        hospitalizedTo: canonical?.incident?.hospitalizedTo ?? null,
        policeReported: canonical?.incident?.policeReported ?? null,
        previousInjuryHad: canonical?.incident?.previousInjuryHad ?? null,
        previousInjuryDate: canonical?.incident?.previousInjuryDate ?? null,
        previousInjuryDoctorConsulted: canonical?.incident?.previousInjuryDoctorConsulted ?? null,
        previousInjuries: canonical?.incident?.previousInjuries ?? null,
        intoxicatedAtAccident: canonical?.incident?.intoxicatedAtAccident ?? null,
        school: canonical?.incident?.school
          ? {
              name: canonical.incident.school.name ?? null,
              educationLevel: canonical.incident.school.educationLevel ?? null,
              policyholder: canonical.incident.school.policyholder ?? null,
              address: canonical.incident.school.address ?? null,
              streetAddress: canonical.incident.school.streetAddress ?? null,
              postalAddress: canonical.incident.school.postalAddress ?? null,
              postalCode: canonical.incident.school.postalCode ?? null,
              city: canonical.incident.school.city ?? null
            }
          : null,
        sport: {
          sportType: canonical?.incident?.sport?.sportType ?? null,
          club: canonical?.incident?.sport?.club ?? null,
          league: canonical?.incident?.sport?.league ?? null,
          trainingFacility: canonical?.incident?.sport?.trainingFacility ?? null,
          role: canonical?.incident?.sport?.role ?? null,
          athleteType: canonical?.incident?.sport?.athleteType ?? null
        }
      },
      injuries: {
        bodyInjuries: Array.isArray(canonical?.injuries?.bodyInjuries)
          ? canonical.injuries.bodyInjuries
          : [],
        residualIssues: Array.isArray(canonical?.injuries?.residualIssues)
          ? canonical.injuries.residualIssues
          : [],
        consequencesEvidence: Array.isArray(canonical?.injuries?.consequencesEvidence)
          ? canonical.injuries.consequencesEvidence
          : [],
        consequencesEvidenceComplete: typeof canonical?.injuries?.consequencesEvidenceComplete === "boolean"
          ? canonical.injuries.consequencesEvidenceComplete
          : null,
        consequenceSourceTexts: Array.isArray(canonical?.injuries?.consequenceSourceTexts)
          ? canonical.injuries.consequenceSourceTexts
          : []
      },
      care: {
        journalCoverSheetUrl: canonical?.care?.journalCoverSheetUrl ?? null,
        additionalProvidersReportedCount: Number.isFinite(canonical?.care?.additionalProvidersReportedCount)
          ? canonical.care.additionalProvidersReportedCount
          : null,
        providers: Array.isArray(canonical?.care?.providers)
          ? canonical.care.providers.map((provider) => ({
              providerType: provider?.providerType ?? null,
              providerName: provider?.providerName ?? null,
              source: provider?.source ?? null,
              postalAddress: provider?.postalAddress ?? null,
              journalAddress: provider?.journalAddress ?? null,
              visitAddress: provider?.visitAddress ?? null,
              addressSource: provider?.addressSource ?? null,
              healthcareProviderUrl: provider?.healthcareProviderUrl ?? null,
              healthcareSearchUrl: provider?.healthcareSearchUrl ?? null,
              visits: Array.isArray(provider?.visits)
                ? provider.visits.map((visit) => ({
                    date: visit?.date ?? null,
                    dateFrom: visit?.dateFrom ?? null,
                    dateTo: visit?.dateTo ?? null,
                    reason: visit?.reason ?? null,
                    department: visit?.department ?? null,
                    rowIndex: visit?.rowIndex ?? null,
                    isFirstVisit: visit?.isFirstVisit ?? null
                  }))
                : []
            }))
          : []
      },
      treatments: {
        performed: Array.isArray(canonical?.treatments?.performed)
          ? canonical.treatments.performed.map((treatment) => ({
              type: treatment?.type ?? null,
              date: treatment?.date ?? null,
              dateFrom: treatment?.dateFrom ?? null,
              dateTo: treatment?.dateTo ?? null,
              providerName: treatment?.providerName ?? null,
              departmentOrPerson: treatment?.departmentOrPerson ?? null
            }))
          : [],
        planned: {
          status: canonical?.treatments?.planned?.status ?? null,
          details: Array.isArray(canonical?.treatments?.planned?.details)
            ? canonical.treatments.planned.details
            : null,
          followUpDate: canonical?.treatments?.planned?.followUpDate ?? null
        }
      },
      sickLeave: {
        hasSickLeave: canonical?.sickLeave?.hasSickLeave ?? null,
        statusText: canonical?.sickLeave?.statusText ?? null,
        date: canonical?.sickLeave?.date ?? null,
        dateFrom: canonical?.sickLeave?.dateFrom ?? null,
        dateTo: canonical?.sickLeave?.dateTo ?? null,
        maxPercent: canonical?.sickLeave?.maxPercent ?? null,
        percentText: canonical?.sickLeave?.percentText ?? null,
        annualIncome: {
          amount: canonical?.sickLeave?.annualIncome?.amount ?? null,
          currency: canonical?.sickLeave?.annualIncome?.currency ?? "SEK"
        }
      },
      expenses: Array.isArray(canonical?.expenses)
        ? canonical.expenses.map((expense) => ({
            type: expense?.type ?? null,
            date: expense?.date ?? null,
            amount: expense?.amount ?? null,
            currency: expense?.currency ?? "SEK",
            hasReceipt: expense?.hasReceipt ?? null
          }))
        : [],
      expensesMeta: {
        carTravelMiles: canonical?.expensesMeta?.carTravelMiles ?? null,
        sourceStatus: canonical?.expensesMeta?.sourceStatus ?? null
      },
      vehicle: {
        involved: canonical?.vehicle?.involved ?? null,
        details: canonical?.vehicle?.details ?? null,
        registrationNumber: canonical?.vehicle?.registrationNumber ?? null,
        crmType: canonical?.vehicle?.crmType ?? null,
        tags: Array.isArray(canonical?.vehicle?.tags) ? canonical.vehicle.tags : [],
        personInVehicle: canonical?.vehicle?.personInVehicle ?? null,
        isDriver: canonical?.vehicle?.isDriver ?? null,
        policeReported: canonical?.vehicle?.policeReported ?? null
      },
      otherAccidentInsurance: {
        hasOther: canonical?.otherAccidentInsurance?.hasOther ?? null,
        insurer: canonical?.otherAccidentInsurance?.insurer ?? null,
        type: canonical?.otherAccidentInsurance?.type ?? null,
        reported: canonical?.otherAccidentInsurance?.reported ?? null,
        claimNumber: canonical?.otherAccidentInsurance?.claimNumber ?? null
      }
    };
  }

  function isHeadingElement(node) {
    return (
      node &&
      node.nodeType === 1 &&
      /^(H1|H2|H3|H4|H5|H6)$/i.test(node.tagName)
    );
  }

  function findHeadingNodesByText(text) {
    const target = normalizeInline(text);
    if (!target) return null;

    const candidates = Array.from(
      document.querySelectorAll("h1,h2,h3,h4,h5,h6,[role='heading'],[aria-level],.s.t.wc.hc")
    );
    return candidates.filter((node) => normalizeInline(node.textContent) === target);
  }

  function findCardRootFromHeading(headingEl) {
    if (!headingEl) return null;
    return (
      headingEl.closest('[id$="-card"]') ||
      headingEl.closest(".hf.s.c.wf.ct.cl") ||
      headingEl.closest("section") ||
      headingEl.parentElement
    );
  }

  function hasLabel(cardRoot, labelText) {
    if (!cardRoot) return false;
    const target = normalizeInline(labelText);
    if (!target) return false;
    return Array.from(cardRoot.querySelectorAll(".width-fill-4")).some(
      (el) => normalizeInline(el.textContent) === target
    );
  }

  function findCardRootByHeadingAndLabel(headingText, labelText) {
    const headingNodes = findHeadingNodesByText(headingText) || [];
    for (const heading of headingNodes) {
      let ancestor = heading;
      while (ancestor && ancestor !== document.body) {
        if (
          ancestor.matches?.('[id$="-card"]') ||
          ancestor.matches?.(".hf.s.c.wf.ct.cl") ||
          ancestor.matches?.("section")
        ) {
          if (!labelText || hasLabel(ancestor, labelText)) return ancestor;
        }
        ancestor = ancestor.parentElement;
      }
    }

    return null;
  }

  function findCardByHeadingText(text) {
    const headingNodes = findHeadingNodesByText(text) || [];
    for (const heading of headingNodes) {
      const root = findCardRootFromHeading(heading);
      if (root) return root;
    }
    return null;
  }

  async function waitForCardRoot({ headingText, labelText, attempts = 10, delayMs = 200 } = {}) {
    for (let i = 0; i < attempts; i++) {
      const card =
        findCardRootByHeadingAndLabel(headingText, labelText) ||
        findCardByHeadingText(headingText);
      if (card) return card;
      if (i < attempts - 1) {
        await sleep(delayMs);
      }
    }
    return null;
  }

  function getCardTitle(cardRoot) {
    if (!cardRoot) return "";
    const heading = cardRoot.querySelector("h1,h2,h3,h4,h5,h6");
    return normalizeInline(heading?.textContent || "");
  }

  function getStopHeading(cardRoot, stopHeadingText) {
    if (!cardRoot || !stopHeadingText) return null;
    const headings = Array.from(cardRoot.querySelectorAll("h1,h2,h3,h4,h5,h6"));
    return headings.find((h) => normalizeInline(h.textContent) === stopHeadingText) || null;
  }

  function isAfterStopHeading(stopHeading, node) {
    if (!stopHeading || !node) return false;
    const rel = stopHeading.compareDocumentPosition(node);
    return Boolean(rel & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  function extractLabelValueRows(cardRoot, { allowedLabels, stopHeadingText, debug, cardId, cardTitle, caseId, caseNumber } = {}) {
    const rows = [];
    if (!cardRoot) return rows;

    const stopHeading = getStopHeading(cardRoot, stopHeadingText);

    const labelColumns = Array.from(cardRoot.querySelectorAll(".width-fill-4"));
    const rowContainers = new Set();

    const findRowContainerForLabel = (labelCol) => {
      let ancestor = labelCol;
      for (let depth = 0; depth < 12; depth++) {
        ancestor = ancestor?.parentElement;
        if (!ancestor || ancestor === cardRoot) return null;
        if (isAfterStopHeading(stopHeading, ancestor)) return null;

        const labelCount = ancestor.querySelectorAll(".width-fill-4").length;
        const valueCount = ancestor.querySelectorAll(".width-fill-8").length;
        if (labelCount === 1 && valueCount >= 1) return ancestor;
      }
      return null;
    };

    for (const labelCol of labelColumns) {
      if (isAfterStopHeading(stopHeading, labelCol)) continue;
      const row = findRowContainerForLabel(labelCol);
      if (row) rowContainers.add(row);
    }

    const orderedRows = Array.from(rowContainers).sort((a, b) => {
      const rel = a.compareDocumentPosition(b);
      if (rel & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (rel & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });

    for (const row of orderedRows) {
      if (isAfterStopHeading(stopHeading, row)) continue;

      const labelEls = row.querySelectorAll(".width-fill-4");
      const valueEls = row.querySelectorAll(".width-fill-8");
      const labelEl = labelEls.length === 1 ? labelEls[0] : null;
      const valueEl = valueEls.length >= 1 ? valueEls[0] : null;
      if (!labelEl || !valueEl) continue;

      const label = normalizeInline(labelEl.textContent);
      if (!label || UI_TEXT_BLACKLIST.has(label)) continue;

      const ignoredLabels =
        IGNORE_LABELS_BY_CARD_ID[cardId] ||
        IGNORE_LABELS_BY_CARD_TITLE[cardTitle] ||
        new Set();

      const isIgnored =
        ignoredLabels.has(label) ||
        IGNORE_LABEL_PATTERNS.some((pattern) => pattern.test(label));

      if (isIgnored) {
        continue;
      }

      const preWrap = valueEl.querySelector('span[style*="white-space: pre-wrap"]');
      // Prefer `innerText` to preserve natural line breaks between block elements (e.g. lists in injuries).
      // Fall back to `textContent` for cases where innerText is empty/unavailable.
      const rawValue = preWrap
        ? preWrap.innerText || preWrap.textContent
        : valueEl.innerText || valueEl.textContent;
      const value = cleanText(rawValue, { stopMarkers: ["* * *", "Frågor & Svar"], stripUi: true, cardId });
      if (!value) continue;
      if (UI_TEXT_BLACKLIST.has(value)) continue;

      if (allowedLabels && !allowedLabels.has(label)) {
        if (debug?.unmappedLabels) {
          const preview = buildValuePreview(value);
          debug.unmappedLabels.push({
            cardId: cardId || null,
            cardTitle: cardTitle || null,
            labelText: label,
            caseId: caseId || null,
            caseNumber: caseNumber || null,
            valuePreview: preview.valuePreview,
            valueLength: preview.valueLength,
            truncated: preview.truncated
          });
        }
        continue;
      }

      rows.push({ label, value, valueEl });
    }

    return rows;
  }

  function rowsToMap(rows) {
    const map = new Map();
    const elMap = new Map();
    for (const row of rows) {
      if (!map.has(row.label)) {
        map.set(row.label, []);
        elMap.set(row.label, []);
      }
      map.get(row.label).push(row.value);
      elMap.get(row.label).push(row.valueEl);
    }
    return { values: map, elements: elMap };
  }

  function extractClaimant(debug, { caseId, caseNumber } = {}) {
    const primaryEl = document.querySelector("[data-crm-browser-extension]");
    const secondaryEl = document.querySelector("[data-crm-external-form-plugin]");

    const primaryRaw = primaryEl?.getAttribute("data-crm-browser-extension") || null;
    const secondaryRaw = secondaryEl?.getAttribute("data-crm-external-form-plugin") || null;

    const primary = primaryRaw ? safeParseJsonLike(primaryRaw) : null;
    const secondary = secondaryRaw ? safeParseJsonLike(secondaryRaw) : null;

    const getPersonNumber = (obj) => obj?.personNumber || obj?.personalNumber || null;

    if (debug) {
      debug.claimantSource = {
        primary: {
          hasAttribute: Boolean(primaryRaw),
          parsed: Boolean(primary && typeof primary === "object"),
          hasName: Boolean(primary?.name),
          hasPersonNumber: Boolean(getPersonNumber(primary)),
          hasEmail: Boolean(primary?.email)
        },
        secondary: {
          hasAttribute: Boolean(secondaryRaw),
          parsed: Boolean(secondary && typeof secondary === "object"),
          hasName: Boolean(secondary?.name),
          hasPersonNumber: Boolean(getPersonNumber(secondary)),
          hasEmail: Boolean(secondary?.email)
        },
        personNumberReason: null
      };
    }

    if (!primary && primaryRaw) {
      debug?.parseErrors?.push({
        type: "claimant",
        source: "data-crm-browser-extension",
        message: "Failed to parse claimant data attribute",
        caseId: caseId || null,
        caseNumber: caseNumber || null
      });
    }

    if (!secondary && secondaryRaw) {
      debug?.parseErrors?.push({
        type: "claimant",
        source: "data-crm-external-form-plugin",
        message: "Failed to parse claimant data attribute",
        caseId: caseId || null,
        caseNumber: caseNumber || null
      });
    }

    if (!primary && !secondary) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("claimant")) {
        debug.missingExtractors.push("claimant");
      }
      return null;
    }

    const result = {
      caseId: primary?.caseId || secondary?.caseId || null,
      name: primary?.name || null,
      personNumber: normalizePersonNumber(getPersonNumber(primary)),
      email: primary?.email || null
    };

    if (secondary && typeof secondary === "object") {
      if (!result.name) result.name = secondary.name || result.name;
      if (!result.personNumber) result.personNumber = normalizePersonNumber(getPersonNumber(secondary)) || result.personNumber;
      if (!result.email) result.email = secondary.email || result.email;
    }

    if (debug?.claimantSource && !result.personNumber) {
      const primaryParsed = debug.claimantSource.primary.parsed;
      const secondaryParsed = debug.claimantSource.secondary.parsed;
      const primaryAttr = debug.claimantSource.primary.hasAttribute;
      const secondaryAttr = debug.claimantSource.secondary.hasAttribute;
      if (primaryParsed && secondaryParsed) {
        debug.claimantSource.personNumberReason = "absent_in_source";
      } else if ((primaryAttr && !primaryParsed) || (secondaryAttr && !secondaryParsed)) {
        debug.claimantSource.personNumberReason = "parse_failed";
      } else {
        debug.claimantSource.personNumberReason = "absent_in_source";
      }
    }

    return result;
  }

  async function extractClaimantCard(debug, { caseId, caseNumber, waitAttempts = 10 } = {}) {
    const cardRoot = await waitForCardRoot({
      headingText: "Anmälan gäller",
      labelText: "Personnummer",
      attempts: waitAttempts,
      delayMs: 200
    });

    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("claimantCard")) {
        debug.missingExtractors.push("claimantCard");
      }
      return { cardRoot: null, rows: [] };
    }

    const cardId = cardRoot.id || "claimant-card";
    const cardTitle = getCardTitle(cardRoot) || "Anmälan gäller";
    const rows = extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.claimant,
      debug,
      cardId,
      cardTitle,
      caseId,
      caseNumber
    });

    return { cardRoot, rows };
  }

  async function extractCustomerCard(debug, { caseId, caseNumber, waitAttempts = 10 } = {}) {
    const cardRoot = await waitForCardRoot({
      headingText: "Kund",
      labelText: "Namn",
      attempts: waitAttempts,
      delayMs: 200
    });

    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("customerCard")) {
        debug.missingExtractors.push("customerCard");
      }
      return { cardRoot: null, rows: [] };
    }

    const cardId = cardRoot.id || "customer-card";
    const cardTitle = getCardTitle(cardRoot) || "Kund";
    const rows = extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.customer,
      debug,
      cardId,
      cardTitle,
      caseId,
      caseNumber
    });

    return { cardRoot, rows };
  }

  async function extractOverview(debug, { caseId, caseNumber, waitAttempts = 10 } = {}) {
    const cardRoot = await waitForCardRoot({
      headingText: "Översikt",
      labelText: "Kategori",
      attempts: waitAttempts,
      delayMs: 200
    });
    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("overview")) {
        debug.missingExtractors.push("overview");
      }
      return { cardRoot: null, rows: [] };
    }

    const cardId = cardRoot.id || "overview-card";
    const cardTitle = getCardTitle(cardRoot) || "Översikt";
    const rows = extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.overview,
      debug,
      cardId,
      cardTitle,
      caseId,
      caseNumber
    });

    return { cardRoot, rows };
  }

  function extractIncident(debug, { caseId, caseNumber } = {}) {
    const cardRoot = document.querySelector("#incident-case-card") || findCardByHeadingText("Händelse");
    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("incident")) {
        debug.missingExtractors.push("incident");
      }
      return [];
    }

    return extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.incident,
      stopHeadingText: "Frågor & Svar",
      debug,
      cardId: cardRoot.id || null,
      cardTitle: getCardTitle(cardRoot) || "Händelse",
      caseId,
      caseNumber
    });
  }

  function normalizeQaLabel(label) {
    return normalizeInline(label)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/gi, " ")
      .trim();
  }

  function isAfterHeadingNode(heading, node) {
    if (!heading || !node) return false;
    const rel = heading.compareDocumentPosition(node);
    return Boolean(rel & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  function extractIncidentQaRows(debug, { caseId, caseNumber } = {}) {
    const cardRoot = document.querySelector("#incident-case-card") || findCardByHeadingText("Händelse");
    if (!cardRoot) {
      return [];
    }

    const qaHeading = getStopHeading(cardRoot, "Frågor & Svar");
    if (!qaHeading) return [];

    const labelColumns = Array.from(cardRoot.querySelectorAll(".width-fill-4"));
    const rowContainers = new Set();

    const findRowContainerForLabel = (labelCol) => {
      let ancestor = labelCol;
      for (let depth = 0; depth < 12; depth += 1) {
        ancestor = ancestor?.parentElement;
        if (!ancestor || ancestor === cardRoot) return null;
        if (!isAfterHeadingNode(qaHeading, ancestor)) continue;
        const labelCount = ancestor.querySelectorAll(".width-fill-4").length;
        const valueCount = ancestor.querySelectorAll(".width-fill-8").length;
        if (labelCount === 1 && valueCount >= 1) return ancestor;
      }
      return null;
    };

    for (const labelCol of labelColumns) {
      if (!isAfterHeadingNode(qaHeading, labelCol)) continue;
      const row = findRowContainerForLabel(labelCol);
      if (row) rowContainers.add(row);
    }

    const orderedRows = Array.from(rowContainers).sort((a, b) => {
      const rel = a.compareDocumentPosition(b);
      if (rel & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (rel & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });

    const rows = [];
    for (const row of orderedRows) {
      const labelEls = row.querySelectorAll(".width-fill-4");
      const valueEls = row.querySelectorAll(".width-fill-8");
      const labelEl = labelEls.length === 1 ? labelEls[0] : null;
      const valueEl = valueEls.length >= 1 ? valueEls[0] : null;
      if (!labelEl || !valueEl) continue;

      const label = normalizeInline(labelEl.textContent);
      if (!label || UI_TEXT_BLACKLIST.has(label)) continue;

      const preWrap = valueEl.querySelector('span[style*="white-space: pre-wrap"]');
      const rawValue = preWrap
        ? preWrap.innerText || preWrap.textContent
        : valueEl.innerText || valueEl.textContent;
      const value = cleanText(rawValue, { stopMarkers: ["* * *"], stripUi: true, cardId: cardRoot.id || null });
      if (!value || UI_TEXT_BLACKLIST.has(value)) continue;

      rows.push({ label, value });
    }

    if (rows.length === 0 && debug?.warnings) {
      debug.warnings.push(`incidentQa: no rows parsed for case ${caseNumber || caseId || "unknown"}`);
    }

    return rows;
  }

  function extractInjuries(debug, { caseId, caseNumber } = {}) {
    const bodyPair = findInjuryLabelValuePair("Kroppsskador");
    const residualPair = findInjuryLabelValuePair("Kvarstående besvär");

    if (debug) {
      debug.injuryCapture = {
        bodyLabelFound: Boolean(bodyPair?.valueEl),
        residualLabelFound: Boolean(residualPair?.valueEl),
        primaryHeadings: [],
        detailTexts: [],
        consequenceSourceTexts: []
      };
    }

    if (!bodyPair && !residualPair) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("injuries")) {
        debug.missingExtractors.push("injuries");
      }
      return [];
    }

    const rows = [];
    if (residualPair?.valueEl) {
      const residualValue = cleanText(
        residualPair.valueEl.innerText || residualPair.valueEl.textContent || "",
        { stopMarkers: ["* * *", "Frågor & Svar"], stripUi: true }
      );
      if (residualValue) rows.push({ label: "Kvarstående besvär", value: residualValue, valueEl: residualPair.valueEl });
    }

    if (bodyPair?.valueEl) {
      const valueEl = bodyPair.valueEl;
      const primarySpan = valueEl.querySelector?.('span[style*="white-space: pre-wrap"]') || null;
      const primaryRaw = primarySpan
        ? primarySpan.innerText || primarySpan.textContent || ""
        : valueEl.innerText || valueEl.textContent || "";
      const primaryHeadings = extractPrimaryInjuryHeadings(valueEl, primaryRaw);
      const domDetailTexts = extractInjuryDetailTextsFromValueElement(
        valueEl,
        primaryHeadings
      );
      const sourceAssessment = assessInjuryConsequenceSources(primaryHeadings, primaryRaw, domDetailTexts);
      if (debug?.injuryCapture) {
        debug.injuryCapture.primaryHeadings = primaryHeadings;
        debug.injuryCapture.detailTexts = domDetailTexts;
        debug.injuryCapture.consequenceSourceTexts = sourceAssessment.consequenceSourceTexts;
      }
      rows.push({
        label: "Kroppsskador",
        value: primaryHeadings.join("\n"),
        valueEl,
        consequencesEvidence: sourceAssessment.consequencesEvidence,
        consequencesEvidenceComplete: sourceAssessment.consequencesEvidenceComplete,
        consequenceSourceTexts: sourceAssessment.consequenceSourceTexts
      });
    }

    return rows;
  }

  function extractEmployment(debug, { caseId, caseNumber } = {}) {
    const cardRoot =
      findCardByHeadingText("Sysselsättning för barnet") ||
      findCardByHeadingText("Sysselsättning för anmälare") ||
      findCardByHeadingText("Sysselsättning");

    if (!cardRoot) {
      return [];
    }

    const cardId = cardRoot.id || "employment-card";
    const cardTitle = getCardTitle(cardRoot) || "Sysselsättning";

    return extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.employment,
      debug,
      cardId,
      cardTitle,
      caseId,
      caseNumber
    });
  }

  function findTables(cardRoot) {
    if (!cardRoot) return [];
    return Array.from(cardRoot.querySelectorAll("table"));
  }

  function getTableHeaders(table) {
    const headerCells = Array.from(table.querySelectorAll("thead th"));
    if (headerCells.length > 0) {
      return headerCells.map((cell) => normalizeInline(cell.textContent));
    }

    const firstRow = table.querySelector("tr");
    if (!firstRow) return [];
    const cells = Array.from(firstRow.querySelectorAll("th,td"));
    return cells.map((cell) => normalizeInline(cell.textContent));
  }

  function parseVisitsTable(table) {
    const headers = getTableHeaders(table);
    const hasVisitColumns = headers.some((h) => /Besöksdatum|Besöksanledning|Avdelning/i.test(h));
    if (!hasVisitColumns) return [];

    const bodyRows = Array.from(table.querySelectorAll("tbody tr"));
    const rows = bodyRows.length > 0 ? bodyRows : Array.from(table.querySelectorAll("tr")).slice(1);

    return rows.map((row, idx) => {
      const cells = Array.from(row.querySelectorAll("td"));
      const getCell = (label) => {
        const index = headers.findIndex((h) => h === label);
        if (index === -1) return "";
        return normalizePreserveNewlines(cells[index]?.textContent || "");
      };

      const dateText = getCell("Besöksdatum") || getCell("Besöksdatum ") || "";
      const dateParts = parseDateOrInterval(dateText);

      return {
        date: dateParts.date,
        dateFrom: dateParts.dateFrom,
        dateTo: dateParts.dateTo,
        reason: getCell("Besöksanledning") || null,
        department: getCell("Avdelning") || null,
        rowIndex: idx
      };
    });
  }

  function findVisitGrids(cardRoot) {
    if (!cardRoot) return [];
    const gridCandidates = Array.from(cardRoot.querySelectorAll('[class*="grid-rows-"]')).filter((node) =>
      node.querySelector('[class*="grid-pos-"]')
    );
    if (gridCandidates.length > 0) return gridCandidates;

    const cells = Array.from(cardRoot.querySelectorAll('[class*="grid-pos-"]'));
    if (cells.length === 0) return [];

    const containers = new Set();
    for (const cell of cells) {
      const container = findGridContainerForCell(cell, cardRoot);
      if (container) containers.add(container);
    }
    return Array.from(containers);
  }

  function findGridContainerForCell(cell, cardRoot) {
    if (!cell) return null;
    let node = cell.parentElement;
    let best = null;
    let bestCount = 0;

    while (node && node !== cardRoot) {
      const count = node.querySelectorAll('[class*="grid-pos-"]').length;
      if (count >= 4 && count > bestCount) {
        best = node;
        bestCount = count;
      }
      node = node.parentElement;
    }

    return best;
  }

  function hasFirstVisitBadge(cell) {
    if (!cell) return false;
    const title = cell.getAttribute?.("title");
    const aria = cell.getAttribute?.("aria-label");
    if (typeof title === "string" && /Första vårdbesöket/i.test(title)) return true;
    if (typeof aria === "string" && /Första vårdbesöket/i.test(aria)) return true;
    return Boolean(
      cell.querySelector(
        '[title*="Första vårdbesöket"],[aria-label*="Första vårdbesöket"]'
      )
    );
  }

  function parseVisitsGrid(gridRoot) {
    if (!gridRoot) return [];
    const cellNodes = Array.from(gridRoot.querySelectorAll('[class*="grid-pos-"]'));
    if (cellNodes.length === 0) return [];

    const cells = [];
    for (const node of cellNodes) {
      const className = typeof node.className === "string" ? node.className : "";
      const match = className.match(/grid-pos-(\d+)-(\d+)-(\d+)-(\d+)/);
      if (!match) continue;
      const row = Number.parseInt(match[1], 10);
      const col = Number.parseInt(match[2], 10);
      if (Number.isNaN(row) || Number.isNaN(col)) continue;
      const text = normalizeInline(node.textContent || "");
      cells.push({ row, col, text, isFirstVisit: hasFirstVisitBadge(node) });
    }

    return parseVisitsGridCells(cells);
  }

  function parseVisitsGridCells(cells) {
    if (!Array.isArray(cells) || cells.length === 0) return [];

    const rows = new Map();
    for (const cell of cells) {
      if (!rows.has(cell.row)) rows.set(cell.row, new Map());
      rows.get(cell.row).set(cell.col, cell);
    }

    const headerLabels = new Set(["Info", "Besöksdatum", "Besöksanledning", "Avdelning"]);
    let headerRow = null;
    let headerRowCells = null;
    let headerScore = 0;

    for (const [row, rowMap] of rows.entries()) {
      const labels = Array.from(rowMap.values())
        .map((cell) => normalizeInline(cell.text))
        .filter(Boolean);
      const score = labels.filter((label) => headerLabels.has(label)).length;
      if (score > headerScore) {
        headerScore = score;
        headerRow = row;
        headerRowCells = rowMap;
      }
    }

    if (!headerRowCells || headerScore < 2) return [];

    const colByLabel = {};
    for (const cell of headerRowCells.values()) {
      const label = normalizeInline(cell.text);
      if (headerLabels.has(label)) {
        colByLabel[label] = cell.col;
      }
    }

    if (!Number.isFinite(colByLabel["Besöksdatum"])) return [];

    const sortedRows = Array.from(rows.keys())
      .filter((row) => row > headerRow)
      .sort((a, b) => a - b);

    const visits = [];
    for (let idx = 0; idx < sortedRows.length; idx += 1) {
      const row = sortedRows[idx];
      const rowMap = rows.get(row);
      if (!rowMap) continue;

      const getCellText = (label) => {
        const col = colByLabel[label];
        if (!Number.isFinite(col)) return "";
        const cell = rowMap.get(col);
        return normalizeInline(cell?.text || "");
      };

      const dateText = normalizeGridCellValue(getCellText("Besöksdatum"));
      const reasonText = normalizeVisitReason(getCellText("Besöksanledning"));
      const departmentText = normalizeGridCellValue(getCellText("Avdelning"));

      const infoCol = colByLabel["Info"];
      const infoCell = Number.isFinite(infoCol) ? rowMap.get(infoCol) : null;
      const isFirstVisit = infoCell?.isFirstVisit ? true : null;

      if (!dateText && !reasonText && !departmentText && !isFirstVisit) continue;

      const dateParts = dateText ? parseDateOrInterval(dateText) : { date: null, dateFrom: null, dateTo: null };

      visits.push({
        date: dateParts.date,
        dateFrom: dateParts.dateFrom,
        dateTo: dateParts.dateTo,
        reason: reasonText || null,
        department: departmentText || null,
        rowIndex: idx,
        isFirstVisit
      });
    }

    return visits;
  }

  function findCareProvidersCardRoot() {
    return (
      document.querySelector("#visited-healthcare-providers-card") ||
      findCardByHeadingText("Besökta vårdinrättningar")
    );
  }

  function isSchoolMoreInfoText(value) {
    const text = normalizeInline(value || "");
    const withoutLeadingIcon = text.replace(/^[^A-Za-zÅÄÖåäö0-9]+/, "").trim();
    return /^Mer information om skola$/i.test(withoutLeadingIcon);
  }

  function findSchoolCardRoot() {
    return (
      findCardByHeadingText("Sysselsättning för barnet") ||
      findCardByHeadingText("Sysselsättning för anmälare") ||
      findCardByHeadingText("Sysselsättning")
    );
  }

  function hasExpandedSchoolDetails(cardRoot) {
    const expandedLabels = new Set(["Typ av huvudman", "Namn på huvudman", "Besöksadress", "Telefonnummer", "Hemsida"]);
    return Array.from(cardRoot?.querySelectorAll?.(".width-fill-4") || []).some((node) =>
      expandedLabels.has(normalizeInline(node.textContent))
    );
  }

  async function expandSchoolDetails(debug) {
    const cardRoot = findSchoolCardRoot();
    if (!cardRoot || hasExpandedSchoolDetails(cardRoot)) return cardRoot;
    const control = Array.from(cardRoot.querySelectorAll("button,a,[role='button']")).find((node) =>
      isSchoolMoreInfoText(node.textContent || node.getAttribute?.("aria-label") || "")
    );
    if (!control) return cardRoot;
    try {
      control.click();
      for (let attempt = 0; attempt < 10 && !hasExpandedSchoolDetails(cardRoot); attempt += 1) {
        await sleep(100);
      }
      if (!hasExpandedSchoolDetails(cardRoot)) {
        debug?.warnings?.push("school: expanded control clicked but expanded school details did not render");
      }
    } catch (error) {
      debug?.warnings?.push(`school: could not expand school details: ${error?.message || String(error)}`);
    }
    return cardRoot;
  }

  function hasCareProviderAddressDetails(rootNode) {
    const text = normalizePreserveNewlines(rootNode?.innerText || rootNode?.textContent || "");
    return /(?:^|\n)(?:Postadress|Journaladress|Postadress\s*\/\s*journaladress|Besöksadress)(?:\n|$)/i.test(text);
  }

  function isCareProviderMoreInfoText(value) {
    const text = normalizeInline(value || "");
    if (!text) return false;
    const withoutLeadingIcon = text.replace(/^[^A-Za-zÅÄÖåäö0-9]+/, "").trim();
    return /^Mer information om vårdinrättning$/i.test(withoutLeadingIcon);
  }

  function findCareProviderControlScope(control, cardRoot) {
    if (!control || !cardRoot) return null;
    let node = control.parentElement;
    for (let depth = 1; node && node !== cardRoot && depth <= 8; depth += 1) {
      const matchingControls = Array.from(node.querySelectorAll("button,a,[role='button']")).filter((candidate) => {
        const text = normalizeInline(candidate.textContent || candidate.getAttribute?.("aria-label") || "");
        return isCareProviderMoreInfoText(text);
      });
      const hasSingleMatchingControl = matchingControls.length === 1 && matchingControls[0] === control;
      const hasProviderName = Boolean(
        Array.from(node.querySelectorAll(".s.t.wc.hc")).find((candidate) => {
          const text = normalizeInline(candidate.textContent);
          return text && !isCareProviderMoreInfoText(text);
        })
      );
      const hasVisits = Boolean(node.querySelector("table,[class*='grid-rows-'],[class*='grid-pos-']"));
      const hasAddress = hasCareProviderAddressDetails(node);
      if (hasSingleMatchingControl && (hasProviderName || hasVisits || hasAddress)) return node;
      node = node.parentElement;
    }
    return control.parentElement || null;
  }

  async function expandCareProviderDetails(debug) {
    const cardRoot = findCareProvidersCardRoot();
    if (!cardRoot) return null;

    const controls = Array.from(cardRoot.querySelectorAll("button,a,[role='button']")).filter((node) => {
      const text = normalizeInline(node.textContent || node.getAttribute?.("aria-label") || "");
      return isCareProviderMoreInfoText(text);
    });

    let clicked = 0;
    for (const control of controls) {
      const scope = findCareProviderControlScope(control, cardRoot);
      const before = hasCareProviderAddressDetails(scope);
      if (before) continue;

      try {
        control.click();
        clicked += 1;
        await sleep(80);
      } catch (error) {
        debug?.warnings?.push(`careProviders: could not expand provider details: ${error?.message || String(error)}`);
      }
    }

    if (clicked > 0) {
      await sleep(250);
    }

    return cardRoot;
  }

  function extractCareProviderLinks(sectionRoot) {
    const links = Array.from(sectionRoot?.querySelectorAll?.("a") || []);
    const firstHrefMatching = (pattern) => {
      const link = links.find((item) => pattern.test(String(item.href || item.getAttribute?.("href") || "")));
      return link?.href || link?.getAttribute?.("href") || null;
    };

    return {
      healthcareProviderUrl: firstHrefMatching(/\/healthcare-provider|hsa|insuro/i),
      healthcareSearchUrl: firstHrefMatching(/1177\.se|hitta-vard/i)
    };
  }

  function extractCareProviderAddressDetails(sectionRoot) {
    if (!sectionRoot) {
      return {
        postalAddress: null,
        journalAddress: null,
        visitAddress: null,
        addressSource: null,
        healthcareProviderUrl: null,
        healthcareSearchUrl: null
      };
    }

    const text = normalizePreserveNewlines(sectionRoot.innerText || sectionRoot.textContent || "");
    const lines = text
      .split("\n")
      .map((line) => normalizeInline(line))
      .filter(Boolean);

    const isAddressLabel = (line) =>
      /^(?:Postadress|Journaladress|Postadress\s*\/\s*journaladress|Besöksadress)$/i.test(line);
    const isStopLine = (line) =>
      isAddressLabel(line) ||
      /^(?:Info|Besöksdatum|Besöksanledning|Avdelning|Första vårdbesöket)$/i.test(line) ||
      isCareProviderMoreInfoText(line);

    const readAfterLabel = (labelPattern) => {
      const index = lines.findIndex((line) => labelPattern.test(line));
      if (index === -1) return null;

      const parts = [];
      for (let i = index + 1; i < lines.length; i += 1) {
        const line = lines[i];
        if (isStopLine(line)) break;
        parts.push(line);
        if (parts.length >= 6) break;
      }

      return parts.length > 0 ? parts.join(", ") : null;
    };

    const combinedAddress = readAfterLabel(/^Postadress\s*\/\s*journaladress$/i);
    const postalAddress = readAfterLabel(/^Postadress$/i) || combinedAddress;
    const journalAddress = readAfterLabel(/^Journaladress$/i) || combinedAddress;
    const visitAddress = readAfterLabel(/^Besöksadress$/i);
    const links = extractCareProviderLinks(sectionRoot);

    let addressSource = null;
    if (postalAddress || journalAddress || visitAddress) {
      addressSource = "crm_expanded";
    } else if (/Försättsblad utan verifierad adress/i.test(text)) {
      addressSource = "unverified";
    }

    return {
      postalAddress,
      journalAddress,
      visitAddress,
      addressSource,
      healthcareProviderUrl: links.healthcareProviderUrl,
      healthcareSearchUrl: links.healthcareSearchUrl
    };
  }

  function careProviderHeadingCandidates(sectionRoot, selector, cardTitle) {
    return Array.from(sectionRoot.querySelectorAll(selector)).filter((node) => {
      // CRM action labels use the same typography classes as provider headings.
      // Exclude both controls and all visit grids, including their descendants.
      const excludedAncestor = node.closest?.("button,[role='button'],input,select,textarea,table,[class*='grid-rows-'],[class*='grid-pos-']");
      if (excludedAncestor && excludedAncestor !== sectionRoot && sectionRoot.contains(excludedAncestor)) {
        return false;
      }
      const text = normalizeInline(node.textContent);
      return Boolean(text) && text !== cardTitle &&
        !isCareProviderMoreInfoText(text) &&
        !/^(?:Lägg till besök|Lägg till vårdinrättning|Begär journaler|Försättsblad|Inaktiv|Info|Besöksdatum|Besöksanledning|Avdelning)$/i.test(text);
    });
  }

  function findProviderBlockRoot(gridOrTable, cardRoot, cardTitle) {
    if (!gridOrTable) return null;
    // A table wrapper can contain only the add-visit button. Keep walking until
    // actual provider headings are found, so visits retain the provider's address.
    let node = gridOrTable.parentElement;
    for (let depth = 1; node && node !== cardRoot && depth <= 10; depth += 1) {
      const typeNodes = careProviderHeadingCandidates(node, ".s.t.wf.hf", cardTitle);
      const nameNodes = careProviderHeadingCandidates(node, ".s.t.wc.hc", cardTitle);
      if (typeNodes.length > 0 && nameNodes.length > 0) return node;
      node = node.parentElement;
    }
    return gridOrTable.closest("section") || gridOrTable.parentElement;
  }

  function extractProviderInfoFromSection(sectionRoot, cardTitle) {
    if (!sectionRoot) return { providerType: null, providerName: null, source: null };

    // Provider blocks in CRM are not always rendered with <h*> headings; often they use
    // div/span nodes with "s t wf hf" / "s t wc hc" classes. We extract provider info
    // only from nodes *outside* the visits grid/table to avoid mixing in row values.

    const headingCandidates = careProviderHeadingCandidates(
      sectionRoot, "h2,h3,h4,h5,h6,.s.t.wf.hf,.s.t.wc.hc", cardTitle
    ).map((node) => normalizeInline(node.textContent));

    let providerType = null;
    let source = null;

    // Prefer a provider type line that is not wrapped in parentheses.
    for (const t of headingCandidates) {
      if (!t.startsWith("(")) {
        providerType = t;
        break;
      }
    }

    // Source is explicitly rendered as "(Via kund)" in many cases.
    const sourceCandidate = headingCandidates.find((t) => /\(.*Via\s+kund.*\)/i.test(t));
    if (sourceCandidate) {
      source = normalizeInline(sourceCandidate.replace(/[()]/g, ""));
    }

    // Provider name is typically a prominent "s t wc hc" node near the provider header.
    // Exclude controls and visit grids so neither action labels nor reasons become names.
    const nameCandidates = careProviderHeadingCandidates(
      sectionRoot, ".s.t.wc.hc", cardTitle
    ).map((node) => normalizeInline(node.textContent));

    const providerName = nameCandidates.length > 0 ? nameCandidates[0] : null;

    return { providerType: providerType || null, providerName, source: source || null };
  }

  function extractCareProviders(debug, { caseId, caseNumber } = {}) {
    const cardRoot = findCareProvidersCardRoot();

    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("careProviders")) {
        debug.missingExtractors.push("careProviders");
      }
      return { providers: [], journalCoverSheetUrl: null };
    }

    const cardTitle = getCardTitle(cardRoot) || "Besökta vårdinrättningar";
    const tables = findTables(cardRoot);
    const grids = findVisitGrids(cardRoot);
    const providers = [];
    let visitCount = 0;
    const providerBySection = new Map();

    const ensureProvider = (sectionRoot) => {
      const key = sectionRoot || cardRoot;
      if (!providerBySection.has(key)) {
        const providerInfo = extractProviderInfoFromSection(sectionRoot, cardTitle);
        const addressDetails = extractCareProviderAddressDetails(sectionRoot);
        providerBySection.set(key, {
          providerType: providerInfo.providerType,
          providerName: providerInfo.providerName,
          source: providerInfo.source,
          postalAddress: addressDetails.postalAddress,
          journalAddress: addressDetails.journalAddress,
          visitAddress: addressDetails.visitAddress,
          addressSource: addressDetails.addressSource,
          healthcareProviderUrl: addressDetails.healthcareProviderUrl,
          healthcareSearchUrl: addressDetails.healthcareSearchUrl,
          visits: []
        });
      }
      return providerBySection.get(key);
    };

    for (const table of tables) {
      const visits = parseVisitsTable(table);
      if (!visits || visits.length === 0) continue;
      visitCount += visits.length;

      const sectionRoot = findProviderBlockRoot(table, cardRoot, cardTitle);
      const provider = ensureProvider(sectionRoot);
      provider.visits.push(...visits);
    }

    for (const grid of grids) {
      const visits = parseVisitsGrid(grid);
      if (!visits || visits.length === 0) continue;
      visitCount += visits.length;

      const sectionRoot = findProviderBlockRoot(grid, cardRoot, cardTitle);
      const provider = ensureProvider(sectionRoot);
      provider.visits.push(...visits);
    }

    providers.push(...providerBySection.values());

    const coverLink = Array.from(cardRoot.querySelectorAll("a")).find((a) =>
      /Försättsblad/i.test(normalizeInline(a.textContent))
    );

    if ((tables.length > 0 || grids.length > 0) && visitCount === 0) {
      debug?.warnings?.push("careProviders: card found but no visit rows parsed");
    }

    return {
      providers,
      journalCoverSheetUrl: coverLink?.href || null
    };
  }

  function extractAdditionalCareProvidersReportedCount() {
    const cardRoot = findCardByHeadingText("Alla besökta vårdinrättningar");
    if (!cardRoot) return null;

    const text = normalizePreserveNewlines(cardRoot.innerText || cardRoot.textContent || "");
    if (!text) return null;
    if (/inte har besökt några ytterligare vårdinrättningar/i.test(text)) return 0;

    const match = text.match(/Kunden\s+har\s+angett\s+(\d+)\s+ytterligare\s+vårdinrättningar/i);
    if (!match) return null;
    const parsed = Number(match[1]);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function deriveHospitalizationFromCareProviders(providers) {
    const result = {
      hospitalized: null,
      hospitalizedWhere: null,
      hospitalizedFrom: null,
      hospitalizedTo: null
    };
    if (!Array.isArray(providers) || providers.length === 0) return result;

    for (const provider of providers) {
      const visits = Array.isArray(provider?.visits) ? provider.visits : [];
      for (const visit of visits) {
        const reasonFolded = foldSwedishText(visit?.reason);
        if (!reasonFolded.includes("inlagd")) continue;

        const dateFrom = normalizeIsoDate(visit?.dateFrom) || normalizeIsoDate(visit?.date);
        const dateTo = normalizeIsoDate(visit?.dateTo) || normalizeIsoDate(visit?.date);
        const hospitalizedWhere =
          normalizeInline(provider?.providerName) ||
          normalizeInline(provider?.providerType) ||
          normalizeInline(visit?.department) ||
          null;

        result.hospitalized = true;
        result.hospitalizedWhere = hospitalizedWhere || null;
        result.hospitalizedFrom = dateFrom || null;
        result.hospitalizedTo = dateTo || null;
        return result;
      }
    }

    return result;
  }

  function extractLinesFromNode(node) {
    if (!node) return [];
    const text = normalizePreserveNewlines(node.innerText || node.textContent || "");
    if (!text) return [];
    return text
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
  }

  function findTreatmentsSectionBody(cardRoot, title) {
    if (!cardRoot) return null;
    const target = normalizeInline(title);
    if (!target) return null;

    const headingCandidates = Array.from(
      cardRoot.querySelectorAll(
        "h1,h2,h3,h4,h5,h6,[role='heading'],[aria-level],.s.t.wf.hf,.s.t.wc.hc"
      )
    ).filter((node) => normalizeInline(node.textContent) === target);

    for (const heading of headingCandidates) {
      const direct = heading.nextElementSibling;
      if (direct && cardRoot.contains(direct)) return direct;

      const viaParent = heading.parentElement?.nextElementSibling;
      if (viaParent && cardRoot.contains(viaParent)) return viaParent;

      const viaGrandParent = heading.parentElement?.parentElement?.nextElementSibling;
      if (viaGrandParent && cardRoot.contains(viaGrandParent)) return viaGrandParent;
    }

    return null;
  }

  function parsePerformedTreatmentEntryLines(lines) {
    const header = normalizeInline(lines?.[0] || "");
    const provider = normalizeInline(lines?.[1] || "") || null;
    const dateParts = parseDateOrInterval(header);
    const type = normalizeInline(header.replace(/\([^)]*\)/g, ""));

    return {
      type: type || null,
      date: dateParts.date,
      dateFrom: dateParts.dateFrom,
      dateTo: dateParts.dateTo,
      providerName: provider,
      departmentOrPerson: null
    };
  }

  function parseTreatmentsPlannedFromLines(lines) {
    const planned = { status: null, details: null, followUpDate: null };
    const cleanLines = Array.isArray(lines) ? lines.map((l) => normalizeInline(l)).filter(Boolean) : [];
    if (cleanLines.length === 0) return planned;

    const joined = cleanLines.join("\n");

    // Explicit "no more treatments" signal.
    if (cleanLines.some((line) => /inte\s+har\s+fler\s+behandlingar/i.test(line))) {
      planned.status = "customer_says_no_more";
      return planned;
    }

    // Follow-up signal inside the planned section.
    const followUpMatch = joined.match(/Systemet\s+återkommer\s+den\s+(\d{4}-\d{2}-\d{2})/i);
    const followUpDate = followUpMatch ? followUpMatch[1] : null;

    const plannedCueRegex = /\b(planerad|planerat|planerade|kommande)\b/i;
    const hasPlannedCue = plannedCueRegex.test(joined) || Boolean(followUpDate);

    if (hasPlannedCue) {
      planned.status = "planned";
      const details = cleanLines
        .filter((line) => /^Kunden\s+har\b/i.test(line))
        .map((line) => line.replace(/\s+/g, " ").trim());
      planned.details = details.length > 0 ? details : null;
      planned.followUpDate = followUpDate;
      return planned;
    }

    return planned;
  }

  function extractTreatments(debug, { caseId, caseNumber } = {}) {
    const cardRoot =
      document.querySelector("#treatments-case-card") ||
      findCardByHeadingText("Behandlingar");

    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("treatments")) {
        debug.missingExtractors.push("treatments");
      }
      return { performed: [], planned: { status: null, details: null, followUpDate: null } };
    }

    const performedBody = findTreatmentsSectionBody(cardRoot, "Utförda behandlingar");
    const plannedBody = findTreatmentsSectionBody(cardRoot, "Planerade behandlingar");

    const performed = [];
    if (!performedBody) {
      debug?.warnings?.push("treatments: missing performed section body");
    } else {
      const performedTextLines = extractLinesFromNode(performedBody);
      if (!performedTextLines.some((line) => /Inga behandlingar\.?/i.test(line))) {
        const typeNodes = Array.from(performedBody.querySelectorAll(".s.t.wf.hf"));
        const seenRoots = new Set();

        if (typeNodes.length > 0) {
          for (const typeNode of typeNodes) {
            const typeText = normalizeInline(typeNode.textContent || "");
            if (!typeText) continue;

            let entryRoot = typeNode;
            while (entryRoot && entryRoot !== performedBody) {
              const lines = extractLinesFromNode(entryRoot);
              if (lines.length >= 2 && entryRoot.querySelectorAll(".s.t.wf.hf").length === 1) break;
              entryRoot = entryRoot.parentElement;
            }

            const rootForParse = entryRoot && entryRoot !== performedBody ? entryRoot : typeNode;
            if (seenRoots.has(rootForParse)) continue;
            seenRoots.add(rootForParse);

            const lines = extractLinesFromNode(rootForParse);
            if (lines.length === 0) continue;
            performed.push(parsePerformedTreatmentEntryLines(lines));
          }
        } else {
          // Fallback: parse from body lines in pairs (best-effort, no DOM structure).
          for (let idx = 0; idx < performedTextLines.length; idx += 2) {
            const header = performedTextLines[idx];
            if (!header) continue;
            const provider = performedTextLines[idx + 1] || null;
            performed.push(parsePerformedTreatmentEntryLines([header, provider]));
          }
        }

        if (performedTextLines.length > 0 && performed.length === 0) {
          debug?.warnings?.push("treatments: performed section had text but no entries parsed");
        }
      }
    }

    const plannedLines = plannedBody ? extractLinesFromNode(plannedBody) : [];
    const planned = parseTreatmentsPlannedFromLines(plannedLines);

    if (!plannedBody) {
      debug?.warnings?.push("treatments: missing planned section body");
      if (debug?.missingExtractors && !debug.missingExtractors.includes("treatmentsPlanned")) {
        debug.missingExtractors.push("treatmentsPlanned");
      }
    } else if (plannedLines.length > 0 && !planned.status) {
      debug?.warnings?.push(
        `treatments: unrecognized planned variant: ${buildValuePreview(plannedLines.join("\n")).valuePreview || "<empty>"}`
      );
    }

    return { performed, planned };
  }

  function parseSickLeaveFromInputs(input) {
    const cardText = normalizePreserveNewlines(input?.cardText || "");
    const explicitNo =
      /Har\s+inte\s+varit\s+sjukskriven\./i.test(cardText) ||
      /för\s+ung\s+för\s+sjukskrivning/i.test(cardText) ||
      /Redan\s+sjukskriven\s+sedan\s+innan\s+olyckan\./i.test(cardText);
    if (explicitNo) {
      return {
        hasSickLeave: false,
        statusText: null,
        date: null,
        dateFrom: null,
        dateTo: null,
        maxPercent: null,
        percentText: null,
        annualIncome: { amount: null, currency: "SEK" }
      };
    }

    const statusText = input?.statusText ? normalizePreserveNewlines(input.statusText) : null;
    const dateText = input?.dateText ? normalizePreserveNewlines(input.dateText) : null;
    const percentText = input?.percentText ? normalizePreserveNewlines(input.percentText) : null;
    const annualIncomeText = input?.annualIncomeText ? normalizePreserveNewlines(input.annualIncomeText) : null;

    const hasAny = Boolean(statusText || dateText || percentText || annualIncomeText);

    const dateParts = parseDateOrInterval(dateText || "");
    const annualIncomeMoney = parseMoney(annualIncomeText || "");

    return {
      hasSickLeave: hasAny ? true : null,
      statusText: statusText || null,
      date: dateParts.date,
      dateFrom: dateParts.dateFrom,
      dateTo: dateParts.dateTo,
      maxPercent: percentText ? parsePercentMax(percentText) : null,
      percentText: percentText || null,
      annualIncome: {
        amount: annualIncomeMoney.amount,
        currency: annualIncomeMoney.currency || "SEK"
      }
    };
  }

  function extractSickLeave(debug, { caseId, caseNumber } = {}) {
    const cardRoot = findCardByHeadingText("Sjukskrivning");
    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("sickLeave")) {
        debug.missingExtractors.push("sickLeave");
      }
      return parseSickLeaveFromInputs({ cardText: "" });
    }

    const cardId = cardRoot.id || "sick-leave-card";
    const cardTitle = "Sjukskrivning";

    const cardText = cleanText(cardRoot.innerText || "", {
      stopMarkers: ["Frågor & Svar"],
      stripUi: true,
      cardId
    });

    // Fast-path explicit "no sick leave" variant.
    if (/Har\s+inte\s+varit\s+sjukskriven\./i.test(cardText)) {
      return parseSickLeaveFromInputs({ cardText });
    }

    // Explicit "not asked" variant → leave blank without warning.
    if (/inte\s+frågat\s+om\s+sjukskrivning/i.test(cardText)) {
      return parseSickLeaveFromInputs({ cardText });
    }

    const rows = extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.sickLeave,
      debug,
      cardId,
      cardTitle,
      caseId,
      caseNumber
    });

    const { values } = rowsToMap(rows);
    const getValue = (label) => values.get(label)?.[0] || null;

    const parsed = parseSickLeaveFromInputs({
      cardText,
      statusText: getValue("Status"),
      dateText: getValue("Datum"),
      percentText: getValue("Procent"),
      annualIncomeText: getValue("Årsinkomst")
    });

    if (parsed.hasSickLeave == null) {
      debug?.warnings?.push("sickLeave: card found but no recognizable variant");
    }

    return parsed;
  }

  function extractExpenses(debug, { caseId, caseNumber } = {}) {
    const cardRoot = document.querySelector("#expenses-case-card") || findCardByHeadingText("Utgifter");
    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("expenses")) {
        debug.missingExtractors.push("expenses");
      }
      return { items: [], meta: { carTravelMiles: null, sourceStatus: "MISSING" } };
    }

    const cardText = cleanText(cardRoot.innerText || "", { stopMarkers: ["Frågor & Svar"], stripUi: true, cardId: cardRoot.id || null });
    if (/Inga utgifter/i.test(cardText)) {
      return { items: [], meta: { carTravelMiles: null, sourceStatus: "EXPLICIT_NONE" } };
    }

    const rows = extractLabelValueRows(cardRoot, {
      allowedLabels: ALLOWED_LABELS.expenses,
      debug,
      cardId: cardRoot.id || null,
      cardTitle: getCardTitle(cardRoot) || "Utgifter",
      caseId,
      caseNumber
    });

    const { values } = rowsToMap(rows);

    const labels = ["Typ av utgift", "Datum för utgift", "Kostnad", "Har kvitto"];
    const maxLen = Math.max(
      0,
      ...labels.map((label) => (values.get(label) ? values.get(label).length : 0))
    );

    const count = maxLen > 0 ? maxLen : values.size > 0 ? 1 : 0;
    const expenses = [];

    const milesRaw = values.get("Antal mil")?.[0] || null;
    const carTravelMiles = milesRaw ? parseMiles(milesRaw) : null;

    for (let i = 0; i < count; i++) {
      const type = values.get("Typ av utgift")?.[i] || values.get("Typ av utgift")?.[0] || null;
      const date = values.get("Datum för utgift")?.[i] || values.get("Datum för utgift")?.[0] || null;
      const cost = values.get("Kostnad")?.[i] || values.get("Kostnad")?.[0] || null;
      const receipt = values.get("Har kvitto")?.[i] || values.get("Har kvitto")?.[0] || null;

      const money = parseMoney(cost || "");

      expenses.push({
        type: type || null,
        date: date || null,
        amount: money.amount,
        currency: money.currency || "SEK",
        hasReceipt: toBool(receipt)
      });
    }

    return {
      items: expenses,
      meta: {
        carTravelMiles,
        sourceStatus: expenses.length > 0 ? "ROWS" : "UNRECOGNIZED"
      }
    };
  }

  function parseVehicleDetailsLines(inputLines) {
    const contentLines = (Array.isArray(inputLines) ? inputLines : [])
      .map((line) => String(line || "").trim())
      .filter(Boolean)
      .filter((line) => normalizeInline(line) !== "Fordon inblandat");
    const empty = {
      registrationNumber: null,
      crmType: null,
      tags: [],
      personInVehicle: null,
      isDriver: null,
      policeReported: null
    };
    if (contentLines.length === 0) return empty;

    const normalized = (value) => normalizeInline(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
    const exactValueAfter = (labels) => {
      const accepted = new Set(labels.map(normalized));
      const index = contentLines.findIndex((line) => accepted.has(normalized(line)));
      return index >= 0 ? contentLines[index + 1] || null : null;
    };
    const normalizedLines = new Set(contentLines.map(normalized));
    const tagDefinitions = [
      ["Förare", "DRIVER"],
      ["Passagerare", "PASSENGER"],
      ["Någon som kunden känner äger fordonet", "KNOWN_PERSON_OWNS_VEHICLE"],
      ["Moped klass 1", "MOPED_CLASS_1"]
    ];
    const tags = tagDefinitions
      .filter(([label]) => normalizedLines.has(normalized(label)))
      .map(([, tag]) => tag);
    const roleText = normalized(exactValueAfter(["Kunden var", "Kunden var:"]));
    const isDriver = tags.includes("DRIVER") ? true : null;
    const personInVehicle = isDriver || tags.includes("PASSENGER") || /forare eller passagerare|fardades i/.test(roleText)
      ? true
      : null;

    return {
      registrationNumber: exactValueAfter(["Fordonets registreringsnummer", "Registreringsnummer"]),
      crmType: exactValueAfter(["Typ av fordon", "Fordonstyp"]),
      tags,
      personInVehicle,
      isDriver,
      policeReported: toBool(exactValueAfter(["Polisanmält", "Polisanmälan gjord"]))
    };
  }

  function extractExactVehicleTagsFromDocument(documentRef, roots) {
    const accepted = new Map([
      ["förare", "DRIVER"],
      ["passagerare", "PASSENGER"],
      ["någon som kunden känner äger fordonet", "KNOWN_PERSON_OWNS_VEHICLE"],
      ["moped klass 1", "MOPED_CLASS_1"]
    ]);
    const tags = [];
    const scopedRoots = (Array.isArray(roots) ? roots : []).filter(Boolean);
    const queryRoots = scopedRoots.length > 0 ? scopedRoots : [documentRef];
    const nodes = queryRoots.flatMap((root) => Array.from(root?.querySelectorAll?.(
      ".s.t.wc.hc,.s.t.wf.hf,li,[role='listitem']"
    ) || []));
    for (const node of nodes) {
      const normalized = normalizeInline(node?.textContent).toLocaleLowerCase("sv-SE");
      const tag = accepted.get(normalized);
      if (tag && !tags.includes(tag)) tags.push(tag);
    }
    return tags;
  }

  function parseIncidentVehicleBulletTags(rawText) {
    const accepted = new Map([
      ["förare", "DRIVER"],
      ["passagerare", "PASSENGER"],
      ["någon som kunden känner äger fordonet", "KNOWN_PERSON_OWNS_VEHICLE"],
      ["moped klass 1", "MOPED_CLASS_1"]
    ]);
    const tags = [];
    const lines = String(rawText || "").replace(/\r\n?/g, "\n").split("\n");
    for (const rawLine of lines) {
      // CRM renders these facts as bullet rows. Only a real leading bullet is
      // removed; ordinary prose such as “förare eller passagerare” cannot match.
      const line = rawLine.replace(/^\s*[•·▪◦]\s*/, "").trim().toLocaleLowerCase("sv-SE");
      const tag = accepted.get(line);
      if (tag && !tags.includes(tag)) tags.push(tag);
    }
    return tags;
  }

  function extractVehicle(debug, { caseId, caseNumber } = {}) {
    const cardRoot = findCardByHeadingText("Fordon inblandat");
    if (!cardRoot) {
      if (debug?.missingExtractors && !debug.missingExtractors.includes("vehicle")) {
        debug.missingExtractors.push("vehicle");
      }
      return { involved: null, details: null, ...parseVehicleDetailsLines([]) };
    }

    const cardText = cleanText(cardRoot.innerText || "", { stopMarkers: ["Frågor & Svar"], stripUi: true, cardId: cardRoot.id || null });
    const lines = cardText.split("\n").map((line) => line.trim()).filter(Boolean);
    const contentLines = lines.filter((line) => normalizeInline(line) !== "Fordon inblandat");
    const incidentRoot = document.querySelector("#incident-case-card");
    const incidentVehicleLines = incidentRoot
      ? cleanText(incidentRoot.innerText || "", {
          stopMarkers: ["Frågor & Svar"],
          stripUi: true,
          cardId: incidentRoot.id || null
        }).split("\n").map((line) => line.trim()).filter(Boolean)
      : [];

    if (contentLines.some((line) => /Inget fordon/i.test(line))) {
      return { involved: false, details: null, ...parseVehicleDetailsLines([]) };
    }

    if (contentLines.length === 0) {
      return { involved: null, details: null, ...parseVehicleDetailsLines([]) };
    }

    const parsed = parseVehicleDetailsLines([...contentLines, ...incidentVehicleLines]);
    const tags = [...new Set([
      ...parsed.tags,
      ...parseIncidentVehicleBulletTags(incidentRoot?.innerText || incidentRoot?.textContent || ""),
      ...extractExactVehicleTagsFromDocument(document, [cardRoot, incidentRoot])
    ])];
    return {
      involved: true,
      details: contentLines.join("\n"),
      ...parsed,
      tags,
      isDriver: tags.includes("DRIVER") ? true : parsed.isDriver,
      personInVehicle: tags.includes("DRIVER") || tags.includes("PASSENGER") ? true : parsed.personInVehicle
    };
  }

  function shouldExpandCareProviderDetails(options) {
    return options?.expandCareProviderDetails !== false;
  }

  function shouldExpandSchoolDetails(options) {
    return options?.expandSchoolDetails !== false;
  }

  async function extractCanonicalFritid(options = {}) {
    const url = window.location.href;
    const caseNumber = caseNumberFromUrl(url);
    const cardWaitAttempts = Number.isInteger(options?.cardWaitAttempts)
      ? Math.max(1, Math.min(10, options.cardWaitAttempts))
      : 10;

    const debug = {
      missingExtractors: [],
      unmappedLabels: [],
      parseErrors: [],
      warnings: []
    };

    const customerData = extractClaimant(debug, { caseNumber });
    const caseId = customerData?.caseId || null;

    const canonical = initCanonical({ caseId, caseNumber, url });

    if (customerData) {
      canonical.meta.caseId = customerData.caseId || canonical.meta.caseId;
      canonical.customer.name = customerData.name || null;
      canonical.customer.personNumber = customerData.personNumber || null;
      canonical.customer.email = customerData.email || null;
      // Fallback values (will be overridden by “Anmälan gäller” card when available).
      canonical.claimant.name = customerData.name || null;
      canonical.claimant.personNumber = customerData.personNumber || null;
      canonical.claimant.email = customerData.email || null;
    } else {
      // Fallback: if the data attributes are missing, parse the "Kund" card rows.
      const customerCard = await extractCustomerCard(debug, { caseId, caseNumber, waitAttempts: cardWaitAttempts });
      if (customerCard.rows.length > 0) {
        const { values } = rowsToMap(customerCard.rows);
        const getValue = (label) => values.get(label)?.[0] || null;
        canonical.customer.name = getValue("Namn") || canonical.customer.name;
        canonical.customer.personNumber = normalizePersonNumber(getValue("Personnummer")) || canonical.customer.personNumber;
        canonical.customer.email = getValue("E-post") || canonical.customer.email;
        // Keep the old fallback behavior: if claimant card is missing, at least capture someone.
        if (!canonical.claimant.name && canonical.customer.name) canonical.claimant.name = canonical.customer.name;
        if (!canonical.claimant.personNumber && canonical.customer.personNumber) canonical.claimant.personNumber = canonical.customer.personNumber;
        if (!canonical.claimant.email && canonical.customer.email) canonical.claimant.email = canonical.customer.email;
      }
    }

    // Claimant (“Anmälan gäller”) — primary source for claimant identity.
    const claimantCard = await extractClaimantCard(debug, { caseId, caseNumber, waitAttempts: cardWaitAttempts });
    if (claimantCard.rows.length > 0) {
      const { values } = rowsToMap(claimantCard.rows);
      const getValue = (label) => values.get(label)?.[0] || null;

      const name = getValue("Namn") || getValue("Barnets namn");
      const pn = getValue("Personnummer");
      const ageText = getValue("Ålder vid skadetillfälle");
      const municipality = getValue("Folkbokföringskommun");

      if (name) canonical.claimant.name = name;
      if (pn) canonical.claimant.personNumber = normalizePersonNumber(pn);

      if (ageText) {
        const match = String(ageText).match(/\d+/);
        canonical.claimant.ageAtIncident = match ? Number(match[0]) : null;
      }

      if (municipality) canonical.claimant.municipality = municipality;
    }

    // Overview
    const overview = await extractOverview(debug, { caseId, caseNumber, waitAttempts: cardWaitAttempts });
    if (overview.rows.length > 0) {
      const { values, elements } = rowsToMap(overview.rows);
      const getValue = (label) => values.get(label)?.[0] || null;
      const getElement = (label) => elements.get(label)?.[0] || null;
      const getValueByPattern = (pattern) => {
        const regex = pattern instanceof RegExp ? pattern : null;
        if (!regex) return null;
        for (const key of values.keys()) {
          if (regex.test(String(key || ""))) return values.get(key)?.[0] || null;
        }
        return null;
      };

      const category = getValue("Kategori");
      canonical.meta.category = category || canonical.meta.category;
      canonical.meta.status = getValue("Status") || null;
      const insuranceEl = getElement("Försäkringsärenden");
      const insuranceRaw = insuranceEl
        ? normalizePreserveNewlines(insuranceEl.textContent || "")
        : getValue("Försäkringsärenden");
      if (insuranceRaw && /Inga försäkringsärenden tillagda/i.test(insuranceRaw)) {
        canonical.meta.insuranceMatter.sourceStatus = "EXPLICIT_NONE";
        canonical.meta.insuranceMatter.displayName = null;
        canonical.meta.insuranceMatter.displayNames = [];
        canonical.meta.insuranceMatter.entries = [];
      } else {
        canonical.meta.insuranceMatter.sourceStatus = insuranceRaw ? "LOADED" : "MISSING";
        const insurance = extractInsuranceDisplayName(insuranceEl, insuranceRaw);
        canonical.meta.insuranceMatter.displayName = insurance.displayName;
        canonical.meta.insuranceMatter.displayNames = insurance.displayNames;
        canonical.meta.insuranceMatter.entries = insurance.entries;
      }
      canonical.meta.createdAt = getValue("Ärende skapades") || null;
      canonical.meta.createdByName =
        getValue("Skapad av") ||
        getValue("Skapat av") ||
        getValue("Ärende skapades av") ||
        getValueByPattern(/skapad av/i) ||
        null;
      canonical.meta.readyAt = getValue("Ärende blev redo") || null;

      const fullmaktEl = getElement("Fullmakt");
      const fullmaktLinks = fullmaktEl ? Array.from(fullmaktEl.querySelectorAll("a")) : [];
      const pdfLink = fullmaktLinks.find((link) =>
        /pdf/i.test(normalizeInline(link.textContent || ""))
      );
      if (pdfLink?.href) {
        canonical.meta.powerOfAttorneyPdfUrl = pdfLink.href;
      } else if (fullmaktLinks.length > 0) {
        const hasScrive = fullmaktLinks.some((link) =>
          /scrive/i.test(normalizeInline(link.textContent || ""))
        );
        if (hasScrive) {
          debug.warnings.push("Fullmakt has Scrive link but no PDF link was captured");
        }
      }

      const portalEl = getElement("Kundens Mina Sidor");
      const portalLink = portalEl ? portalEl.querySelector("a") : null;
      if (portalLink?.href) canonical.meta.customerPortalUrl = portalLink.href;
    }
    canonical.meta.insuranceMatter.cards = extractInsuranceCards();
    canonical.meta.selfDeclarationPdfs = extractSelfDeclarationPdfs();

    // School address and operator details are hidden behind “Mer information om skola”.
    // Expand once before parsing the incident/employment cards so all workflows share the data.
    if (shouldExpandSchoolDetails(options)) {
      await expandSchoolDetails(debug);
    }

    // Incident
    const incidentRows = extractIncident(debug, { caseId, caseNumber });
    if (incidentRows.length > 0) {
      let schoolInfo = null;
      for (const row of incidentRows) {
        switch (row.label) {
          case "Händelsen inträffade":
            canonical.incident.context = row.value || null;
            if (/\butomlands\b|\babroad\b/i.test(normalizeInline(row.value || ""))) {
              canonical.incident.abroad = true;
            }
            break;
          case "Plats där händelsen inträffade":
            canonical.incident.place = row.value || null;
            break;
          case "Land":
          case "Land där händelsen inträffade":
            canonical.incident.country = row.value || null;
            break;
          case "Datum och tidpunkt": {
            const parsed = parseSwedishDateTime(row.value);
            canonical.incident.date = parsed.date;
            canonical.incident.time = parsed.time;
            break;
          }
          case "Beskrivning":
            canonical.incident.description = row.value || null;
            break;
          case "Övrig information från kund":
            canonical.incident.customerAdditionalInfo = row.value || null;
            break;
          case "Kompletteringar":
            canonical.incident.supplements = row.value || null;
            break;
          case "Skola":
          case "Skolans adress":
          case "Skoladress":
          case "Skolans postadress":
          case "Skolans gatuadress":
          case "Skolans postnummer och ort":
          case "Verksamhetens adress":
          case "Adress till skolan":
          case "Utbildningsnivå":
          case "Skolans försäkringstagare":
          case "Besöksadress":
            schoolInfo = applySchoolFieldRow(schoolInfo, row);
            break;
          case "Idrott":
            canonical.incident.sport.sportType = row.value || null;
            break;
          case "Klubb":
            canonical.incident.sport.club = row.value || null;
            break;
          case "Serie":
            canonical.incident.sport.league = row.value || null;
            break;
          case "Träningsanläggning":
            canonical.incident.sport.trainingFacility = row.value || null;
            // Sports cases often use this instead of generic "Plats där händelsen inträffade".
            if (!canonical.incident.place) canonical.incident.place = row.value || null;
            break;
          case "Roll":
            canonical.incident.sport.role = row.value || null;
            break;
          case "Typ av idrottare":
            canonical.incident.sport.athleteType = row.value || null;
            break;
        }
      }
      if (schoolInfo) {
        canonical.incident.school = schoolInfo;
      }
    }

    const incidentQaRows = extractIncidentQaRows(debug, { caseId, caseNumber });
    if (incidentQaRows.length > 0) {
      let previousQaKey = "";
      for (const row of incidentQaRows) {
        const qaKey = normalizeQaLabel(row.label);
        const yesNo = toBool(row.value);

        if (qaKey.includes("har lakare anlitats")) {
          canonical.incident.hasDoctorVisit = yesNo;
        } else if (qaKey.includes("lakarens namn")) {
          canonical.incident.firstDoctorName = row.value || null;
        } else if (qaKey.includes("har skadan gipsats")) {
          canonical.incident.gipsed = yesNo;
        } else if (qaKey.includes("gipsbehandlingen")) {
          canonical.incident.gipsWeeks = row.value || null;
        } else if (qaKey.includes("ordinerat skolskjuts")) {
          canonical.incident.schoolTransportOrdered = yesNo;
        } else if (qaKey.includes("inlagd pa sjukhus")) {
          canonical.incident.hospitalized = yesNo;
        } else if (qaKey.includes("period har du legat pa sjukhus") && qaKey.includes("fran")) {
          canonical.incident.hospitalizedFrom = row.value || null;
        } else if (qaKey.includes("period har du legat pa sjukhus") && qaKey.includes("till")) {
          canonical.incident.hospitalizedTo = row.value || null;
        } else if (qaKey.includes("polisanmalan gjorts")) {
          canonical.incident.policeReported = yesNo;
        } else if (qaKey.includes("skadad kroppsdel tidigare varit utsatt")) {
          canonical.incident.previousInjuryHad = yesNo;
        } else if (isPreviousInjuryDateQaRow(qaKey, previousQaKey)) {
          canonical.incident.previousInjuryDate = row.value || null;
        } else if (qaKey.includes("anlitades lakare")) {
          canonical.incident.previousInjuryDoctorConsulted = yesNo;
        } else if (qaKey.includes("beskriv den tidigare skadan") || qaKey.includes("beskriv den tidigare skada")) {
          canonical.incident.previousInjuries = row.value || null;
        } else if (
          qaKey.includes("paverkad av alkohol") ||
          qaKey.includes("annat rusningsmedel") ||
          qaKey.includes("medicin")
        ) {
          canonical.incident.intoxicatedAtAccident = yesNo;
        } else if (qaKey.includes("berors annan forsakring")) {
          canonical.otherAccidentInsurance.hasOther = yesNo;
        } else if (qaKey.includes("vilken typ av forsakring")) {
          canonical.otherAccidentInsurance.type = row.value || null;
        } else if (qaKey.includes("anmalan gjorts till annat forsakringsbolag")) {
          canonical.otherAccidentInsurance.reported = yesNo;
        } else if (qaKey.includes("skadenummer")) {
          canonical.otherAccidentInsurance.claimNumber = row.value || null;
        } else if (qaKey.includes("om ja vilket bolag")) {
          // Reused wording in two places; prioritize insurer fields for "annan försäkring".
          canonical.otherAccidentInsurance.insurer = row.value || null;
        } else if (qaKey.startsWith("om ja vilket") && previousQaKey.includes("inlagd pa sjukhus")) {
          canonical.incident.hospitalizedWhere = row.value || null;
        }

        previousQaKey = qaKey;
      }
    }

    // Injuries
    const injuryRows = extractInjuries(debug, { caseId, caseNumber });
    for (const row of injuryRows) {
      if (row.label === "Kroppsskador") {
        canonical.injuries.bodyInjuries = splitListValue(row.value);
        canonical.injuries.consequencesEvidence = Array.isArray(row.consequencesEvidence)
          ? row.consequencesEvidence
          : [];
        canonical.injuries.consequencesEvidenceComplete = row.consequencesEvidenceComplete === true;
        canonical.injuries.consequenceSourceTexts = Array.isArray(row.consequenceSourceTexts)
          ? row.consequenceSourceTexts
          : [];
      } else if (row.label === "Kvarstående besvär") {
        canonical.injuries.residualIssues = splitListValue(row.value);
      }
    }

    // Employment (optional)
    const employmentRows = extractEmployment(debug, { caseId, caseNumber });
    for (const row of employmentRows) {
      if (row.label === "Sysselsättning") canonical.employment.employmentStatus = row.value || null;
      if (row.label === "Arbetsgivare") canonical.employment.employer = row.value || null;
      if (row.label === "Medlem i fack") canonical.employment.unionMemberText = row.value || null;
      if (row.label === "Detaljer") canonical.employment.details = row.value || null;
      // Some cases put school fields here instead of under the Incident card.
      if (ALLOWED_LABELS.employment.has(row.label) && [
        "Skola",
        "Skolans adress",
        "Skoladress",
        "Skolans postadress",
        "Skolans gatuadress",
        "Skolans postnummer och ort",
        "Verksamhetens adress",
        "Adress till skolan",
        "Utbildningsnivå",
        "Skolans försäkringstagare",
        "Besöksadress"
      ].includes(row.label)) {
        canonical.incident.school = applySchoolFieldRow(canonical.incident.school, row);
      }
    }

    // Care providers
    if (options.skipCareExtraction !== true && shouldExpandCareProviderDetails(options)) {
      await expandCareProviderDetails(debug);
    }
    const care = options.skipCareExtraction === true ? { providers: [] } : extractCareProviders(debug, { caseId, caseNumber });
    canonical.care.providers = care.providers || [];
    canonical.care.journalCoverSheetUrl = care.journalCoverSheetUrl || null;
    canonical.care.additionalProvidersReportedCount = options.skipCareExtraction === true ? null : extractAdditionalCareProvidersReportedCount();

    // Fallback: some CRM variants store inpatient stay only inside care visits (reason: "Inlagd").
    // Keep incident QA as source of truth and only fill missing values.
    const hospitalizationFromCare = deriveHospitalizationFromCareProviders(canonical.care.providers);
    if (canonical.incident.hospitalized == null && hospitalizationFromCare.hospitalized != null) {
      canonical.incident.hospitalized = hospitalizationFromCare.hospitalized;
    }
    if (!canonical.incident.hospitalizedWhere && hospitalizationFromCare.hospitalizedWhere) {
      canonical.incident.hospitalizedWhere = hospitalizationFromCare.hospitalizedWhere;
    }
    if (!canonical.incident.hospitalizedFrom && hospitalizationFromCare.hospitalizedFrom) {
      canonical.incident.hospitalizedFrom = hospitalizationFromCare.hospitalizedFrom;
    }
    if (!canonical.incident.hospitalizedTo && hospitalizationFromCare.hospitalizedTo) {
      canonical.incident.hospitalizedTo = hospitalizationFromCare.hospitalizedTo;
    }

    // Treatments
    const treatments = extractTreatments(debug, { caseId, caseNumber });
    canonical.treatments.performed = treatments.performed || [];
    canonical.treatments.planned = treatments.planned || { status: null, details: null, followUpDate: null };

    // Sick leave (Sjukskrivning)
    const sickLeave = extractSickLeave(debug, { caseId, caseNumber });
    canonical.sickLeave = sickLeave;

    // Expenses
    const expensesResult = extractExpenses(debug, { caseId, caseNumber });
    canonical.expenses = expensesResult.items;
    canonical.expensesMeta.carTravelMiles = expensesResult.meta.carTravelMiles;
    canonical.expensesMeta.sourceStatus = expensesResult.meta.sourceStatus || null;

    // Vehicle
    const vehicle = extractVehicle(debug, { caseId, caseNumber });
    canonical.vehicle.involved = vehicle.involved;
    canonical.vehicle.details = vehicle.details;
    canonical.vehicle.registrationNumber = vehicle.registrationNumber;
    canonical.vehicle.crmType = vehicle.crmType;
    canonical.vehicle.tags = vehicle.tags;
    canonical.vehicle.personInVehicle = vehicle.personInVehicle;
    canonical.vehicle.isDriver = vehicle.isDriver;
    canonical.vehicle.policeReported = vehicle.policeReported;

    const missingRequiredFields = [];
    const customerDigits = String(canonical.customer.personNumber || "").replace(/\D/g, "");
    const claimantDigits = String(canonical.claimant.personNumber || "").replace(/\D/g, "");
    const identitiesDiffer = customerDigits && claimantDigits
      ? customerDigits !== claimantDigits
      : normalizeInline(canonical.customer.name) && normalizeInline(canonical.claimant.name)
      ? normalizeInline(canonical.customer.name).toLocaleLowerCase("sv-SE") !== normalizeInline(canonical.claimant.name).toLocaleLowerCase("sv-SE")
      : false;
    if (identitiesDiffer) {
      canonical.reporter.name = canonical.customer.name || null;
      canonical.reporter.personNumber = canonical.customer.personNumber || null;
      canonical.reporter.email = canonical.customer.email || null;
      canonical.reporter.source = "customer";
    }
    if (!canonical.claimant.name) missingRequiredFields.push("claimant.name");
    if (!canonical.claimant.personNumber) missingRequiredFields.push("claimant.personNumber");
    if (!canonical.incident.date) missingRequiredFields.push("incident.date");
    if (!canonical.incident.time) missingRequiredFields.push("incident.time");

    const warnings = {
      missingExtractors: debug.missingExtractors,
      unmappedLabels: debug.unmappedLabels,
      missingRequiredFields,
      parseErrors: debug.parseErrors,
      warnings: debug.warnings,
      claimantSource: debug.claimantSource || null
    };

    return { canonical: pruneCanonical(canonical), warnings };
  }

  return {
    extractCanonicalFritid,
    __test: {
      findProviderBlockRoot,
      extractProviderInfoFromSection,
      pruneCanonical,
      initCanonical,
      extractInsuranceEntries,
      extractInsuranceCards,
      extractInsuranceCardFromText,
      extractSelfDeclarationPdfInfoFromText,
      extractAdditionalCareProvidersReportedCount,
      parseTreatmentsPlannedFromLines,
      parsePerformedTreatmentEntryLines,
      parseSickLeaveFromInputs,
      parsePercentMax,
      isPreviousInjuryDateQaRow,
      parseVisitsGridCells,
      isCareProviderMoreInfoText,
      shouldExpandCareProviderDetails,
      extractCareProviderAddressDetails,
      deriveHospitalizationFromCareProviders,
      extractPrimaryInjuryHeadings,
      extractKnownInjuryConsequences,
      classifyInjuryDetailEvidence,
      assessInjuryConsequenceSources,
      extractInjuryDetailTextsFromCardText,
      extractInjuryDetailTextsFromValueElement,
      findExactLabelValuePairs,
      extractInjuries,
      getCompleteInjuryCardText,
      parseVehicleDetailsLines,
      extractExactVehicleTagsFromDocument,
      parseIncidentVehicleBulletTags,
      applySchoolFieldRow,
      isSchoolMoreInfoText,
      hasExpandedSchoolDetails,
      expandSchoolDetails,
      shouldExpandSchoolDetails
    }
  };
});
