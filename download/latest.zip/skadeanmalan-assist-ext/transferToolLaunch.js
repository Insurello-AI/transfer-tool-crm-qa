(function (root, factory) {
  const api = factory();

  root.__crmTransferToolLaunch = api;

  if (typeof module === "object" && module && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const SCHEMA_ID = "transfer_tool_launch_v1";
  const SCHEMA_VERSION = 1;
  const SCHOOL_CERTIFICATE_TEMPLATE_ID = "school_certificate_v1";

  function normalizeInline(text) {
    return String(text ?? "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeMatterText(text) {
    return normalizeInline(text)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[‐‑‒–—-]+/g, " ")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function uniqueNonEmptyStrings(values) {
    const seen = new Set();
    const result = [];
    for (const value of Array.isArray(values) ? values : []) {
      const text = normalizeInline(value);
      if (!text || seen.has(text)) continue;
      seen.add(text);
      result.push(text);
    }
    return result;
  }

  // The CRM extractor intentionally keeps a rich canonical object for
  // extension-side diagnostics.  That object must not be forwarded wholesale
  // to a web page: a page script can observe a MAIN-world CustomEvent.  The
  // handoff projections below are explicit allowlists for each destination.
  // The new caseInputs envelope is separately scoped/validated for our browser
  // case context; consumers still receive only their PDF/portal projection.
  function hasOwn(source, key) {
    return Boolean(source && Object.prototype.hasOwnProperty.call(source, key));
  }

  function pickDefined(source, keys) {
    if (!source || typeof source !== "object" || Array.isArray(source)) return {};
    const result = {};
    for (const key of keys) {
      if (!hasOwn(source, key)) continue;
      const value = source[key];
      if (value === undefined || value === null) continue;
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        result[key] = value;
      } else if (Array.isArray(value)) {
        const scalarValues = value.filter(
          item => typeof item === "string" || typeof item === "number" || typeof item === "boolean"
        );
        if (scalarValues.length > 0) result[key] = scalarValues;
      }
    }
    return result;
  }

  function setIfPresent(target, key, value) {
    if (value === undefined || value === null) return;
    if (Array.isArray(value) && value.length === 0) return;
    if (typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 0) return;
    target[key] = value;
  }

  function projectAddress(value) {
    if (typeof value === "string") return normalizeInline(value) || null;
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    return pickDefined(value, [
      "street",
      "streetAddress",
      "addressLine1",
      "addressLine",
      "postalAddress",
      "postalCodeAndCity",
      "postalCode",
      "postalCity",
      "city"
    ]);
  }

  function projectSchool(school) {
    if (!school || typeof school !== "object") return null;
    const result = pickDefined(school, [
      "name",
      "policyholder",
      "municipality",
      "addressLine",
      "streetAddress",
      "postalAddress",
      "postalCode",
      "city",
      "locality"
    ]);
    const address = projectAddress(school.address);
    if (address && (typeof address === "string" || Object.keys(address).length > 0)) result.address = address;
    return result;
  }

  function projectSport(sport) {
    if (!sport || typeof sport !== "object") return null;
    const result = pickDefined(sport, ["sportType", "club", "trainingFacility"]);
    const clubAddress = projectAddress(sport.clubAddress);
    const address = projectAddress(sport.address);
    if (clubAddress && (typeof clubAddress === "string" || Object.keys(clubAddress).length > 0)) {
      result.clubAddress = clubAddress;
    }
    if (address && (typeof address === "string" || Object.keys(address).length > 0)) result.address = address;
    for (const key of ["clubStreetAddress", "streetAddress", "clubPostalAddress", "postalCode", "city"]) {
      if (!hasOwn(sport, key)) continue;
      const value = sport[key];
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") result[key] = value;
    }
    return result;
  }

  function projectSportForSkadeanmalan(sport) {
    if (!sport || typeof sport !== "object") return null;
    return pickDefined(sport, ["sportType"]);
  }

  function projectInsuranceEntries(insurance) {
    if (!insurance || typeof insurance !== "object") return [];
    return Array.isArray(insurance.entries)
      ? insurance.entries
          .map(entry => pickDefined(entry, ["displayName", "statusText", "stateTitle", "stateKind"]))
          .filter(entry => Object.keys(entry).length > 0)
      : [];
  }

  function projectInsuranceMatter(insurance, { includeCards = false } = {}) {
    if (!insurance || typeof insurance !== "object") return null;
    const result = pickDefined(insurance, ["displayName", "displayNames", "sourceStatus", "insurer", "product"]);
    const entries = projectInsuranceEntries(insurance);
    if (entries.length > 0) result.entries = entries;
    if (includeCards) {
      const cards = Array.isArray(insurance.cards)
        ? insurance.cards
            .map(card => pickDefined(card, ["insurer", "product", "displayName", "claimNumber"]))
            .filter(card => Object.keys(card).length > 0)
        : [];
      if (cards.length > 0) result.cards = cards;
    }
    return result;
  }

  function projectCare(care) {
    if (!care || typeof care !== "object") return null;
    const result = pickDefined(care, ["additionalProvidersReportedCount", "firstVisitState"]);
    const providers = Array.isArray(care.providers)
      ? care.providers
          .map(provider => {
            const projected = pickDefined(provider, ["providerType", "providerName"]);
            const visits = Array.isArray(provider?.visits)
              ? provider.visits
                  .map(visit => pickDefined(visit, ["date", "dateFrom", "dateTo", "reason", "department", "isFirstVisit"]))
                  .filter(visit => Object.keys(visit).length > 0)
              : [];
            if (visits.length > 0) projected.visits = visits;
            return projected;
          })
          .filter(provider => Object.keys(provider).length > 0)
      : [];
    if (providers.length > 0) result.providers = providers;
    return result;
  }

  function projectStringList(value) {
    if (Array.isArray(value)) {
      return value
        .filter(item => typeof item === "string" || typeof item === "number" || typeof item === "boolean")
        .map(item => normalizeInline(item))
        .filter(Boolean);
    }
    if (typeof value === "string") {
      return value.split(/\r?\n/g).map(item => normalizeInline(item)).filter(Boolean);
    }
    return [];
  }

  const VEHICLE_REGISTRATION_LABEL = /^(?:registreringsnummer|regnr)(?=$|[\s:\-])\s*[:\-]?\s*/i;

  // A plate-shaped value: letters/digits with optional inner spaces or
  // hyphens, 2-8 significant characters, containing a digit or written in
  // capitals (personalized plates). Anything else is treated as free text.
  function plateLikeValue(text) {
    const leading = normalizeInline(text).match(/^[A-Za-zÅÄÖåäö0-9][A-Za-zÅÄÖåäö0-9 \-]*/);
    if (!leading) return null;
    const value = leading[0].replace(/[\s\-]+$/, "");
    const compact = value.replace(/[\s\-]/g, "");
    if (compact.length < 2 || compact.length > 8) return null;
    if (!/\d/.test(compact) && compact !== compact.toUpperCase()) return null;
    if (["ej angivet", "inte angivet", "okant", "saknas", "n a", "na"].includes(normalizeMatterText(value))) return null;
    return value;
  }

  function projectVehicle(vehicle) {
    const result = pickDefined(vehicle, ["registrationNumber"]);
    if (result.registrationNumber || typeof vehicle?.details !== "string") return result;
    // Legacy CRM cards can put the plate in a labelled text block. Forward
    // only the plate-shaped value from the labelled line (or the line after
    // it), never the private block itself.
    const lines = vehicle.details.split(/\r?\n/g).map(line => normalizeInline(line)).filter(Boolean);
    for (let i = 0; i < lines.length; i += 1) {
      const label = lines[i].match(VEHICLE_REGISTRATION_LABEL);
      if (!label) continue;
      const sameLine = lines[i].slice(label[0].length);
      const plate = sameLine ? plateLikeValue(sameLine) : plateLikeValue(lines[i + 1] ?? "");
      if (plate) result.registrationNumber = plate;
      break;
    }
    return result;
  }

  function projectCanonicalForSkadeanmalan(canonical) {
    if (!canonical || typeof canonical !== "object") return {};
    const result = {};
    const meta = pickDefined(canonical.meta, ["caseId", "caseNumber", "createdByName"]);
    const insuranceEntries = projectInsuranceEntries(canonical?.meta?.insuranceMatter);
    if (insuranceEntries.length > 0) meta.insuranceMatter = { entries: insuranceEntries };
    setIfPresent(result, "meta", meta);

    setIfPresent(result, "customer", pickDefined(canonical.customer, ["name", "personNumber"]));
    setIfPresent(
      result,
      "claimant",
      pickDefined(canonical.claimant, [
        "name",
        "personNumber",
        "municipality",
        "address",
        "streetAddress",
        "addressLine",
        "postalCode",
        "postnummer",
        "zip",
        "zipCode",
        "postalCity",
        "postort",
        "city",
        "town"
      ])
    );
    setIfPresent(result, "employment", pickDefined(canonical.employment, ["employer"]));

    const incident = pickDefined(canonical.incident, [
      "context",
      "date",
      "time",
      "place",
      "description",
      "schoolName",
      "schoolAddress",
      "hasDoctorVisit",
      "firstDoctorName",
      "firstDoctorVisitDate",
      "doctorVisitDate",
      "gipsed",
      "gipsWeeks",
      "schoolTransportOrdered",
      "hospitalized",
      "hospitalizedWhere",
      "hospitalName",
      "hospitalizedFrom",
      "hospitalizedTo",
      "policeReported",
      "previousInjuryHad",
      "previousInjuryDate",
      "previousInjuries",
      "previousInjuriesDate",
      "previousInjuryDoctorConsulted",
      "previousInjuryDoctorVisited",
      "previousInjuryDoctorDetails",
      "previousInjuryDoctorName",
      "previousInjuryDoctor",
      "intoxicatedAtAccident",
      "fullyRecovered",
      "activityDescription",
      "hasOtherAccidentInsurance"
    ]);
    setIfPresent(incident, "school", projectSchool(canonical?.incident?.school));
    setIfPresent(incident, "sport", projectSportForSkadeanmalan(canonical?.incident?.sport));
    setIfPresent(result, "incident", incident);

    const injuries = {};
    const bodyInjuries = projectStringList(canonical?.injuries?.bodyInjuries);
    const residualIssues = projectStringList(canonical?.injuries?.residualIssues);
    setIfPresent(injuries, "bodyInjuries", bodyInjuries);
    setIfPresent(injuries, "residualIssues", residualIssues);
    setIfPresent(result, "injuries", injuries);

    setIfPresent(result, "care", projectCare(canonical.care));
    const plannedTreatment = pickDefined(canonical?.treatments?.planned, ["status"]);
    if (Object.keys(plannedTreatment).length > 0) {
      result.treatments = { planned: plannedTreatment };
    }
    setIfPresent(result, "sickLeave", pickDefined(canonical.sickLeave, ["hasSickLeave", "date", "dateFrom", "dateTo", "maxPercent"]));

    const expenses = Array.isArray(canonical.expenses)
      ? canonical.expenses
          .map(expense => pickDefined(expense, ["type", "date", "amount", "currency"]))
          .filter(expense => Object.keys(expense).length > 0)
      : [];
    setIfPresent(result, "expenses", expenses);
    setIfPresent(result, "expensesMeta", pickDefined(canonical.expensesMeta, ["carTravelMiles"]));
    setIfPresent(result, "vehicle", projectVehicle(canonical.vehicle));
    setIfPresent(
      result,
      "otherAccidentInsurance",
      pickDefined(canonical.otherAccidentInsurance, [
        "hasOther",
        "insurer",
        "reportedInsurer",
        "type",
        "reported",
        "claimNumber",
        "policyNumber",
        "insuranceNumber",
        "forsakringsnummer"
      ])
    );
    setIfPresent(result, "otherReportedClaim", pickDefined(canonical.otherReportedClaim, ["reported", "insurer", "claimNumber", "skadenummer"]));
    setIfPresent(result, "trafficInsurance", pickDefined(canonical.trafficInsurance, ["reported", "insurer", "registrationNumber"]));
    setIfPresent(result, "tfa", pickDefined(canonical.tfa, ["reported"]));
    setIfPresent(result, "policyholder", pickDefined(canonical.policyholder, ["insuranceNumber"]));
    setIfPresent(result, "insurance", pickDefined(canonical.insurance, ["policyNumber", "insuranceNumber"]));
    return result;
  }

  // Trygg-Hansa Egenintyg and Hälsofullmakt: the handler's case, the signer
  // (and the insured child when they differ), the accident description for the
  // prefill, and the care providers with their addresses and visits for the
  // HFM provider list and the first-visit prefill. Nothing else crosses.
  function projectCareForTrygghansa(care) {
    if (!care || typeof care !== "object") return null;
    const result = pickDefined(care, ["additionalProvidersReportedCount"]);
    const providers = Array.isArray(care.providers)
      ? care.providers
          .map(provider => {
            const projected = pickDefined(provider, [
              "providerName",
              "providerType",
              "postalAddress",
              "journalAddress",
              "visitAddress"
            ]);
            const visits = Array.isArray(provider?.visits)
              ? provider.visits
                  .map(visit => pickDefined(visit, ["date", "dateFrom", "dateTo", "department", "isFirstVisit"]))
                  .filter(visit => Object.keys(visit).length > 0)
              : [];
            if (visits.length > 0) projected.visits = visits;
            return projected;
          })
          .filter(provider => Object.keys(provider).length > 0)
      : [];
    if (providers.length > 0) result.providers = providers;
    return result;
  }

  function projectCanonicalForTrygghansaEgenintyg(canonical) {
    if (!canonical || typeof canonical !== "object") return {};
    const result = {};
    setIfPresent(result, "meta", pickDefined(canonical.meta, ["caseNumber"]));
    setIfPresent(result, "customer", pickDefined(canonical.customer, ["name", "personNumber"]));
    setIfPresent(result, "claimant", pickDefined(canonical.claimant, ["name", "personNumber"]));
    setIfPresent(result, "incident", pickDefined(canonical.incident, ["description"]));
    setIfPresent(result, "care", projectCareForTrygghansa(canonical.care));
    return result;
  }

  function projectCanonicalForEndgame(canonical) {
    if (!canonical || typeof canonical !== "object") return {};
    const result = {};
    setIfPresent(result, "meta", pickDefined(canonical.meta, ["caseId", "caseNumber"]));
    setIfPresent(result, "customer", pickDefined(canonical.customer, ["name", "personNumber"]));
    setIfPresent(result, "claimant", pickDefined(canonical.claimant, ["name", "personNumber"]));
    const incident = pickDefined(canonical.incident, ["date", "schoolAddress", "clubAddress"]);
    setIfPresent(incident, "school", projectSchool(canonical?.incident?.school));
    setIfPresent(incident, "sport", projectSport(canonical?.incident?.sport));
    setIfPresent(result, "incident", incident);
    return result;
  }

  const HANDOFF_HANDelse_LABELS = new Set([
    "namn",
    "personnummer",
    "adress",
    "utdelningsadress",
    "utdelningsadress om annan än folkbokföringsadress",
    "postnummer",
    "postort",
    "händelsedatum",
    "datum för olycksfallet",
    "vilket datum hände olycksfallet",
    "tidpunkt",
    "klockslag",
    "klockslag för olycksfallet",
    "händelseförlopp",
    "händelseförlopp / beskrivning",
    "var befann du när olycksfallet hände och hur gick det till",
    "vilken kroppsskada blev följden",
    "datum för första läkar-/tandläkarbesök",
    "ange namn och adress till samtliga vårdinrättningar du har varit hos",
    "har denna kroppsdel varit skadad förut ange när och hur",
    "kompletteringar",
    "befaras framtida men",
    "skola",
    "förskola",
    "verksamhet",
    "skolanförskolanverksamhetens namn",
    "skolans adress",
    "skoladress",
    "skolans postadress",
    "verksamhetens adress",
    "adress till skolan",
    "berörs annan försäkring",
    "om ja vilket bolag",
    "vilken typ av försäkring",
    "har anmälan gjorts till annat försäkringsbolag",
    "skadenummer",
    "ange fordonets regnr samt försäkringsbolag"
  ]);

  function normalizeHandoffHandelseLabel(label) {
    return String(label ?? "")
      .toLowerCase()
      .replace(/[.:]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isSafeHandoffHandelseLabel(label) {
    const normalized = normalizeHandoffHandelseLabel(label);
    if (!normalized || /e-?post|email|telefon|bank|konto|adresshistorik|journal/.test(normalized)) return false;
    return HANDOFF_HANDelse_LABELS.has(normalized) || normalized.includes("personnummer") || normalized.includes("namn");
  }

  function projectHandelseValue(value, { list = false } = {}) {
    if (list && Array.isArray(value)) {
      return value
        .map(item => {
          if (item && typeof item === "object" && !Array.isArray(item)) {
            return pickDefined(item, ["date", "text"]);
          }
          if (typeof item === "string" || typeof item === "number" || typeof item === "boolean") return item;
          return null;
        })
        .filter(item => item !== null && (typeof item !== "object" || Object.keys(item).length > 0));
    }
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
    if (Array.isArray(value)) {
      return value.filter(item => typeof item === "string" || typeof item === "number" || typeof item === "boolean");
    }
    return null;
  }

  function buildSkadeanmalanHandelseHandoffPayload(handelse) {
    if (!handelse || typeof handelse !== "object") return { card: "Händelse", fields: {}, lists: {} };
    const fields = {};
    for (const [label, value] of Object.entries(handelse.fields || {})) {
      if (!isSafeHandoffHandelseLabel(label)) continue;
      const projected = projectHandelseValue(value);
      if (projected !== null && projected !== "") fields[label] = projected;
    }
    const lists = {};
    for (const [label, value] of Object.entries(handelse.lists || {})) {
      if (!isSafeHandoffHandelseLabel(label)) continue;
      const projected = projectHandelseValue(value, { list: true });
      if (projected !== null && (!Array.isArray(projected) || projected.length > 0)) lists[label] = projected;
    }
    return { card: "Händelse", fields, lists };
  }

  function buildSkadeanmalanHandoffPayload({ canonical, handelse, caseInputs } = {}) {
    if (canonical && typeof canonical === "object") {
      const payload = { canonical: projectCanonicalForSkadeanmalan(canonical) };
      if (caseInputs) {
        const reader = globalThis.__crmCaseProbe || (typeof require === "function" ? require("./crmCaseProbe.js") : null);
        if (!reader) throw new Error("Ärendeunderlagets överföringskontrakt saknas.");
        payload.caseInputs = reader.caseHandoff(caseInputs);
        if (String(payload.canonical.meta?.caseId) !== payload.caseInputs.source.caseId) throw new Error("RESPONSE_CASE_MISMATCH");
        if (new TextEncoder().encode(JSON.stringify(payload)).length > 6 * 1024 * 1024) throw new Error("HANDOFF_TOO_LARGE");
      }
      return payload;
    }
    return buildSkadeanmalanHandelseHandoffPayload(handelse);
  }

  function countProviders(canonical) {
    const providers = Array.isArray(canonical?.care?.providers) ? canonical.care.providers : [];
    return providers.filter((provider) => normalizeInline(provider?.providerName) || Array.isArray(provider?.visits)).length;
  }

  function countVisits(canonical) {
    const providers = Array.isArray(canonical?.care?.providers) ? canonical.care.providers : [];
    return providers.reduce((sum, provider) => sum + (Array.isArray(provider?.visits) ? provider.visits.length : 0), 0);
  }

  function getAdditionalProvidersReportedCount(canonical) {
    const value = canonical?.care?.additionalProvidersReportedCount;
    return Number.isFinite(value) ? value : null;
  }

  function buildTransferToolLaunchPayload({ canonical } = {}) {
    if (!canonical || typeof canonical !== "object") {
      throw new Error("Canonical payload saknas.");
    }

    const providerCount = countProviders(canonical);
    const visitCount = countVisits(canonical);
    const additionalProvidersReportedCount = getAdditionalProvidersReportedCount(canonical);
    const launchWarnings = uniqueNonEmptyStrings([
      providerCount === 0 ? "Inga vårdinrättningar hittades i CRM-ärendet." : null,
      additionalProvidersReportedCount && additionalProvidersReportedCount > 0
        ? `CRM anger ${additionalProvidersReportedCount} ytterligare vårdinrättningar som inte är utvecklade i den synliga listan.`
        : null
    ]);

    return {
      schemaId: SCHEMA_ID,
      schemaVersion: SCHEMA_VERSION,
      source: "crm-extension",
      workflow: "trygghansa_egenintyg",
      // The full canonical object stays inside the extension. The page receives
      // only the fields Trygg-Hansa Egenintyg and Hälsofullmakt use.
      canonical: projectCanonicalForTrygghansaEgenintyg(canonical),
      launch: {
        caseNumber: canonical?.meta?.caseNumber || null,
        providerCount,
        visitCount,
        additionalProvidersReportedCount
      },
      warnings: {
        launchWarnings
      }
    };
  }

  function buildEndgameIntygLaunchPayload({
    canonical,
    warnings = null,
    preferredTemplateId = null
  } = {}) {
    if (!canonical || typeof canonical !== "object") {
      throw new Error("Canonical payload saknas.");
    }

    const launchWarnings = uniqueNonEmptyStrings([
      canonical?.meta?.caseNumber ? null : "Insurellos ärendenummer saknas i CRM-payloaden.",
      canonical?.claimant?.name || canonical?.customer?.name ? null : "Kundens namn saknas i CRM-payloaden.",
      canonical?.claimant?.personNumber || canonical?.customer?.personNumber ? null : "Personnummer saknas i CRM-payloaden.",
      canonical?.incident?.date ? null : "Skadedatum saknas i CRM-payloaden.",
      preferredTemplateId === SCHOOL_CERTIFICATE_TEMPLATE_ID && !canonical?.incident?.school?.name
        ? "Skola saknas i CRM-payloaden."
        : null
    ]);

    return {
      schemaId: SCHEMA_ID,
      schemaVersion: SCHEMA_VERSION,
      source: "crm-extension",
      workflow: "endgame_intyg",
      ...(preferredTemplateId ? { preferredTemplateId } : {}),
      canonical: projectCanonicalForEndgame(canonical),
      launch: {
        caseNumber: canonical?.meta?.caseNumber || null
      },
      warnings: {
        launchWarnings
      }
    };
  }

  return {
    SCHEMA_ID,
    SCHEMA_VERSION,
    SCHOOL_CERTIFICATE_TEMPLATE_ID,
    buildSkadeanmalanHandelseHandoffPayload,
    buildSkadeanmalanHandoffPayload,
    buildEndgameIntygLaunchPayload,
    buildTransferToolLaunchPayload,
    countProviders,
    countVisits,
    getAdditionalProvidersReportedCount,
    projectCanonicalForEndgame,
    projectCanonicalForSkadeanmalan,
    projectCanonicalForTrygghansaEgenintyg
  };
});
