globalThis.__TRANSFER_TOOL_BUILD_REVISION = "f853e82ca872aa0ee92912528b0588296a66cf76";
/*
 * Handler background for Skadeanmälan Assist: Skadeanmälan, Folksam Portal,
 * Skapa intyg (Endgame Intyg), Egenintyg and Protector. The QA build loads
 * this file unchanged and adds its diagnostics through
 * globalThis.__transferToolExtraMessageHandlers.
 */

importScripts(
  "/folksamPortal.js",
  "/transferToolLaunch.js",
  "/crmCaseProbe.js",
  "/workflowMode.js",
  "/protectorConfig.js",
  "/protectorCanonicalAdapters.js",
  "/protectorCrmCrosswalk.js",
  "/protectorSportCrosswalk.js",
  "/protectorInsurerCrosswalk.js",
  "/protectorSemanticCoverage.js",
  "/protectorPlan.js",
  "/protectorContracts.js"
);

const BUILD_FLAVOR = globalThis.__TRANSFER_TOOL_BUILD_FLAVOR || "stable";
const STOP_HEADING_TEXT = "Frågor & Svar";
const TRANSFER_TOOL_UI_ORIGIN = "https://insurello-ai.github.io/transfer-tool-crm-qa/";
const SKADEANMALAN_URL = new URL("./?tab=skadeanmalan", TRANSFER_TOOL_UI_ORIGIN).toString();
const SKADEANMALAN_ORIGIN = new URL(SKADEANMALAN_URL).origin;
const ENDGAME_INTYG_URL = new URL("./?tab=endgame-intyg&beta=1", TRANSFER_TOOL_UI_ORIGIN).toString();
// thBeta=1 turns on the Trygg-Hansa CRM prefill and Hälsofullmakt, which are
// behind a temporary web gate while older extension builds share Pages.
const EGENINTYG_URL = new URL("./?tab=convert&preselect=none&thBeta=1", TRANSFER_TOOL_UI_ORIGIN).toString();
const TRANSFER_TOOL_ORIGIN = new URL(ENDGAME_INTYG_URL).origin;
const HANDOFF_EVENT = "__transfer_tool_handoff_v2";
const HANDOFF_ACK_EVENT = "__transfer_tool_handoff_ack_v2";
const HANDOFF_QUERY_PARAM = "tt_transfer";
const HANDOFF_TTL_MS = 30_000;
const FOLKSAM_PORTAL_URL =
  globalThis.__crmFolksamPortal?.FOLKSAM_OMBUD_URL ||
  "https://folksam.sweetsystems.se/web/Survey/CreateAnswerSet/b7772749-b37d-4820-9ad4-559380ba3857?close=1";
const MAX_RUNTIME_MESSAGE_BYTES = 8 * 1024 * 1024;
const PROTECTOR_PORTAL_URL =
  globalThis.__crmProtectorConfig?.PORTAL_URL || "https://claims-at-net.protectorforsakring.se/swe/sv";
const PROTECTOR_RUN_STORAGE_PREFIX = globalThis.__crmProtectorConfig?.RUN_STORAGE_PREFIX || "crmProtectorRunV1:";
const PROTECTOR_RUN_HISTORY_LIMIT = 200;
const WORKFLOW_MODE_API = globalThis.__crmWorkflowMode;
// Actions started from the extension's own popup.
const POPUP_MESSAGE_TYPES = new Set([
  "EXPORT_SKADA_AUTOFILL",
  "EXPORT_FOLKSAM_COMPLEMENT",
  "OPEN_TRANSFER_TOOL_ENDGAME_INTYG",
  "OPEN_TRANSFER_TOOL_EGENINTYG",
  "START_PROTECTOR",
  "GET_STATUS"
]);
// Messages from the Protector portal content script.
const PROTECTOR_PORTAL_MESSAGE_TYPES = new Set([
  "PROTECTOR_PORTAL_REQUEST_ACTION",
  "PROTECTOR_PORTAL_SET_PAUSED",
  "PROTECTOR_PORTAL_REPORT"
]);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function setBadge({ text, color, title }) {
  if (typeof title === "string") await chrome.action.setTitle({ title });
  if (color) await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text: text ?? "" });
}

async function flashBadgeOk() {
  await setBadge({ text: "OK", color: "#0f766e", title: "Klar" });
  await sleep(1500);
  await setBadge({ text: "", title: "Skadeanmälan Assist" });
}

async function flashBadgeError(message) {
  await setBadge({ text: "!", color: "#b91c1c", title: message || "Fel" });
  await sleep(2500);
  await setBadge({ text: "", title: "Skadeanmälan Assist" });
}

async function executeInTab(tabId, func, args = [], options = null) {
  const base = { target: { tabId }, func, args };
  try {
    const results = await chrome.scripting.executeScript({
      ...base,
      ...(options && typeof options === "object" ? options : {})
    });
    return results?.[0]?.result;
  } catch (error) {
    if (options && typeof options === "object") {
      const results = await chrome.scripting.executeScript(base);
      return results?.[0]?.result;
    }
    throw error;
  }
}

async function executeFilesInTab(tabId, files, options = null) {
  const base = { target: { tabId }, files };
  try {
    await chrome.scripting.executeScript({
      ...base,
      ...(options && typeof options === "object" ? options : {})
    });
  } catch (error) {
    if (options && typeof options === "object") {
      await chrome.scripting.executeScript(base);
      return;
    }
    throw error;
  }
}

async function ensureTextCleaningInTab(tabId) {
  try {
    await executeFilesInTab(tabId, ["textCleaning.js"]);
  } catch {
    // The extractors have bounded in-function fallbacks.
  }
}

async function ensureCanonicalFritidInTab(tabId) {
  try {
    await executeFilesInTab(tabId, ["canonicalFritid.js"]);
  } catch {
    // The request returns a clear error if the extractor cannot be loaded.
  }
}

async function ensureFolksamPortalInTab(tabId) {
  await executeFilesInTab(tabId, ["folksamPortal.js"], { world: "MAIN" });
}

async function showToastInTab(tabId, message, { isError = false, level = null } = {}) {
  const safeMessage = String(message || "");
  if (!safeMessage) return;
  const toastLevel = level || (isError ? "error" : "success");
  try {
    await executeInTab(
      tabId,
      (text, toastStyle) => {
        const existing = document.getElementById("__crm_assist_toast");
        if (existing) existing.remove();
        const el = document.createElement("div");
        el.id = "__crm_assist_toast";
        el.textContent = text;
        el.style.position = "fixed";
        el.style.right = "16px";
        el.style.top = "16px";
        el.style.zIndex = "2147483647";
        el.style.maxWidth = "520px";
        el.style.whiteSpace = "pre-wrap";
        el.style.padding = "10px 12px";
        el.style.borderRadius = "10px";
        el.style.font = "13px/1.35 system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";
        el.style.boxShadow = "0 8px 30px rgba(0,0,0,0.22)";
        el.style.color = "#fff";
        el.style.background =
          toastStyle === "error"
            ? "rgba(185, 28, 28, 0.95)"
            : toastStyle === "warn"
              ? "rgba(217, 119, 6, 0.95)"
              : "rgba(15, 118, 110, 0.95)";
        document.documentElement.appendChild(el);
        window.setTimeout(() => el.remove(), 3500);
      },
      [safeMessage, toastLevel]
    );
  } catch {
    // Best-effort feedback only.
  }
}

function isAllowedCrmUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.origin === "https://crm.insurello.se" && parsed.pathname.startsWith("/admin/case/");
  } catch {
    return false;
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function createTransferId() {
  if (typeof crypto?.randomUUID === "function") return crypto.randomUUID();
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
}

function crmCaseIdentityFromUrl(value) {
  try {
    const parsed = new URL(value);
    if (parsed.origin !== "https://crm.insurello.se") return null;
    const match = parsed.pathname.match(/^\/admin\/case\/([^/?#]+)/);
    return match?.[1] ? decodeURIComponent(match[1]).trim().slice(0, 128) : null;
  } catch {
    return null;
  }
}

function addTransferIdToUrl(baseUrl, transferId) {
  const url = new URL(baseUrl);
  url.searchParams.set(HANDOFF_QUERY_PARAM, transferId);
  url.searchParams.set("ts", String(Date.now()));
  return url.toString();
}

async function openSkadeanmalanTab(transferId) {
  return await chrome.tabs.create({ url: addTransferIdToUrl(SKADEANMALAN_URL, transferId), active: true });
}

async function openEndgameIntygTab(transferId) {
  return await chrome.tabs.create({ url: addTransferIdToUrl(ENDGAME_INTYG_URL, transferId), active: true });
}

async function openEgenintygTab(transferId) {
  return await chrome.tabs.create({ url: addTransferIdToUrl(EGENINTYG_URL, transferId), active: true });
}

async function openFolksamPortalTab() {
  return await chrome.tabs.create({ url: FOLKSAM_PORTAL_URL, active: true });
}

function waitForTabComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      cleanup();
      reject(new Error("Tidsgränsen överskreds när målfliken skulle laddas."));
    }, timeoutMs);
    const cleanup = () => {
      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(onUpdated);
    };
    const onUpdated = (updatedTabId, info) => {
      if (updatedTabId !== tabId || info.status !== "complete") return;
      cleanup();
      resolve(true);
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then(tab => {
      if (tab?.status === "complete") {
        cleanup();
        resolve(true);
      }
    }).catch(() => {});
  });
}

async function sendOneTimeHandoff(tabId, { payload, workflow, transferId, caseIdentity, targetOrigin, targetPath }) {
  const result = await executeInTab(
    tabId,
    async (data, expectedWorkflow, expectedTransferId, expectedCaseIdentity, expectedOrigin, expectedPath, ttlMs, handoffEvent, ackEvent, queryParam) => {
      const current = new URL(window.location.href);
      if (
        current.origin !== expectedOrigin ||
        current.pathname !== expectedPath ||
        current.searchParams.get(queryParam) !== expectedTransferId
      ) {
        return { ok: false, code: "HANDOFF_DESTINATION_MISMATCH" };
      }

      const expiresAt = Date.now() + ttlMs;
      const envelope = {
        schema: "transfer_tool_handoff_v2",
        workflow: expectedWorkflow,
        transferId: expectedTransferId,
        caseIdentity: expectedCaseIdentity,
        expiresAt,
        payload: data
      };

      return await new Promise(resolve => {
        let settled = false;
        const finish = value => {
          if (settled) return;
          settled = true;
          window.removeEventListener(ackEvent, onAck);
          resolve(value);
        };
        const onAck = event => {
          const detail = event?.detail;
          if (
            detail?.schema !== "transfer_tool_handoff_ack_v2" ||
            detail?.workflow !== expectedWorkflow ||
            detail?.transferId !== expectedTransferId ||
            detail?.caseIdentity !== expectedCaseIdentity
          ) return;
          if (data?.caseInputs && detail.caseInputSchema !== data.caseInputs.schema) {
            finish({ ok: false, code: "HANDOFF_CASE_INPUT_UNSUPPORTED" }); return;
          }
          finish({ ok: true });
        };
        window.addEventListener(ackEvent, onAck);
        try {
          window.dispatchEvent(new CustomEvent(handoffEvent, { detail: envelope }));
        } catch (error) {
          finish({ ok: false, code: "HANDOFF_DISPATCH_FAILED", message: error instanceof Error ? error.message : String(error) });
          return;
        }
        window.setTimeout(() => finish({ ok: false, code: "HANDOFF_ACK_TIMEOUT" }), 350);
      });
    },
    [
      payload,
      workflow,
      transferId,
      caseIdentity,
      targetOrigin,
      targetPath,
      HANDOFF_TTL_MS,
      HANDOFF_EVENT,
      HANDOFF_ACK_EVENT,
      HANDOFF_QUERY_PARAM
    ],
    { world: "MAIN" }
  );
  if (!result?.ok) {
    const error = new Error(result?.code || "Handoff was not acknowledged");
    error.code = result?.code;
    throw error;
  }
  return result;
}

async function sendPayloadToSkadeanmalan(tabId, payload, transferId, caseIdentity) {
  const target = new URL(SKADEANMALAN_URL);
  return await sendOneTimeHandoff(tabId, {
    payload,
    workflow: "skadeanmalan",
    transferId,
    caseIdentity,
    targetOrigin: target.origin,
    targetPath: target.pathname
  });
}

async function sendPayloadToEgenintyg(tabId, payload, transferId, caseIdentity) {
  const target = new URL(EGENINTYG_URL);
  return await sendOneTimeHandoff(tabId, {
    payload,
    workflow: "trygghansa-egenintyg",
    transferId,
    caseIdentity,
    targetOrigin: target.origin,
    targetPath: target.pathname
  });
}

async function sendPayloadToTransferTool(tabId, payload, transferId, caseIdentity) {
  const target = new URL(ENDGAME_INTYG_URL);
  return await sendOneTimeHandoff(tabId, {
    payload,
    workflow: "endgame-intyg",
    transferId,
    caseIdentity,
    targetOrigin: target.origin,
    targetPath: target.pathname
  });
}

async function extractCanonicalFritidFromActiveTab(tabId, options = {}) {
  return await executeInTab(
    tabId,
    async extractOptions => {
      const api = globalThis.__crmFritidCanonical;
      if (!extractOptions.structuredCaseInputs && (!api || typeof api.extractCanonicalFritid !== "function")) {
        return { ok: false, message: "Canonical extractor not available" };
      }
      try {
        if (!extractOptions.structuredCare) return { ok: true, payload: await api.extractCanonicalFritid(extractOptions) };
        const href = extractOptions.boundHref;
        let changed = location.href !== href;
        const watcher = setInterval(() => { if (location.href !== href) changed = true; }, 20);
        try {
          const reader = globalThis.__crmCaseProbe;
          if (!reader) return { ok: false, message: "Den strukturerade vårdläsaren kunde inte laddas." };
          const result = await reader.run({ href, getHref: () => changed ? '' : location.href,
            fetchFn: fetch.bind(globalThis), canonicalCare: !extractOptions.structuredCaseInputs,
            ...(extractOptions.structuredCaseInputs ? { captureAll: true, collectCaseSources: true, scopedCaseInputs: true } : {}) });
          if (!result.ok) return { ok: false, message: `Vårduppgifterna kunde inte läsas: ${result.report.code}.` };
          if (extractOptions.structuredCaseInputs && !result.bundle?.coverage?.complete) {
            return { ok: false, message: "CRM-underlaget är ofullständigt. Försök igen." };
          }
          const payload = extractOptions.structuredCaseInputs
            ? { canonical: { meta: { caseId: reader.identity(href).caseId, caseNumber: reader.identity(href).caseId, url: href } }, warnings: {} }
            : await api.extractCanonicalFritid({ ...extractOptions, skipCareExtraction: true });
          if (changed || location.href !== href) return { ok: false, message: "CRM-ärendet ändrades under läsningen. Försök igen." };
          const renderedCaseId = payload.canonical?.meta?.caseId;
          if (renderedCaseId != null && String(renderedCaseId) !== reader.identity(href).caseId) {
            return { ok: false, message: "CRM-vyn visar fortfarande ett annat ärende. Vänta tills ärendet har laddats och försök igen." };
          }
          if (extractOptions.structuredCaseInputs) {
            // Interpret case values in the receiving web version. Packaged care
            // decoders must not block a future web-only mapping correction.
            payload.caseInputs = result.bundle;
          } else {
            payload.canonical.care = result.canonical.care;
            const { hasDoctorVisit, ...firstVisit } = result.canonical.incident;
            Object.assign(payload.canonical.incident, firstVisit);
            // Absence of providers does not replace an explicit no-visit answer.
            if (hasDoctorVisit != null) payload.canonical.incident.hasDoctorVisit = hasDoctorVisit;
          }
          return { ok: true, payload };
        } finally { clearInterval(watcher); }
      } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : String(error) };
      }
    },
    [options]
  );
}

async function extractHandelseCardFromActiveTab(tabId) {
  return await executeInTab(
    tabId,
    stopHeadingText => {
      const UI_TEXT_BLACKLIST = new Set(["Kopiera till urklipp", "Redigera"]);
      const COMPLEMENT_KEY = "Kompletteringar";
      const normalizeInline = text => String(text ?? "").replace(/\s+/g, " ").trim();
      const normalizePreserveNl = text =>
        String(text ?? "")
          .replace(/\r\n/g, "\n")
          .replace(/\r/g, "\n")
          .split("\n")
          .map(line => line.replace(/[ \t]+/g, " ").trim())
          .filter(line => line.length > 0)
          .join("\n")
          .trim();
      const cleanText =
        globalThis.__crmTextCleaning?.cleanCollectorText ||
        ((rawText, { stopMarkers = [], stripUi = true } = {}) => {
          let text = String(rawText ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
          for (const marker of Array.isArray(stopMarkers) ? stopMarkers : []) {
            const markerText = String(marker ?? "").trim().toLowerCase();
            const lines = text.split("\n");
            const idx = lines.findIndex(line => {
              const trimmed = String(line ?? "").trim();
              if (!trimmed) return false;
              if (markerText === "* * *") return /^\*\s*\*\s*\*$/.test(trimmed);
              const lower = trimmed.toLowerCase();
              return lower === markerText || lower.startsWith(markerText + " ");
            });
            if (idx !== -1) text = lines.slice(0, idx).join("\n");
          }
          const hadToggleGlyph = /[▼▾]/.test(text);
          if (stripUi) {
            text = text.replace(/[▼▾]\s*Visa alla\b[^\n]*/gi, "");
            text = text.replace(/[▼▾]/g, "");
          }
          const lines = String(text ?? "")
            .replace(/\u00a0/g, " ")
            .split("\n")
            .map(line => line.replace(/[ \t]+/g, " ").trim())
            .filter(line => line.length > 0);
          if (!stripUi) return lines.join("\n").trim();
          const DEFAULT_UI_LINES = new Set([
            "Kopiera till urklipp",
            "Redigera",
            "Begär läkarintyg",
            "Begär journaler",
            "Välj sjukskrivning",
            "Välj filer att posta",
            "eller släpp dem här",
            "Rensa"
          ]);
          const hasRequestActions = lines.includes("Begär journaler") || lines.includes("Begär läkarintyg");
          return lines
            .filter(line => !DEFAULT_UI_LINES.has(line))
            .filter(line => !(line === "Försättsblad" && hasRequestActions))
            .filter(line => !(hadToggleGlyph && /^Visa alla\b/i.test(line)))
            .join("\n")
            .trim();
        });
      const card = document.querySelector("#incident-case-card");
      if (!card) return { ok: false, code: "CARD_NOT_FOUND", message: "Händelse-kort saknas" };
      const headings = Array.from(card.querySelectorAll("h1,h2,h3,h4,h5,h6"));
      const stopHeading = headings.find(h => normalizeInline(h.textContent) === stopHeadingText);
      const isAfterStopHeading = node => {
        if (!stopHeading) return false;
        return Boolean(stopHeading.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING);
      };
      const fields = {};
      const rowContainers = new Set();
      const labelColumns = Array.from(card.querySelectorAll(".width-fill-4"));
      const findRowContainerForLabel = labelCol => {
        let ancestor = labelCol;
        for (let depth = 0; depth < 10; depth++) {
          ancestor = ancestor?.parentElement;
          if (!ancestor || ancestor === card || isAfterStopHeading(ancestor)) return null;
          const labelCount = ancestor.querySelectorAll(".width-fill-4").length;
          const valueCount = ancestor.querySelectorAll(".width-fill-8").length;
          if (labelCount === 1 && valueCount === 1) return ancestor;
        }
        return null;
      };
      for (const labelCol of labelColumns) {
        if (isAfterStopHeading(labelCol)) continue;
        const row = findRowContainerForLabel(labelCol);
        if (row) rowContainers.add(row);
      }
      const orderedRows = Array.from(rowContainers).sort((a, b) => {
        const rel = a.compareDocumentPosition(b);
        if (rel & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
        if (rel & Node.DOCUMENT_POSITION_PRECEDING) return 1;
        return 0;
      });
      for (const row of orderedRows) {
        if (isAfterStopHeading(row)) continue;
        const labelEls = row.querySelectorAll(".width-fill-4");
        const valueEls = row.querySelectorAll(".width-fill-8");
        const labelEl = labelEls.length === 1 ? labelEls[0] : null;
        const valueEl = valueEls.length === 1 ? valueEls[0] : null;
        if (!labelEl || !valueEl) continue;
        const label = normalizeInline(labelEl.textContent);
        if (!label || UI_TEXT_BLACKLIST.has(label)) continue;
        const preWrap = valueEl.querySelector('span[style*="white-space: pre-wrap"]');
        const shortTextNode = valueEl.querySelector(".s.t.wc.hc");
        const rawValue = preWrap ? preWrap.textContent : shortTextNode?.textContent || valueEl.textContent;
        const value = cleanText(rawValue, { stopMarkers: ["* * *"], stripUi: true });
        if (!value || UI_TEXT_BLACKLIST.has(value)) continue;
        fields[label] = value;
      }
      const lists = {};
      const complementHeading = headings.find(h => normalizeInline(h.textContent) === "Kompletteringar");
      if (complementHeading && !isAfterStopHeading(complementHeading)) {
        const sectionRoot = complementHeading.closest("section") || complementHeading.parentElement || complementHeading;
        const raw = cleanText(sectionRoot.innerText || sectionRoot.textContent, { stripUi: true });
        const dateRegex = /\b\d{4}-\d{2}-\d{2}\s+(?:kl\.\s*)?\d{2}:\d{2}\b/g;
        const items = [];
        const parts = raw.split(dateRegex);
        const dates = raw.match(dateRegex) || [];
        if (dates.length > 0 && parts.length === dates.length + 1) {
          for (let i = 0; i < dates.length; i++) {
            const text = normalizePreserveNl(parts[i + 1]);
            if (text) items.push({ date: dates[i], text });
          }
        }
        if (items.length > 0) lists["Kompletteringar"] = items;
        else if (raw) lists["KompletteringarRawText"] = raw;
      }
      if (
        typeof fields[COMPLEMENT_KEY] === "string" &&
        fields[COMPLEMENT_KEY].trim().length > 0 &&
        !lists["Kompletteringar"] &&
        !lists["KompletteringarRawText"]
      ) {
        lists["KompletteringarRawText"] = fields[COMPLEMENT_KEY];
        delete fields[COMPLEMENT_KEY];
      }
      return { ok: true, payload: { card: "Händelse", fields, lists } };
    },
    [STOP_HEADING_TEXT]
  );
}

async function fillFolksamPortal(tabId, minimalPlan) {
  return await executeInTab(
    tabId,
    async plan => {
      const api = globalThis.__crmFolksamPortal;
      if (!api || typeof api.fillComplementPlan !== "function") {
        return { ok: false, message: "Folksam portal helper not available" };
      }
      return await api.fillComplementPlan(plan);
    },
    [minimalPlan],
    { world: "MAIN" }
  );
}

async function getCanonicalCaseContext(tab, options = {}) {
  if (!tab?.id) return { ok: false, message: "Ingen aktiv flik." };
  if (!isAllowedCrmUrl(tab.url || "")) {
    return { ok: false, message: "Öppna ett CRM-ärende på crm.insurello.se först.", tab };
  }
  if (!options.structuredCaseInputs) {
    await ensureTextCleaningInTab(tab.id);
    await ensureCanonicalFritidInTab(tab.id);
  }
  let result;
  try {
    if (options.structuredCare) await executeFilesInTab(tab.id, ["crmCaseProbe.js"]);
    result = await extractCanonicalFritidFromActiveTab(tab.id, { ...options, boundHref: tab.url });
  } catch (error) {
    result = {
      ok: false,
      message: error instanceof Error ? error.message : "Canonical-extraktion misslyckades."
    };
  }
  if (!result?.ok || !result?.payload?.canonical) {
    return { ok: false, message: result?.message || "Canonical-extraktion misslyckades.", tab };
  }
  return {
    ok: true,
    tab,
    canonical: result.payload.canonical,
    warnings: result.payload.warnings || {},
    caseInputs: result.payload.caseInputs || null
  };
}

async function sendWithRetry(sendFn) {
  let lastError = null;
  for (let attempt = 0; attempt < 8; attempt++) {
    try {
      await sendFn();
      return;
    } catch (error) {
      if (error?.code === "HANDOFF_CASE_INPUT_UNSUPPORTED") throw error;
      lastError = error;
      await sleep(350);
    }
  }
  throw lastError || new Error("Kunde inte skicka data till målfliken.");
}

async function handleExportSkadaAutofill() {
  const tab = await getActiveTab();
  if (!tab?.id) return { ok: false, message: "Ingen aktiv flik." };
  if (!isAllowedCrmUrl(tab.url || "")) {
    return { ok: false, message: "Öppna ett CRM-ärende på crm.insurello.se först." };
  }

  const started = performance.now();
  let payload;
  const context = await getCanonicalCaseContext(tab, { structuredCare: true, structuredCaseInputs: true });
  const contextMs = Math.round(performance.now() - started);
  if (context.ok) {
    const launchApi = globalThis.__crmTransferToolLaunch;
    if (!launchApi || typeof launchApi.buildSkadeanmalanHandoffPayload !== "function") {
      return { ok: false, message: "Skadeanmälan-handoffern är inte tillgänglig." };
    }
    const payloadStarted = performance.now();
    payload = launchApi.buildSkadeanmalanHandoffPayload({ canonical: context.canonical, caseInputs: context.caseInputs });
    payload.caseInputs.transportDiagnostics ||= {schema:'crm_transport_diagnostics_v1',sources:{}};
    const trace = payload.caseInputs.transportDiagnostics;
    trace.pluginVersion = chrome.runtime.getManifest().version;
    trace.buildRevision = globalThis.__TRANSFER_TOOL_BUILD_REVISION;
    trace.stages = {contextMs, payloadMs:Math.round(performance.now()-payloadStarted)};
  } else {
    // Structured care failures must not silently revive DOM-derived care.
    await showToastInTab(tab.id, context.message, { isError: true });
    return { ok: false, message: context.message };
  }

  const caseIdentity = crmCaseIdentityFromUrl(tab.url || "");
  if (!caseIdentity) return { ok: false, message: "Kunde inte binda överföringen till aktuellt CRM-ärende." };
  const transferId = createTransferId();
  const openStarted = performance.now();
  const skadeTab = await openSkadeanmalanTab(transferId);
  if (!skadeTab?.id) return { ok: false, message: "Kunde inte öppna Skadeanmälan." };
  const trace = payload.caseInputs.transportDiagnostics;
  trace.stages.openMs = Math.round(performance.now()-openStarted);
  const readyStarted = performance.now();
  try {
    await waitForTabComplete(skadeTab.id);
  } catch {
    // The bounded handoff retry below waits for the app listener.
  }
  try {
    trace.stages.targetReadyMs = Math.round(performance.now()-readyStarted);
    const dispatchStarted = performance.now();
    let attempts = 0;
    await sendWithRetry(() => {
      trace.stages.dispatchWaitMs = Math.round(performance.now()-dispatchStarted);
      trace.stages.handoffAttempts = ++attempts;
      return sendPayloadToSkadeanmalan(skadeTab.id, payload, transferId, caseIdentity);
    });
  } catch (error) {
    return { ok: false, message: error?.code === "HANDOFF_CASE_INPUT_UNSUPPORTED"
      ? "Hemsidan stöder ännu inte detta CRM-underlag. Ladda om hemsidan när den matchande webbversionen har publicerats."
      : error instanceof Error ? error.message : "Kunde inte skicka data till Skadeanmälan." };
  }
  return {
    ok: true,
    message: "Öppnade Skadeanmälan med CRM-data."
  };
}

async function handleExportFolksamComplement() {
  const tab = await getActiveTab();
  // Folksam needs no care-provider details; skip expanding them in the CRM.
  const context = await getCanonicalCaseContext(tab, { expandCareProviderDetails: false });
  if (!context.ok) return { ok: false, message: context.message };

  const portalApi = globalThis.__crmFolksamPortal;
  if (!portalApi || typeof portalApi.buildFolksamComplementPlan !== "function") {
    return { ok: false, message: "Folksam portal helper är inte tillgänglig." };
  }
  const plan = portalApi.buildFolksamComplementPlan(context.canonical);
  const portalTab = await openFolksamPortalTab();
  if (!portalTab?.id) return { ok: false, message: "Kunde inte öppna Folksam Portal." };

  try {
    await waitForTabComplete(portalTab.id, 20000);
  } catch {
    // Best-effort; injection below will report a concrete failure if the page is not ready.
  }

  try {
    await ensureFolksamPortalInTab(portalTab.id);
    const minimalPlan = portalApi.sanitizeFolksamComplementPlan(plan);
    const fillResult = await fillFolksamPortal(portalTab.id, minimalPlan);
    if (!fillResult?.ok) {
      const message = fillResult?.message || "Kunde inte fylla Folksam Portal.";
      await showToastInTab(portalTab.id, message, { isError: true });
      return { ok: false, message };
    }

    const missingFields = Array.isArray(fillResult?.missingFields)
      ? fillResult.missingFields
      : Array.isArray(plan?.missingRequired) ? plan.missingRequired : [];
    const warnings = Array.isArray(fillResult?.warnings)
      ? fillResult.warnings
      : Array.isArray(plan?.warnings) ? plan.warnings : [];
    const needsReview = missingFields.length > 0 || warnings.length > 0;
    const message = needsReview
      ? `Folksam öppnades och säkra fält fylldes. Kontrollera manuellt: ${[...warnings, ...missingFields].join(" ")}`
      : "Folksam öppnades och kompletteringsfälten fylldes. Kontrollera innan du skickar.";
    await showToastInTab(portalTab.id, message, { level: needsReview ? "warn" : "success" });
    return {
      ok: true,
      message,
      status: {
        filledFields: Array.isArray(fillResult?.filledFields) ? fillResult.filledFields : [],
        missingFields,
        warnings
      }
    };
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Kunde inte fylla Folksam Portal." };
  }
}

async function handleOpenEndgameIntyg() {
  const tab = await getActiveTab();
  const context = await getCanonicalCaseContext(tab);
  if (!context.ok) return { ok: false, message: context.message };
  const launchApi = globalThis.__crmTransferToolLaunch;
  if (!launchApi || typeof launchApi.buildEndgameIntygLaunchPayload !== "function") {
    return { ok: false, message: "Endgame Intyg-launchern är inte tillgänglig." };
  }

  let payload;
  try {
    payload = launchApi.buildEndgameIntygLaunchPayload({
      canonical: context.canonical,
      warnings: context.warnings
    });
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Kunde inte skapa Endgame-payload." };
  }
  const launchWarnings = Array.isArray(payload?.warnings?.launchWarnings)
    ? payload.warnings.launchWarnings
    : [];
  await showToastInTab(
    context.tab.id,
    launchWarnings.length > 0
      ? "Öppnar Endgame Intyg. Kontrollera: " + launchWarnings.join(" ")
      : "Öppnar Endgame Intyg med CRM-data.",
    { level: launchWarnings.length > 0 ? "warn" : "success" }
  );
  const caseIdentity = crmCaseIdentityFromUrl(context.tab.url || "");
  if (!caseIdentity) return { ok: false, message: "Kunde inte binda överföringen till aktuellt CRM-ärende." };
  const transferId = createTransferId();
  const targetTab = await openEndgameIntygTab(transferId);
  if (!targetTab?.id) return { ok: false, message: "Kunde inte öppna Endgame Intyg." };
  try {
    await waitForTabComplete(targetTab.id);
  } catch {
    // The bounded handoff retry below waits for the app listener.
  }
  try {
    await sendWithRetry(() => sendPayloadToTransferTool(targetTab.id, payload, transferId, caseIdentity));
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Kunde inte skicka data till Endgame Intyg." };
  }
  return {
    ok: true,
    message: "Öppnade Endgame Intyg och skickade CRM-data.",
    status: { caseNumber: payload?.launch?.caseNumber || null, warningCount: launchWarnings.length }
  };
}

function getProtectorRunStorageKey(tabId) {
  return `${PROTECTOR_RUN_STORAGE_PREFIX}${tabId}`;
}

function sanitizeProtectorReport(payload) {
  const strings = (values, limit = 40) => (Array.isArray(values) ? values.slice(0, limit).map((value) => String(value).slice(0, 240)) : []);
  const action = (value) => {
    if (!value || typeof value !== "object") return null;
    return {
      type: String(value.type || "").slice(0, 80),
      id: value.id ? String(value.id).slice(0, 160) : null,
      name: value.name ? String(value.name).slice(0, 160) : null,
      text: value.text ? String(value.text).slice(0, 240) : null,
      valueRedacted: value.valueRedacted === true,
      valueLength: Number.isFinite(value.valueLength) ? Number(value.valueLength) : null
    };
  };
  const report = {
    path: String(payload?.path || "").slice(0, 300),
    previousPath: payload?.previousPath ? String(payload.previousPath).slice(0, 300) : null,
    status: String(payload?.status || "UNKNOWN").slice(0, 80),
    reason: payload?.reason ? String(payload.reason).slice(0, 500) : null,
    pauseNote: payload?.pauseNote ? String(payload.pauseNote).slice(0, 500) : null,
    at: new Date().toISOString()
  };
  if (Array.isArray(payload?.validationErrors)) {
    report.validationErrors = strings(payload.validationErrors, 20);
  }
  if (payload?.interaction && typeof payload.interaction === "object") {
    report.interaction = {
      kind: String(payload.interaction.kind || "interaction").slice(0, 80),
      tag: String(payload.interaction.tag || "").slice(0, 40),
      id: String(payload.interaction.id || "").slice(0, 120),
      name: String(payload.interaction.name || "").slice(0, 120),
      type: String(payload.interaction.type || "").slice(0, 40),
      text: String(payload.interaction.text || "").slice(0, 240),
      checked: typeof payload.interaction.checked === "boolean" ? payload.interaction.checked : null,
      value: payload.interaction.value ? String(payload.interaction.value).slice(0, 160) : null,
      selectedText: strings(payload.interaction.selectedText, 20),
      valueRedacted: payload.interaction.valueRedacted === true,
      valueLength: Number.isFinite(payload.interaction.valueLength) ? Number(payload.interaction.valueLength) : null
    };
  }
  if (payload?.decision && typeof payload.decision === "object") {
    let evidence = null;
    try {
      const serializedEvidence = JSON.stringify(payload.decision.evidence || null);
      if (serializedEvidence.length <= 4000) evidence = JSON.parse(serializedEvidence);
    } catch {
      evidence = null;
    }
    report.decision = {
      diagnosisHint: String(payload.decision.diagnosisHint || "CAPTURE_INCONCLUSIVE").slice(0, 80),
      canonicalPathsChecked: strings(payload.decision.canonicalPathsChecked),
      evidence
    };
  }
  if (Array.isArray(payload?.plannedActions)) report.plannedActions = payload.plannedActions.slice(0, 30).map(action).filter(Boolean);
  if (payload?.contract && typeof payload.contract === "object") {
    report.contract = {
      matchedSelectors: strings(payload.contract.matchedSelectors),
      missingSelectors: strings(payload.contract.missingSelectors)
    };
  }
  if (payload?.executor && typeof payload.executor === "object") {
    report.executor = {
      phase: String(payload.executor.phase || "").slice(0, 40),
      actionIndex: Number.isInteger(payload.executor.actionIndex) ? payload.executor.actionIndex : null,
      action: action(payload.executor.action)
    };
  }
  if (payload?.failure && typeof payload.failure === "object") {
    report.failure = {
      type: String(payload.failure.type || "EXECUTION_ERROR").slice(0, 100),
      message: String(payload.failure.message || "").slice(0, 500)
    };
  }
  if (payload?.portal && typeof payload.portal === "object") {
    report.portal = {
      heading: String(payload.portal.heading || "").slice(0, 240),
      buttons: Array.isArray(payload.portal.buttons) ? payload.portal.buttons.slice(0, 80).map((button) => ({
        text: String(button?.text || "").slice(0, 160),
        ariaLabel: String(button?.ariaLabel || "").slice(0, 160),
        disabled: button?.disabled === true,
        pressed: button?.pressed === true
      })) : [],
      inputs: Array.isArray(payload.portal.inputs) ? payload.portal.inputs.slice(0, 80).map((input) => ({
        id: String(input?.id || "").slice(0, 120),
        name: String(input?.name || "").slice(0, 120),
        type: String(input?.type || "").slice(0, 40),
        disabled: input?.disabled === true,
        checked: typeof input?.checked === "boolean" ? input.checked : null,
        selectedText: strings(input?.selectedText, 20),
        value: input?.value ? String(input.value).slice(0, 160) : null,
        valueRedacted: input?.valueRedacted === true,
        valueLength: Number.isFinite(input?.valueLength) ? Number(input.valueLength) : null
      })) : [],
      textSnippet: payload.portal.textSnippet ? String(payload.portal.textSnippet).slice(0, 800) : null
    };
  }
  return report;
}

async function getProtectorRun(tabId) {
  if (!tabId) return null;
  const key = getProtectorRunStorageKey(tabId);
  const stored = await chrome.storage.session.get(key);
  return stored?.[key] || null;
}

async function setProtectorRun(tabId, run) {
  const key = getProtectorRunStorageKey(tabId);
  await chrome.storage.session.set({ [key]: run });
}

async function startProtectorRunFromCanonical({ canonical, sourceTabId = null, runKind = "crm" }) {
  const planApi = globalThis.__crmProtectorPlan;
  if (!planApi?.buildProtectorPlan) return { ok: false, message: "Protector-planeraren saknas." };
  const plan = planApi.buildProtectorPlan(canonical, globalThis.__crmProtectorConfig || {});
  const portalTab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (!portalTab?.id) return { ok: false, message: "Kunde inte öppna Protector." };

  const run = {
    runId: globalThis.crypto?.randomUUID?.() || `protector-${Date.now()}-${portalTab.id}`,
    runKind,
    replayAccessToken: runKind === "replay"
      ? (globalThis.crypto?.randomUUID?.() || `replay-access-${Date.now()}-${Math.random()}`)
      : null,
    status: "RUNNING",
    automationPaused: false,
    pauseSource: null,
    pauseReason: null,
    pauseNote: null,
    createdAt: new Date().toISOString(),
    sourceTabId,
    portalTabId: portalTab.id,
    caseNumber: plan.caseNumber || null,
    plan,
    lastReport: null,
    reportHistory: []
  };
  await setProtectorRun(portalTab.id, run);
  await chrome.tabs.update(portalTab.id, { url: PROTECTOR_PORTAL_URL });
  return { ok: true, run, plan };
}

async function handleStartProtector(requestPayload = null) {
  const workflowMode = WORKFLOW_MODE_API.normalizeWorkflowMode(requestPayload?.workflowMode);
  if (WORKFLOW_MODE_API.isEndgameMode(workflowMode)) {
    return { ok: false, message: "Protector är tillgängligt i Pregame." };
  }
  const tab = await getActiveTab();
  // Protector needs no care-provider details; skip expanding them in the CRM.
  const caseContext = await getCanonicalCaseContext(tab, { expandCareProviderDetails: false });
  if (!caseContext?.ok) return { ok: false, message: caseContext?.message || "Canonical-extraktion misslyckades." };
  const started = await startProtectorRunFromCanonical({
    canonical: caseContext.canonical,
    sourceTabId: caseContext.tab?.id || null,
    runKind: "crm"
  });
  if (!started.ok) return started;
  const { plan } = started;
  return {
    ok: true,
    message: plan.warnings?.length
      ? `Protector öppnades. ${plan.warnings.length} val kräver extra kontroll.`
      : "Protector öppnades. Lös CAPTCHA och gör manuella kontrollval när pluginet pausar.",
    status: { warningCount: plan.warnings?.length || 0 }
  };
}

async function handleProtectorPortalRequestAction(tabId, payload) {
  let run = await getProtectorRun(tabId);
  if (!run?.plan) return { ok: false, message: "Ingen aktiv Protector-körning för fliken." };
  if (run.status !== "RUNNING") {
    return {
      ok: true,
      terminal: true,
      runId: run.runId,
      status: run.status,
      terminalReport: run.terminalReport || run.lastReport || null,
      passiveQaEnabled: run.runKind === "replay",
      passiveQaLastPath: run.passiveQaLastPath || null
    };
  }
  // 0.2.62 persisted USER_REQUIRED as a run pause. From 0.2.63 onward manual
  // steps are transient waits that resume automatically on the next route.
  // Clear only that legacy auto-pause; explicit user pauses remain persistent.
  if (run.automationPaused === true && run.pauseSource === "USER_REQUIRED") {
    run = {
      ...run,
      automationPaused: false,
      pauseSource: null,
      pauseReason: null,
      pauseNote: null
    };
    await setProtectorRun(tabId, run);
  }
  if (run.automationPaused === true) {
    return {
      ok: true,
      paused: true,
      runId: run.runId,
      status: run.status,
      pauseSource: run.pauseSource || "USER",
      pauseReason: run.pauseReason || null,
      pauseNote: run.pauseNote || null,
      passiveQaEnabled: run.runKind === "replay",
      passiveQaLastPath: run.passiveQaLastPath || null
    };
  }
  const path = globalThis.__crmProtectorContracts?.normalizePath?.(payload?.path) || String(payload?.path || "");
  const step = globalThis.__crmProtectorPlan?.getStep?.(run.plan, path);
  if (!step) return { ok: false, message: "Protector-steget kunde inte bestämmas." };
  return { ok: true, runId: run.runId, step, passiveQaEnabled: run.runKind === "replay" };
}

async function handleProtectorPortalSetPaused(tabId, payload) {
  const run = await getProtectorRun(tabId);
  if (!run?.plan) return { ok: false, message: "Ingen aktiv Protector-körning för fliken." };
  if (run.status !== "RUNNING") {
    return { ok: false, message: "Protector-körningen är redan stoppad och kan inte återupptas." };
  }

  const paused = payload?.paused === true;
  const source = paused ? String(payload?.source || "USER").slice(0, 80) : null;
  const pauseReason = paused
    ? String(payload?.reason || (source === "USER" ? "PAUSED_BY_USER" : "PAUSED")).slice(0, 500)
    : null;
  const pauseNote = paused && payload?.note ? String(payload.note).slice(0, 500) : null;
  const updated = {
    ...run,
    automationPaused: paused,
    pauseSource: source,
    pauseReason,
    pauseNote
  };
  await setProtectorRun(tabId, updated);
  return {
    ok: true,
    runId: run.runId,
    automationPaused: paused,
    pauseSource: source,
    pauseReason,
    pauseNote
  };
}

async function handleProtectorPortalReport(tabId, payload) {
  const run = await getProtectorRun(tabId);
  if (!run) return { ok: false, message: "Ingen aktiv Protector-körning för fliken." };
  const status = String(payload?.status || "UNKNOWN");
  const terminalStatuses = new Set([
    "READY_FOR_REVIEW",
    "BANK_CONFIG_MISSING",
    "BANK_NAME_MISMATCH",
    "UNKNOWN_ROUTE",
    "UNSUPPORTED",
    "PORTAL_SCHEMA_MISMATCH",
    "EXECUTION_ERROR"
  ]);
  const report = sanitizeProtectorReport(payload);
  const reportHistory = [...(Array.isArray(run.reportHistory) ? run.reportHistory : []), report]
    .slice(-PROTECTOR_RUN_HISTORY_LIMIT);
  const nextRun = {
    ...run,
    status: terminalStatuses.has(status) ? status : run.status,
    automationPaused: run.automationPaused === true,
    pauseSource: run.pauseSource || null,
    pauseReason: run.pauseReason || null,
    pauseNote: run.pauseNote || null,
    terminalReport: terminalStatuses.has(status) ? report : (run.terminalReport || null),
    passiveQaLastPath: status === "PASSIVE_QA_PAGE" ? report.path : (run.passiveQaLastPath || null),
    lastReport: report,
    reportHistory
  };
  await setProtectorRun(tabId, nextRun);
  // The QA build records runtime reports in its corpus; the handler build does not.
  const observer = globalThis.__transferToolProtectorReportObserver;
  if (typeof observer === "function") {
    await Promise.resolve(observer(run.caseNumber, report, nextRun.status)).catch(() => {});
  }
  return { ok: true };
}

// Opens the Egenintyg tab. From a CRM case it also sends the case's Trygg-Hansa
// projection (used only if the handler chooses Trygg-Hansa); elsewhere it only
// navigates.
async function handleOpenEgenintyg() {
  const activeTab = await getActiveTab();
  if (!activeTab?.id || !isAllowedCrmUrl(activeTab.url || "")) {
    const tab = await chrome.tabs.create({ url: EGENINTYG_URL, active: true });
    if (!tab?.id) return { ok: false, message: "Kunde inte öppna Blankettportalen." };
    return { ok: true, message: "Öppnade Blankettportalen utan CRM-data (inget CRM-ärende är öppet)." };
  }

  // Care-provider details are expanded: Hälsofullmakt needs the addresses.
  const context = await getCanonicalCaseContext(activeTab);
  if (!context.ok) return { ok: false, message: context.message };
  const launchApi = globalThis.__crmTransferToolLaunch;
  if (!launchApi || typeof launchApi.buildTransferToolLaunchPayload !== "function") {
    return { ok: false, message: "Blankettportalen-launchern är inte tillgänglig." };
  }
  let payload;
  try {
    payload = launchApi.buildTransferToolLaunchPayload({ canonical: context.canonical });
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Kunde inte skapa CRM-data för Blankettportalen." };
  }
  const caseIdentity = crmCaseIdentityFromUrl(context.tab.url || "");
  if (!caseIdentity) return { ok: false, message: "Kunde inte binda överföringen till aktuellt CRM-ärende." };

  const launchWarnings = Array.isArray(payload?.warnings?.launchWarnings) ? payload.warnings.launchWarnings : [];
  await showToastInTab(
    context.tab.id,
    launchWarnings.length > 0
      ? "Öppnar Blankettportalen. Kontrollera: " + launchWarnings.join(" ")
      : "Öppnar Blankettportalen med CRM-data.",
    { level: launchWarnings.length > 0 ? "warn" : "success" }
  );
  const transferId = createTransferId();
  const targetTab = await openEgenintygTab(transferId);
  if (!targetTab?.id) return { ok: false, message: "Kunde inte öppna Blankettportalen." };
  try {
    await waitForTabComplete(targetTab.id);
  } catch {
    // The bounded handoff retry below waits for the app listener.
  }
  try {
    await sendWithRetry(() => sendPayloadToEgenintyg(targetTab.id, payload, transferId, caseIdentity));
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Kunde inte skicka data till Blankettportalen." };
  }
  return {
    ok: true,
    message: "Öppnade Blankettportalen och skickade CRM-data.",
    status: { caseNumber: payload?.launch?.caseNumber || null, warningCount: launchWarnings.length }
  };
}

async function handleGetStatus() {
  return {
    ok: true,
    status: {
      buildFlavor: BUILD_FLAVOR,
      version: chrome.runtime.getManifest().version,
      actions: ["skadeanmalan", "folksam", "endgame-intyg", "egenintyg", "protector"]
    }
  };
}

function isExtensionPageSender(sender) {
  if (!sender || sender.tab) return false;
  if (sender.id && sender.id !== chrome.runtime.id) return false;
  const extensionOrigin = chrome.runtime.getURL("");
  return typeof sender.url === "string" && sender.url.startsWith(extensionOrigin);
}

function isProtectorPortalSender(sender) {
  try {
    const expected = new URL(PROTECTOR_PORTAL_URL);
    const actual = new URL(sender?.tab?.url || "");
    return actual.protocol === "https:" && actual.host === expected.host;
  } catch {
    return false;
  }
}

async function dispatchHandlerMessage(message, sender) {
  switch (message.type) {
    case "EXPORT_SKADA_AUTOFILL":
      return await handleExportSkadaAutofill();
    case "EXPORT_FOLKSAM_COMPLEMENT":
      return await handleExportFolksamComplement();
    case "OPEN_TRANSFER_TOOL_ENDGAME_INTYG":
      return await handleOpenEndgameIntyg();
    case "OPEN_TRANSFER_TOOL_EGENINTYG":
      return await handleOpenEgenintyg();
    case "START_PROTECTOR":
      return await handleStartProtector(message.payload);
    case "PROTECTOR_PORTAL_REQUEST_ACTION":
      return await handleProtectorPortalRequestAction(sender.tab.id, message.payload);
    case "PROTECTOR_PORTAL_SET_PAUSED":
      return await handleProtectorPortalSetPaused(sender.tab.id, message.payload);
    case "PROTECTOR_PORTAL_REPORT":
      return await handleProtectorPortalReport(sender.tab.id, message.payload);
    default:
      return await handleGetStatus();
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "EXPORT_SKADA_AUTOFILL") return false;
  if (serializedByteLength(message) > MAX_RUNTIME_MESSAGE_BYTES) {
    sendResponse({ ok: false, message: "Meddelandet är för stort." });
    return;
  }
  const type = message?.type;
  const extra = globalThis.__transferToolExtraMessageHandlers || {};
  let run;
  if (POPUP_MESSAGE_TYPES.has(type)) {
    if (!isExtensionPageSender(sender)) {
      sendResponse({ ok: false, message: "Åtgärden får bara startas från tillägget." });
      return;
    }
    run = () => dispatchHandlerMessage(message, sender);
  } else if (PROTECTOR_PORTAL_MESSAGE_TYPES.has(type)) {
    if (!isProtectorPortalSender(sender)) {
      sendResponse({ ok: false, message: "Meddelandet får bara komma från Protector-portalen." });
      return;
    }
    run = () => dispatchHandlerMessage(message, sender);
  } else if (Object.prototype.hasOwnProperty.call(extra, type)) {
    const entry = extra[type];
    if (entry.passive) return;
    if (typeof entry.allowSender === "function" && !entry.allowSender(sender)) {
      sendResponse({ ok: false, message: entry.rejectMessage || "Meddelandet avvisades." });
      return;
    }
    run = () => entry.handle(message, sender);
  } else {
    sendResponse({ ok: false, message: "Okänd intern åtgärd." });
    return;
  }
  (async () => {
    try {
      sendResponse(await run());
    } catch (error) {
      sendResponse({
        ok: false,
        message: error instanceof Error ? error.message : "Oväntat fel."
      });
    }
  })();
  return true;
});

function serializedByteLength(value) {
  try {
    return new TextEncoder().encode(JSON.stringify(value)).byteLength;
  } catch {
    return Infinity;
  }
}

// Drop a Protector run's state when its portal tab closes.
chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.session.remove(getProtectorRunStorageKey(tabId)).catch(() => {});
});

// Keep a safe icon-click fallback for environments that do not show the popup.
chrome.action.onClicked.addListener(async tab => {
  try {
    const result = await handleExportSkadaAutofill();
    if (result?.ok) await flashBadgeOk();
    else {
      await flashBadgeError(result?.message || "Kunde inte köra Skadeanmälan.");
      if (tab?.id) await showToastInTab(tab.id, result?.message || "Kunde inte köra Skadeanmälan.", { isError: true });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "Oväntat fel.";
    await flashBadgeError(message);
    if (tab?.id) await showToastInTab(tab.id, message, { isError: true });
  }
});
