(function (root, factory) {
  const api = factory();
  root.__crmProtectorConfig = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    PORTAL_URL: "https://claims-at-net.protectorforsakring.se/swe/sv",
    RUN_STORAGE_PREFIX: "crmProtectorRunV1:",
    // Consent is a user decision and is never automated in the distributed build.
    PROTECTOR_BETA_AUTO_PRIVACY: false,
    INSURELLO_CONTACT: {
      phone: "031-308 88 75",
      email: "kundservice@insurello.se",
      address: "Insurello R 934",
      postalCode: "10656",
      city: "Stockholm"
    },
    INSURELLO_ACCOUNT_HOLDER: {
      givenName: "Insurello",
      familyName: "AB"
    },
    // Payout account data is intentionally absent from the distributed client.
    // The handler must enter and verify it manually in the portal.
    INSURELLO_BANK_ACCOUNT: {
      clearingNumber: "",
      accountNumber: "",
      expectedBankName: ""
    }
  };
});
