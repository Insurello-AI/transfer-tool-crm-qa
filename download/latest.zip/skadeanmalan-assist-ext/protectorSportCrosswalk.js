(function (root, factory) {
  const api = factory();
  root.__crmProtectorSportCrosswalk = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const STATUS = Object.freeze({
    AUTO: "AUTO",
    AMBIGUOUS: "AMBIGUOUS",
    UNKNOWN: "UNKNOWN"
  });

  const PROTECTOR_SPORTS = Object.freeze({
    ballSports: "Bollsport",
    dance: "Dans",
    diving: "Dykning",
    parachuteAirSports: "Fallskärms-/flygsport",
    athletics: "Friidrott",
    gymnastics: "Gymnastik",
    equestrian: "Hästsport",
    iceWinterSports: "Is-/alpinsport",
    martialArts: "Kampsport",
    climbing: "Klättring",
    motorSports: "Motorsport",
    sailing: "Segling",
    weightTraining: "Styrketräning",
    waterAquatics: "Vatten-/simsport",
    other: "Annat"
  });

  function fold(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .toLowerCase();
  }

  function auto(values, protectorValue, reason) {
    return values.map((source) => ({
      source,
      status: STATUS.AUTO,
      protectorValue,
      protectorLabel: PROTECTOR_SPORTS[protectorValue],
      reason
    }));
  }

  function ambiguous(values, reason) {
    return values.map((source) => ({
      source,
      status: STATUS.AMBIGUOUS,
      protectorValue: null,
      protectorLabel: null,
      reason
    }));
  }

  // Secondary reviewed catalogue already present in this repo via the licence-intyg
  // catalogue. It is useful evidence for exact sport semantics, but it is NOT the
  // authoritative Insurello Sport.fs/live CRM catalogue. Unknown CRM values remain
  // fail-closed until the full private-domain catalogue can be inspected read-only.
  const SECONDARY_SPORT_CROSSWALK = Object.freeze([
    ...auto([
      "Amerikansk fotboll",
      "Baseboll & Softboll",
      "Basket",
      "Bordtennis",
      "Cricket",
      "Fotboll",
      "Handboll",
      "Innebandy",
      "Lacrosse",
      "Landhockey",
      "Padel",
      "Rugby",
      "Squash",
      "Tennis",
      "Volleyboll"
    ], "ballSports", "Exact sport is a direct ball-sport semantic match."),

    ...auto(["Danssport"], "dance", "Exact sport is a direct dance semantic match."),
    ...auto(["Sportdykning"], "diving", "Exact sport is a direct diving semantic match."),
    ...auto([
      "Fallskärm",
      "Hängflyg",
      "Skärmflygning"
    ], "parachuteAirSports", "Exact sport is an air/parachute sport."),
    ...auto([
      "Friidrott",
      "Mångkamp"
    ], "athletics", "Exact sport belongs to athletics."),
    ...auto(["Gymnastik"], "gymnastics", "Exact sport is gymnastics."),
    ...auto([
      "Ridsport",
      "Ridsport + Hästfrågor",
      "Travsport"
    ], "equestrian", "Exact sport is horse/equestrian sport."),
    ...auto([
      "Curling",
      "Ishockey",
      "Kälksport",
      "Konståkning",
      "Ringette",
      "Skidåkning",
      "Skidskytte",
      "Skridskor"
    ], "iceWinterSports", "Exact sport is an ice/winter sport."),
    ...auto([
      "Boxning",
      "Brottning",
      "Budo & Kampsport",
      "Judo",
      "Karate",
      "Taekwondo"
    ], "martialArts", "Exact sport is a combat/martial art."),
    ...auto(["Klättring"], "climbing", "Exact sport is climbing."),
    ...auto([
      "Bilsport",
      "Racerbåt",
      "Tractorpulling"
    ], "motorSports", "Exact sport is motor-powered competition."),
    ...auto(["Segling"], "sailing", "Exact sport is sailing."),
    ...auto([
      "Bodybuilding & Fitness",
      "Styrkelyft",
      "Tyngdlyft"
    ], "weightTraining", "Exact sport is strength/weight training."),
    ...auto([
      "Kanot",
      "Rodd",
      "Simning",
      "Vattenskidor & Wakeboard"
    ], "waterAquatics", "Exact sport is a water/aquatic sport."),
    ...auto([
      "Bågskytte",
      "Brukshund",
      "Cykel",
      "Dart",
      "Draghundsport",
      "Dragkamp",
      "Frisbee",
      "Gång & Vandring",
      "Orientering",
      "Pistolskytte",
      "Skateboard",
      "Skyttesport",
      "Sportfiske & Fiskevård",
      "Varpa"
    ], "other", "Exact sport does not fit another Protector sport family and maps to Annat."),

    ...ambiguous([
      "Badminton",
      "Bandy",
      "Bangolf",
      "Biljard",
      "Boule",
      "Bowling",
      "Golf"
    ], "Could plausibly be interpreted as Bollsport or Annat; policy evidence is required."),
    ...ambiguous([
      "Cheerleading"
    ], "Could plausibly be Gymnastik or Annat; policy evidence is required."),
    ...ambiguous([
      "Fäktning"
    ], "Could plausibly be Kampsport or Annat; policy evidence is required."),
    ...ambiguous([
      "Issegling"
    ], "Could plausibly be Is-/alpinsport or Segling; policy evidence is required."),
    ...ambiguous([
      "Vindsurfning"
    ], "Could plausibly be Segling or Vatten-/simsport; policy evidence is required."),
    ...ambiguous([
      "Triathlon"
    ], "Multi-sport activity crosses Protector sport families."),
    ...ambiguous([
      "Dövidrott",
      "Friluftsfrämjandet",
      "Jägarförbundet",
      "Korpen Motionsidrott",
      "Parasport",
      "Riksidrott (RF)",
      "Skolidrott",
      "SWE3",
      "Svemo",
      "Sveriges Akademiska idrottsförbund (SAIF)",
      "Swesport"
    ], "Umbrella organisation/federation or multi-sport label does not identify one Protector sport family.")
  ]);

  // Exact values observed or semantically identical to Protector's own closed list.
  // These are intentionally separate from the secondary catalogue provenance.
  const RUNTIME_EXACT_ALIASES = Object.freeze([
    { source: "Gym", protectorValue: "weightTraining", reason: "Observed CRM value; Gym maps directly to strength training." },
    { source: "Barngymnastik", protectorValue: "gymnastics", reason: "Observed CRM value; Barngymnastik is directly gymnastics." },
    { source: "Brasiliansk jiu-jitsu", protectorValue: "martialArts", reason: "Observed CRM value; Brazilian jiu-jitsu is directly a combat/martial art." },
    { source: "Muaythai", protectorValue: "martialArts", reason: "Observed CRM value; Muaythai is directly a combat/martial art." },
    { source: "Muay Thai", protectorValue: "martialArts", reason: "Spelling variant of observed CRM Muaythai; directly a combat/martial art." },
    { source: "Styrketräning", protectorValue: "weightTraining", reason: "Exact Protector semantic label." },
    ...Object.entries(PROTECTOR_SPORTS).map(([protectorValue, source]) => ({
      source,
      protectorValue,
      reason: "Exact Protector semantic label."
    }))
  ]);

  const entries = [
    ...SECONDARY_SPORT_CROSSWALK,
    ...RUNTIME_EXACT_ALIASES.map((entry) => ({
      ...entry,
      status: STATUS.AUTO,
      protectorLabel: PROTECTOR_SPORTS[entry.protectorValue]
    }))
  ];

  const byFoldedSource = new Map();
  for (const entry of entries) {
    const key = fold(entry.source);
    const existing = byFoldedSource.get(key);
    if (existing && (
      existing.status !== entry.status ||
      existing.protectorValue !== entry.protectorValue
    )) {
      throw new Error(`PROTECTOR_SPORT_CROSSWALK_CONFLICT:${entry.source}`);
    }
    if (!existing) byFoldedSource.set(key, entry);
  }

  function resolveSportType(value) {
    const source = String(value || "").replace(/\s+/g, " ").trim();
    if (!source) {
      return {
        source: null,
        status: STATUS.UNKNOWN,
        protectorValue: null,
        protectorLabel: null,
        reason: "SPORT_TYPE_MISSING"
      };
    }
    const entry = byFoldedSource.get(fold(source));
    if (!entry) {
      return {
        source,
        status: STATUS.UNKNOWN,
        protectorValue: null,
        protectorLabel: null,
        reason: "SPORT_TYPE_NOT_IN_REVIEWED_CROSSWALK"
      };
    }
    return { ...entry, source };
  }

  function validateSecondaryCoverage(expectedValues) {
    const errors = [];
    const actual = SECONDARY_SPORT_CROSSWALK.map((entry) => entry.source);
    const duplicates = actual.filter((source, index) => actual.indexOf(source) !== index);
    if (duplicates.length) errors.push(`DUPLICATE_SECONDARY_SPORTS:${[...new Set(duplicates)].join(",")}`);
    if (Array.isArray(expectedValues)) {
      const expected = new Set(expectedValues);
      const actualSet = new Set(actual);
      const missing = [...expected].filter((value) => !actualSet.has(value));
      const unexpected = [...actualSet].filter((value) => !expected.has(value));
      if (missing.length) errors.push(`MISSING_SECONDARY_SPORTS:${missing.join(",")}`);
      if (unexpected.length) errors.push(`UNEXPECTED_SECONDARY_SPORTS:${unexpected.join(",")}`);
    }
    for (const entry of SECONDARY_SPORT_CROSSWALK) {
      if (![STATUS.AUTO, STATUS.AMBIGUOUS].includes(entry.status)) errors.push(`INVALID_STATUS:${entry.source}`);
      if (entry.status === STATUS.AUTO && !PROTECTOR_SPORTS[entry.protectorValue]) errors.push(`INVALID_TARGET:${entry.source}`);
      if (entry.status === STATUS.AMBIGUOUS && entry.protectorValue !== null) errors.push(`AMBIGUOUS_WITH_TARGET:${entry.source}`);
    }
    return {
      ok: errors.length === 0,
      errors,
      summary: SECONDARY_SPORT_CROSSWALK.reduce((summary, entry) => {
        summary[entry.status] += 1;
        return summary;
      }, { AUTO: 0, AMBIGUOUS: 0 })
    };
  }

  return {
    STATUS,
    PROTECTOR_SPORTS,
    SECONDARY_SPORT_CROSSWALK,
    RUNTIME_EXACT_ALIASES,
    resolveSportType,
    validateSecondaryCoverage
  };
});
