(function (root, factory) {
  const api = factory(root);

  root.__crmFolksamPortal = api;

  if (typeof module === "object" && module && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  const FOLKSAM_OMBUD_URL =
    "https://folksam.sweetsystems.se/web/Survey/CreateAnswerSet/b7772749-b37d-4820-9ad4-559380ba3857?close=1";

  const QUESTION_IDS = {
    claimantName: "e4b444ee-f07f-4806-9cd0-b1170df70cd2",
    claimantPersonNumber: "49d85e9b-ff5e-4c33-9286-a71c6a3bbdca",
    caseType: "e24cf437-3876-41cd-8c9a-31148e061ca2",
    incidentDate: "c3dd58c9-41de-476d-9ecc-59ed81521751",
    folksamClaimNumber: "9b639c44-3a8b-448b-b0b3-163af82e8b0d",
    completionType: "cbf4b15f-7499-49c9-9d4c-47c0038ade28"
  };

  const ANSWER_IDS = {
    caseTypeComplement: "bd433e47-bdb7-4f43-a827-92fb9ba6c271",
    completionAttachFiles: "0e9d7d43-a863-4592-bf1d-795abdd9e19a"
  };

  const REQUIRED_FIELD_LABELS = {
    claimantName: "claimant.name",
    claimantPersonNumber: "claimant.personNumber",
    incidentDate: "incident.date",
    folksamClaimNumber: "folksam.claimNumber"
  };

  function normalizeWhitespace(value) {
    return String(value ?? "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function escapeRegExp(value) {
    return String(value ?? "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function pickFirstString() {
    for (let i = 0; i < arguments.length; i += 1) {
      const candidate = normalizeWhitespace(arguments[i]);
      if (candidate) return candidate;
    }
    return null;
  }

  function normalizePersonNumber(value) {
    const digits = String(value ?? "").replace(/\D/g, "");
    return digits.length >= 12 ? digits.slice(0, 12) : digits || null;
  }

  function isValidFolksamClaimNumber(value) {
    const raw = normalizeWhitespace(value).toUpperCase();
    if (!raw) return false;
    return /^[A-Z]{2}\d{8}[A-Z]$/.test(raw) || /^[A-Z]{3}\d{12}$/.test(raw);
  }

  function normalizeFolksamClaimNumber(value) {
    const raw = normalizeWhitespace(value);
    if (!raw) return null;
    if (isValidFolksamClaimNumber(raw)) return raw;

    if (!/[-\s]/.test(raw)) return raw;

    const compact = raw.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    if (isValidFolksamClaimNumber(compact)) return compact;

    const compactWithShortIsoDate = raw
      .replace(/\b(\d{4})-(\d{2})-(\d{2})\b/g, function (_match, year, month, day) {
        return `${String(year).slice(-2)}${month}${day}`;
      })
      .replace(/[^A-Za-z0-9]/g, "")
      .toUpperCase();
    if (isValidFolksamClaimNumber(compactWithShortIsoDate)) return compactWithShortIsoDate;

    return raw;
  }

  function normalizeIsoDate(value) {
    const trimmed = normalizeWhitespace(value);
    if (!trimmed) return null;

    const isoMatch = trimmed.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;

    const slashYearFirstMatch = trimmed.match(/\b(\d{4})[/.](\d{2})[/.](\d{2})\b/);
    if (slashYearFirstMatch) {
      return `${slashYearFirstMatch[1]}-${slashYearFirstMatch[2]}-${slashYearFirstMatch[3]}`;
    }

    const compactMatch = trimmed.match(/\b(\d{4})(\d{2})(\d{2})\b/);
    if (compactMatch) return `${compactMatch[1]}-${compactMatch[2]}-${compactMatch[3]}`;

    const dayFirstMatch = trimmed.match(/\b(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})\b/);
    if (dayFirstMatch) {
      const day = dayFirstMatch[1].padStart(2, "0");
      const month = dayFirstMatch[2].padStart(2, "0");
      return `${dayFirstMatch[3]}-${month}-${day}`;
    }

    return null;
  }

  function extractCanonicalPayload(payload) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) return null;
    if (payload.canonical && typeof payload.canonical === "object") return payload.canonical;
    if (payload.claimant || payload.incident) return payload;
    return null;
  }

  function isFolksamText(value) {
    return normalizeWhitespace(value).toLowerCase().includes("folksam");
  }

  function resolveFolksamClaimNumber(canonical) {
    const insuranceCards = Array.isArray(canonical?.meta?.insuranceMatter?.cards)
      ? canonical.meta.insuranceMatter.cards
      : [];
    const folksamCardCandidates = insuranceCards.filter((card) => {
      const insurer = normalizeWhitespace(card?.insurer).toLowerCase();
      const displayName = normalizeWhitespace(card?.displayName).toLowerCase();
      const claimLink = normalizeWhitespace(card?.claimLink).toLowerCase();
      const inquiryLink = normalizeWhitespace(card?.inquiryLink).toLowerCase();
      const claimNumber = pickFirstString(card?.claimNumber);

      if (!claimNumber) return false;
      return (
        insurer.includes("folksam") ||
        displayName.includes("folksam") ||
        claimLink.includes("folksam") ||
        inquiryLink.includes("folksam")
      );
    });

    if (folksamCardCandidates.length === 1) {
      return {
        claimNumber: normalizeFolksamClaimNumber(pickFirstString(folksamCardCandidates[0]?.claimNumber)) || null,
        warning: null
      };
    }

    if (folksamCardCandidates.length > 1) {
      return {
        claimNumber: null,
        warning: "Flera Folksam skadenummer hittades. Välj rätt skadenummer manuellt i Folksam."
      };
    }

    const fallbackLooksFolksam =
      isFolksamText(canonical?.otherAccidentInsurance?.insurer) ||
      isFolksamText(canonical?.meta?.insuranceMatter?.displayName) ||
      (Array.isArray(canonical?.meta?.insuranceMatter?.displayNames) &&
        canonical.meta.insuranceMatter.displayNames.some((name) => isFolksamText(name)));

    return {
      claimNumber:
        fallbackLooksFolksam
          ? normalizeFolksamClaimNumber(
              pickFirstString(
              canonical?.otherAccidentInsurance?.claimNumber,
              canonical?.otherAccidentInsurance?.skadenummer
              )
            ) || null
          : null,
      warning: null
    };
  }

  function buildFolksamComplementPlan(canonical) {
    const claimantName = pickFirstString(canonical?.claimant?.name);
    const claimantPersonNumber = normalizePersonNumber(canonical?.claimant?.personNumber);
    const incidentDate = normalizeIsoDate(canonical?.incident?.date);
    const claimNumberResolution = resolveFolksamClaimNumber(canonical);
    const folksamClaimNumber = pickFirstString(claimNumberResolution?.claimNumber);

    const missingRequired = [];
    if (!claimantName) missingRequired.push(REQUIRED_FIELD_LABELS.claimantName);
    if (!claimantPersonNumber) missingRequired.push(REQUIRED_FIELD_LABELS.claimantPersonNumber);
    if (!incidentDate) missingRequired.push(REQUIRED_FIELD_LABELS.incidentDate);
    if (!folksamClaimNumber) missingRequired.push(REQUIRED_FIELD_LABELS.folksamClaimNumber);

    return {
      missingRequired,
      warnings: claimNumberResolution?.warning ? [claimNumberResolution.warning] : [],
      fields: [
        {
          questionId: QUESTION_IDS.claimantName,
          label: "För- och efternamn",
          value: claimantName,
          kind: "text"
        },
        {
          questionId: QUESTION_IDS.claimantPersonNumber,
          label: "Personnummer",
          value: claimantPersonNumber,
          kind: "text"
        },
        {
          questionId: QUESTION_IDS.caseType,
          label: "Vad gäller ärendet?",
          value: ANSWER_IDS.caseTypeComplement,
          kind: "answerId"
        },
        {
          questionId: QUESTION_IDS.incidentDate,
          label: "Ange skadedatum",
          value: incidentDate,
          kind: "date"
        },
        {
          questionId: QUESTION_IDS.folksamClaimNumber,
          label: "Ange Folksams skadenummer",
          value: folksamClaimNumber,
          kind: "text"
        },
        {
          questionId: QUESTION_IDS.completionType,
          label: "Vad vill ni komplettera?",
          value: ANSWER_IDS.completionAttachFiles,
          kind: "answerId"
        }
      ].filter((field) => field.value)
    };
  }

  function getSurveyContext() {
    const ko = root.ko;
    const surveyNode = root.document?.getElementById?.("SurveyDiv");
    if (!ko || typeof ko.dataFor !== "function" || !surveyNode) return null;

    const viewModel = ko.dataFor(surveyNode) || ko.contextFor?.(surveyNode)?.$root || null;
    const survey = viewModel?.Survey || null;
    if (!survey || typeof survey !== "object") return null;
    if (!survey.AllQuestions || typeof survey.AllQuestions !== "object") return null;
    return survey;
  }

  function sleep(ms) {
    return new Promise((resolve) => root.setTimeout(resolve, ms));
  }

  async function waitForSurveyContext(requiredQuestionIds, timeoutMs) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const survey = getSurveyContext();
      if (survey) {
        const hasAllQuestions = requiredQuestionIds.every((questionId) => !!survey.AllQuestions?.[questionId]);
        if (hasAllQuestions) return survey;
      }
      await sleep(100);
    }
    return null;
  }

  function setQuestionValue(question, field) {
    if (field.kind === "date") {
      setDateQuestionValue(question, field);
      return;
    }

    const target = question?.SelectedAnswer?.Answered;
    if (typeof target !== "function") {
      throw new Error(`Question ${field.questionId} is not writable`);
    }
    target(field.value);
  }

  function findInputNearLabel(label) {
    const normalizedLabel = normalizeWhitespace(label);
    if (!normalizedLabel || !root.document?.querySelectorAll) return null;

    const candidates = root.document.querySelectorAll("label, h1, h2, h3, h4, h5, h6, p, span, div, strong");
    for (const candidate of candidates) {
      if (normalizeWhitespace(candidate.textContent) !== normalizedLabel) continue;

      const localInput = candidate.querySelector?.("input, textarea");
      if (localInput) return localInput;

      const parentInput = candidate.parentElement?.querySelector?.("input, textarea");
      if (parentInput) return parentInput;

      let sibling = candidate.nextElementSibling;
      while (sibling) {
        const siblingInput = sibling.querySelector?.("input, textarea");
        if (siblingInput) return siblingInput;
        sibling = sibling.nextElementSibling;
      }

      let ancestor = candidate.parentElement;
      for (let depth = 0; ancestor && depth < 4; depth += 1) {
        const ancestorInput = ancestor.querySelector?.("input, textarea");
        if (ancestorInput) return ancestorInput;
        ancestor = ancestor.parentElement;
      }
    }

    return null;
  }

  function findQuestionInput(question, field) {
    const selectors = [
      `[data-question-id="${field.questionId}"] input`,
      `[data-questionid="${field.questionId}"] input`,
      `[questionid="${field.questionId}"] input`,
      `#${field.questionId} input`,
      `[id="${field.questionId}"] input`,
      `[id*="${field.questionId}"] input`,
      `[name="${field.questionId}"]`,
      `[aria-label="${field.label}"]`,
      `input[placeholder="${field.label}"]`
    ];

    for (const selector of selectors) {
      try {
        const input = root.document?.querySelector?.(selector);
        if (input) return input;
      } catch {
        // Ignore invalid selectors on older engines.
      }
    }

    const questionName = normalizeWhitespace(question?.Name || question?.Text || "");
    const questionInput = findInputNearLabel(questionName);
    if (questionInput) return questionInput;

    return findInputNearLabel(field.label);
  }

  function setNativeInputValue(input, value) {
    const prototype = Object.getPrototypeOf(input);
    const descriptor = prototype ? Object.getOwnPropertyDescriptor(prototype, "value") : null;
    if (descriptor?.set) {
      descriptor.set.call(input, value);
    } else {
      input.value = value;
    }
  }

  function dispatchInputEvents(input, value) {
    setNativeInputValue(input, value);
    input.dispatchEvent(new root.Event("input", { bubbles: true }));
    input.dispatchEvent(new root.Event("change", { bubbles: true }));
    input.dispatchEvent(new root.KeyboardEvent("keydown", { bubbles: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    input.dispatchEvent(new root.KeyboardEvent("keyup", { bubbles: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    input.dispatchEvent(new root.Event("blur", { bubbles: true }));
  }

  function toLocalDate(value) {
    const match = String(value ?? "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;
    return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  }

  function setDateQuestionValue(question, field) {
    const jq = root.jQuery || root.$ || null;
    const input = findQuestionInput(question, field);
    const dateValue = toLocalDate(field.value);

    const target = question?.SelectedAnswer?.Answered;
    if (typeof target === "function") {
      target(dateValue || field.value);
    }

    if (!input) return;

    if (typeof input.focus === "function") input.focus();
    if (typeof input.click === "function") input.click();

    if (jq) {
      const $input = jq(input);
      try {
        if (typeof $input.datetimepicker === "function" && dateValue) {
          $input.datetimepicker("setDate", dateValue);
        } else if (typeof $input.datepicker === "function" && dateValue) {
          $input.datepicker("setDate", dateValue);
        }
      } catch {
        // Continue with native event fallback.
      }
    }

    dispatchInputEvents(input, field.value);
  }

  function sanitizeFolksamComplementPlan(input) {
    const allowedQuestionIds = new Set(Object.values(QUESTION_IDS));
    const allowedKinds = new Set(["text", "answerId", "date"]);
    const fields = Array.isArray(input?.fields)
      ? input.fields.flatMap((field) => {
          const questionId = typeof field?.questionId === "string" ? field.questionId : "";
          const label = typeof field?.label === "string" ? field.label.slice(0, 120) : "";
          const kind = typeof field?.kind === "string" ? field.kind : "";
          const value = typeof field?.value === "string" ? field.value.slice(0, 256) : "";
          if (!allowedQuestionIds.has(questionId) || !allowedKinds.has(kind) || !label || !value) return [];
          return [{ questionId, label, kind, value }];
        })
      : [];
    const cleanList = (value) => Array.isArray(value)
      ? value.filter((item) => typeof item === "string").slice(0, 16).map((item) => item.slice(0, 240))
      : [];
    return {
      fields,
      missingRequired: cleanList(input?.missingRequired),
      warnings: cleanList(input?.warnings)
    };
  }

  async function fillComplementPlan(planInput) {
    const plan = sanitizeFolksamComplementPlan(planInput);

    const survey = await waitForSurveyContext(
      [QUESTION_IDS.claimantName, QUESTION_IDS.claimantPersonNumber, QUESTION_IDS.caseType],
      20000
    );

    if (!survey) {
      return { ok: false, message: "Folksam survey not ready" };
    }

    const initialFields = plan.fields.filter(
      (field) =>
        field.questionId === QUESTION_IDS.claimantName ||
        field.questionId === QUESTION_IDS.claimantPersonNumber ||
        field.questionId === QUESTION_IDS.caseType
    );

    for (const field of initialFields) {
      const question = survey.AllQuestions?.[field.questionId];
      if (!question) {
        return { ok: false, message: `Folksam question missing: ${field.label}` };
      }
      setQuestionValue(question, field);
      await sleep(field.questionId === QUESTION_IDS.caseType ? 150 : 30);
    }

    const complementSurvey = await waitForSurveyContext(
      [QUESTION_IDS.incidentDate, QUESTION_IDS.folksamClaimNumber, QUESTION_IDS.completionType],
      10000
    );

    if (!complementSurvey) {
      return { ok: false, message: "Folksam complement fields not ready" };
    }

    const complementFields = plan.fields.filter(
      (field) =>
        field.questionId === QUESTION_IDS.incidentDate ||
        field.questionId === QUESTION_IDS.folksamClaimNumber ||
        field.questionId === QUESTION_IDS.completionType
    );

    for (const field of complementFields) {
      const question = complementSurvey.AllQuestions?.[field.questionId];
      if (!question) {
        return { ok: false, message: `Folksam question missing: ${field.label}` };
      }
      setQuestionValue(question, field);
      await sleep(30);
    }

    return {
      ok: true,
      filledFields: plan.fields.map((field) => field.label),
      missingFields: plan.missingRequired,
      warnings: plan.warnings || []
    };
  }

  async function fillComplement(payload) {
    const canonical = extractCanonicalPayload(payload);
    if (!canonical) return { ok: false, message: "Canonical payload missing" };
    return await fillComplementPlan(buildFolksamComplementPlan(canonical));
  }

  return {
    FOLKSAM_OMBUD_URL,
    QUESTION_IDS,
    ANSWER_IDS,
    extractCanonicalPayload,
    buildFolksamComplementPlan,
    sanitizeFolksamComplementPlan,
    fillComplementPlan,
    fillComplement,
    __test: {
      normalizePersonNumber,
      normalizeFolksamClaimNumber,
      isValidFolksamClaimNumber,
      normalizeIsoDate,
      toLocalDate,
      isFolksamText,
      resolveFolksamClaimNumber,
      buildFolksamComplementPlan,
      sanitizeFolksamComplementPlan,
      extractCanonicalPayload
    }
  };
});
