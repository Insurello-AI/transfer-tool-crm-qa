(function (root, factory) {
  const api = factory();
  root.__crmProtectorContracts = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const CONTRACTS = {
    "/swe/sv": { requiredAny: ["main button"] },
    "/swe/sv/captcha": { manual: "captcha" },
    "/swe/sv/5/category": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/claim-reporter-role": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/claim-reporter": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/insurance-type": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/privacy": { requiredAll: ["#acceptedPrivacy"] },
    "/swe/sv/5/accident/claim-location": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/claim-date": {
      requiredAll: ["[role='grid']", "button[aria-label='calendar view is open, switch to year view']"]
    },
    "/swe/sv/5/accident/claim-time-of-day": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/is-vehicle-involved": { requiredAny: ["main button"] },
    // Statically mapped from the shipped Claims@Net accident route graph.
    // These contracts deliberately recognize portal structure without implying
    // that the planner has enough CRM evidence to automate the answer.
    "/swe/sv/5/accident/vehicle-information": { requiredAll: ["#registrationNumber"] },
    "/swe/sv/5/accident/is-vehicle-motorcycle": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/person-in-vehicle": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/has-license": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/has-helmet": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/happen-domestically": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/during-sport": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/type-of-sport": { requiredAll: ["#typeOfSport"] },
    "/swe/sv/5/accident/teeth-or-body": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/body-parts": {
      requiredAny: ["#checkbox-WHOLE_BODY", "#checkbox-HEAD_FRONT", "#checkbox-HEAD_BACK"]
    },
    "/swe/sv/5/accident/teeth": { requiredAny: ["main input[type='checkbox']"] },
    "/swe/sv/5/accident/claim-cause": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/claim-cause-consequences": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/has-plaster-treatment": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/weeks-of-plaster-treatment": { requiredAll: ["#weeksOfPlasterTreatment"] },
    "/swe/sv/5/accident/previous-injury": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/date-of-previous-injury": {
      requiredAll: ["[role='grid']", "button[aria-label='calendar view is open, switch to year view']"]
    },
    "/swe/sv/5/accident/is-doctor-contacted": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/is-dentist-contacted": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/date-of-dentist-treatment": {
      requiredAll: ["[role='grid']", "button[aria-label='calendar view is open, switch to year view']"]
    },
    "/swe/sv/5/accident/dentist-information": { requiredAll: ["[name='dentist']"] },
    "/swe/sv/5/accident/type-of-medical-institution": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/date-of-treatment": {
      requiredAll: ["[role='grid']", "button[aria-label='calendar view is open, switch to year view']"]
    },
    "/swe/sv/5/accident/medical-institution-information": { requiredAll: ["[name='medicalInstitution']"] },
    "/swe/sv/5/accident/finished-treatment": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/invalidity": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/has-expenses": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/need-transport": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/in-elementary-school": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/upload-medical-certificate": { requiredAll: ["input[type='file']"] },
    "/swe/sv/5/accident/has-other-expenses": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/upload-receipt": { requiredAll: ["input[type='file']"] },
    "/swe/sv/5/accident/has-other-insurance": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/other-insurance-company": { requiredAll: ["#otherInsuranceCompany"] },
    "/swe/sv/5/accident/has-attachment": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/upload-attachment": { requiredAll: ["input[type='file']"] },
    "/swe/sv/5/accident/situation-summary": { requiredAll: ["#claimDescription"] },
    "/swe/sv/5/accident/company-information": { requiredAll: ["#name"] },
    "/swe/sv/5/accident/is-municipality": { requiredAny: ["main button"] },
    "/swe/sv/5/accident/school-information": {
      requiredAll: ["[name='name']", "#municipality", "[name='street']", "[name='zip']", "[name='city']"]
    },
    "/swe/sv/5/accident/association-information": { requiredAll: ["#selectAssociation"] },
    "/swe/sv/5/accident/claimant-information": {
      requiredAll: ["#missingSSN", "#firstName", "#lastName", "#nationalIdentity", "#email", "#phone", "#street", "#zip", "#city"]
    },
    "/swe/sv/5/accident/reporter-information": {
      requiredAll: ["#firstName", "#lastName", "#nationalIdentity", "#email", "#phone"]
    },
    "/swe/sv/5/accident/bank-account-information": {
      requiredAll: ["#clearingNumber", "#accountNumber", "#bankName"]
    },
    "/swe/sv/5/accident/final-summary": { requiredAll: ["#claimDescription"] },
    "/swe/sv/5/accident/report-completed": { manual: "report-completed" }
  };

  function normalizePath(value) {
    const raw = String(value || "");
    try {
      const url = new URL(raw, "https://claims-at-net.protectorforsakring.se");
      return url.pathname.replace(/\/+$/, "") || "/";
    } catch {
      return raw.split(/[?#]/)[0].replace(/\/+$/, "") || "/";
    }
  }

  function getContract(path) {
    return CONTRACTS[normalizePath(path)] || null;
  }

  function hasMeaningfulPortalDom(documentRef) {
    return [
      "main h1",
      "main h2",
      "main button",
      "main input",
      "main textarea",
      "main select",
      "main [role='grid']"
    ].some((selector) => Boolean(documentRef?.querySelector?.(selector)));
  }

  function validateDocument(documentRef, path) {
    const contract = getContract(path);
    if (!contract) return { ok: false, reason: "UNKNOWN_ROUTE" };
    if (contract.manual) return { ok: true, manual: contract.manual, matched: [], missing: [] };
    const missing = [];
    const matched = [];
    for (const selector of contract.requiredAll || []) {
      if (documentRef.querySelector(selector)) matched.push(selector);
      else missing.push(selector);
    }
    const any = contract.requiredAny || [];
    if (any.length > 0) {
      const matchedAny = any.filter((selector) => documentRef.querySelector(selector));
      matched.push(...matchedAny);
      if (matchedAny.length === 0) missing.push(any.join(" | "));
    }
    return missing.length > 0
      ? { ok: false, reason: "PORTAL_SCHEMA_MISMATCH", missing, matched }
      : { ok: true, missing: [], matched };
  }

  function normalizeDigits(value) {
    return String(value || "").replace(/\D/g, "");
  }

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLocaleLowerCase("sv-SE");
  }

  function validateBankState(state) {
    const failures = [];
    if (normalizeDigits(state?.actualClearing) !== normalizeDigits(state?.expectedClearing)) {
      failures.push("CLEARING_READBACK_MISMATCH");
    }
    if (normalizeDigits(state?.actualAccount) !== normalizeDigits(state?.expectedAccount)) {
      failures.push("ACCOUNT_READBACK_MISMATCH");
    }
    if (!normalizeText(state?.actualBankName)) failures.push("BANK_NAME_MISSING");
    else if (normalizeText(state?.actualBankName) !== normalizeText(state?.expectedBankName)) {
      failures.push("BANK_NAME_MISMATCH");
    }
    if (Array.isArray(state?.validationErrors) && state.validationErrors.length > 0) {
      failures.push("PORTAL_VALIDATION_ERROR");
    }
    if (state?.ownerFieldsPresent) {
      if (normalizeText(state?.actualOwnerGivenName) !== normalizeText(state?.expectedOwnerGivenName)) {
        failures.push("OWNER_GIVEN_NAME_READBACK_MISMATCH");
      }
      if (normalizeText(state?.actualOwnerFamilyName) !== normalizeText(state?.expectedOwnerFamilyName)) {
        failures.push("OWNER_FAMILY_NAME_READBACK_MISMATCH");
      }
    }
    return failures.length === 0
      ? { ok: true, status: "READY_FOR_REVIEW", failures: [] }
      : { ok: false, status: "BANK_ACCOUNT_VALIDATION_FAILED", failures };
  }

  return { CONTRACTS, normalizePath, getContract, hasMeaningfulPortalDom, validateDocument, validateBankState };
});
