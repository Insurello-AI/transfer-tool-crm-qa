(function (root, factory) {
  const api = factory();
  root.__crmProtectorCrmCrosswalk = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const STATUS = Object.freeze({
    AUTO: "AUTO",
    AMBIGUOUS: "AMBIGUOUS",
    NOT_APPLICABLE: "NOT_APPLICABLE"
  });

  const PROTECTOR_BODY_TARGETS = Object.freeze([
    "WHOLE_BODY",
    "HEAD_FRONT",
    "HEAD_BACK",
    "TORSO_FRONT",
    "TORSO_BACK",
    "ARM_LEFT",
    "ARM_RIGHT",
    "HAND_LEFT",
    "HAND_RIGHT",
    "LEG_LEFT",
    "LEG_RIGHT",
    "FOOT_LEFT",
    "FOOT_RIGHT"
  ]);

  const sided = (family) => ({
    LEFT: [`${family}_LEFT`],
    RIGHT: [`${family}_RIGHT`]
  });

  // Versioned reviewed crosswalk. Every known source concept is explicit.
  // Runtime may use this only after a bounded CRM label has been classified to
  // one of these source concepts; unknown labels must never fall through here.
  const BODY_PART_CROSSWALK = Object.freeze([
    { source: "head", status: STATUS.AMBIGUOUS, reason: "Head does not prove front or back." },
    { source: "face", status: STATUS.AUTO, targets: ["HEAD_FRONT"], reason: "Face is explicit anterior head evidence." },
    { source: "scalp", status: STATUS.AMBIGUOUS, reason: "Scalp does not prove front or back." },
    { source: "brain", status: STATUS.AMBIGUOUS, reason: "Brain proves head only, not direction." },
    { source: "cheek", status: STATUS.AUTO, targets: ["HEAD_FRONT"], preserveSourceLaterality: true, reason: "Cheek is anterior head evidence; Protector has no head side target." },
    { source: "ear", status: STATUS.AMBIGUOUS, reason: "Ear laterality does not resolve Protector front/back." },
    { source: "ear_drum", status: STATUS.AMBIGUOUS, reason: "Ear drum laterality does not resolve Protector front/back." },
    { source: "eye", status: STATUS.AUTO, targets: ["HEAD_FRONT"], preserveSourceLaterality: true, reason: "Eye is anterior head evidence; Protector has no head side target." },
    { source: "eyelid", status: STATUS.AUTO, targets: ["HEAD_FRONT"], preserveSourceLaterality: true, reason: "Eyelid is anterior head evidence; Protector has no head side target." },
    { source: "jaw", status: STATUS.AUTO, targets: ["HEAD_FRONT"], reason: "Jaw is treated as anterior facial evidence." },
    { source: "mouth", status: STATUS.AUTO, targets: ["HEAD_FRONT"], reason: "Mouth is explicit anterior head evidence." },
    { source: "nose", status: STATUS.AUTO, targets: ["HEAD_FRONT"], reason: "Nose is explicit anterior head evidence." },
    { source: "teeth", status: STATUS.NOT_APPLICABLE, reason: "Dental injury is handled by Protector's teeth/body branch, not the 13 body targets." },
    { source: "neck", status: STATUS.AMBIGUOUS, reason: "Neck is a head/torso boundary without approved policy." },
    { source: "throat", status: STATUS.AMBIGUOUS, reason: "Throat is a head/torso boundary without approved policy." },
    { source: "larynx", status: STATUS.AMBIGUOUS, reason: "Larynx is a head/torso boundary without approved policy." },
    { source: "cervical_spine", status: STATUS.AMBIGUOUS, reason: "Cervical spine must not be silently forced to head or torso." },
    { source: "chest", status: STATUS.AUTO, targets: ["TORSO_FRONT"], reason: "Chest is explicit anterior torso evidence." },
    { source: "intrathoracic_organ", status: STATUS.AMBIGUOUS, reason: "Internal thoracic anatomy does not prove the intended Protector surface category." },
    { source: "breast", status: STATUS.AUTO, targets: ["TORSO_FRONT"], preserveSourceLaterality: true, reason: "Breast is anterior torso evidence; Protector has no torso side target." },
    { source: "shoulder", status: STATUS.AUTO, targetByLaterality: sided("ARM"), reason: "Approved arm-family mapping with required laterality." },
    { source: "upper_arm", status: STATUS.AUTO, targetByLaterality: sided("ARM"), reason: "Upper arm maps directly to Protector arm." },
    { source: "collar_bone", status: STATUS.AMBIGUOUS, reason: "Collar bone is an arm/torso boundary requiring policy evidence." },
    { source: "shoulder_blade", status: STATUS.AMBIGUOUS, reason: "Shoulder blade is an arm/back boundary requiring policy evidence." },
    { source: "elbow", status: STATUS.AUTO, targetByLaterality: sided("ARM"), reason: "Elbow maps to Protector arm with side." },
    { source: "forearm", status: STATUS.AUTO, targetByLaterality: sided("ARM"), reason: "Forearm maps to Protector arm with side." },
    { source: "wrist", status: STATUS.AMBIGUOUS, reason: "Wrist is an arm/hand boundary requiring policy evidence." },
    { source: "hand", status: STATUS.AUTO, targetByLaterality: sided("HAND"), reason: "Hand maps directly to Protector hand." },
    { source: "thumb", status: STATUS.AUTO, targetByLaterality: sided("HAND"), reason: "Thumb maps to Protector hand with side." },
    { source: "finger", status: STATUS.AUTO, targetByLaterality: sided("HAND"), reason: "Finger maps to Protector hand with side." },
    { source: "hip", status: STATUS.AMBIGUOUS, reason: "Hip is a torso/leg boundary requiring policy evidence." },
    { source: "thigh", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Thigh maps directly to Protector leg." },
    { source: "knee", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Knee maps directly to Protector leg." },
    { source: "kneecap", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Kneecap maps to Protector leg with side." },
    { source: "cruciate_ligament", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Cruciate ligament maps to the sided knee/leg category." },
    { source: "meniscus", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Meniscus maps to the sided knee/leg category." },
    { source: "lower_leg", status: STATUS.AUTO, targetByLaterality: sided("LEG"), reason: "Lower leg maps directly to Protector leg." },
    {
      source: "ankle",
      status: STATUS.AUTO,
      targetByLaterality: {
        LEFT: ["LEG_LEFT", "FOOT_LEFT"],
        RIGHT: ["LEG_RIGHT", "FOOT_RIGHT"]
      },
      reason: "Handler-confirmed Protector policy: ankle/vrist selects both leg and foot on the observed side."
    },
    { source: "achilles", status: STATUS.AMBIGUOUS, reason: "Achilles is a leg/foot boundary requiring policy evidence." },
    { source: "foot", status: STATUS.AUTO, targetByLaterality: sided("FOOT"), reason: "Foot maps directly to Protector foot." },
    { source: "toe", status: STATUS.AUTO, targetByLaterality: sided("FOOT"), reason: "Toe maps to Protector foot with side." },
    { source: "great_toe", status: STATUS.AUTO, targetByLaterality: sided("FOOT"), reason: "Great toe maps to Protector foot with side." },
    { source: "torso", status: STATUS.AMBIGUOUS, reason: "Torso does not prove front or back." },
    { source: "heart", status: STATUS.AMBIGUOUS, reason: "Internal organ evidence does not prove the intended Protector surface category." },
    { source: "respiratory_system", status: STATUS.AMBIGUOUS, reason: "System-level anatomy does not prove front or back." },
    { source: "lower_back_and_pelvis", status: STATUS.AMBIGUOUS, reason: "Combined lower-back/pelvis concept crosses Protector boundaries." },
    { source: "abdomen", status: STATUS.AUTO, targets: ["TORSO_FRONT"], reason: "Abdomen is explicit anterior torso evidence." },
    { source: "abdominal_wall", status: STATUS.AUTO, targets: ["TORSO_FRONT"], reason: "Abdominal wall is explicit anterior torso evidence." },
    { source: "penis", status: STATUS.AMBIGUOUS, reason: "Genital anatomy has no approved Protector category policy." },
    { source: "vagina_and_vulva", status: STATUS.AMBIGUOUS, reason: "Genital anatomy has no approved Protector category policy." },
    { source: "scrotum_and_testes", status: STATUS.AMBIGUOUS, reason: "Genital anatomy has no approved Protector category policy." },
    { source: "spleen", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "liver_and_gallbladder", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "pancreas", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "alimentary_tract", status: STATUS.AMBIGUOUS, reason: "System-level anatomy does not prove a Protector surface category." },
    { source: "oesophagus", status: STATUS.AMBIGUOUS, reason: "Internal anatomy does not prove a Protector surface category." },
    { source: "stomach", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "small_intestine", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "colon", status: STATUS.AMBIGUOUS, reason: "Internal abdominal organ mapping requires policy evidence." },
    { source: "rectum", status: STATUS.AMBIGUOUS, reason: "Internal/pelvic anatomy mapping requires policy evidence." },
    { source: "intra_abdominal_organ", status: STATUS.AMBIGUOUS, reason: "Generic internal organ evidence cannot select a surface category." },
    { source: "kidney", status: STATUS.AMBIGUOUS, reason: "Kidney side does not resolve torso front/back policy." },
    { source: "ureter", status: STATUS.AMBIGUOUS, reason: "Ureter side does not resolve torso/pelvis policy." },
    { source: "bladder", status: STATUS.AMBIGUOUS, reason: "Internal pelvic organ mapping requires policy evidence." },
    { source: "urethra", status: STATUS.AMBIGUOUS, reason: "Internal/genital anatomy mapping requires policy evidence." },
    { source: "ovary", status: STATUS.AMBIGUOUS, reason: "Ovary side does not resolve torso/pelvis policy." },
    { source: "fallopian_tube", status: STATUS.AMBIGUOUS, reason: "Fallopian tube side does not resolve torso/pelvis policy." },
    { source: "uterus", status: STATUS.AMBIGUOUS, reason: "Internal pelvic organ mapping requires policy evidence." },
    { source: "pelvic_organ", status: STATUS.AMBIGUOUS, reason: "Generic pelvic organ evidence has no approved Protector target." },
    { source: "unspecified", status: STATUS.AMBIGUOUS, reason: "Unspecified anatomy must fail closed." }
  ]);

  const bySource = new Map(BODY_PART_CROSSWALK.map((entry) => [entry.source, entry]));

  function normalizeSource(value) {
    return String(value || "")
      .trim()
      .toLowerCase()
      .replace(/[\s-]+/g, "_");
  }

  function normalizeLaterality(value) {
    const side = String(value || "").trim().toUpperCase();
    return side === "LEFT" || side === "RIGHT" ? side : null;
  }

  function resolveBodyPart(source, laterality) {
    const sourceKey = normalizeSource(source);
    const entry = bySource.get(sourceKey);
    if (!entry) {
      return { source: sourceKey || null, status: "UNKNOWN", targets: [], reason: "SOURCE_BODY_PART_NOT_IN_SNAPSHOT" };
    }
    const side = normalizeLaterality(laterality);
    if (entry.status !== STATUS.AUTO) {
      return { source: entry.source, status: entry.status, targets: [], sourceLaterality: side, reason: entry.reason };
    }
    if (entry.targetByLaterality) {
      if (!side) {
        return { source: entry.source, status: STATUS.AMBIGUOUS, targets: [], sourceLaterality: null, reason: "LATERALITY_REQUIRED" };
      }
      return { source: entry.source, status: STATUS.AUTO, targets: [...entry.targetByLaterality[side]], sourceLaterality: side, reason: entry.reason };
    }
    return {
      source: entry.source,
      status: STATUS.AUTO,
      targets: [...(entry.targets || [])],
      sourceLaterality: entry.preserveSourceLaterality ? side : null,
      reason: entry.reason
    };
  }

  function summarizeCrosswalk() {
    return BODY_PART_CROSSWALK.reduce((summary, entry) => {
      summary[entry.status] += 1;
      return summary;
    }, { AUTO: 0, AMBIGUOUS: 0, NOT_APPLICABLE: 0 });
  }

  function resolveBodyParts(entries) {
    const items = (Array.isArray(entries) ? entries : []).map((entry) =>
      resolveBodyPart(entry?.source ?? entry, entry?.laterality)
    );
    const automatic = items.filter((item) => item.status === STATUS.AUTO);
    const safeTargets = [...new Set(automatic.flatMap((item) => item.targets))];
    const blocking = items.filter((item) => item.status === STATUS.AMBIGUOUS || item.status === "UNKNOWN");
    if (blocking.length > 0) {
      return { status: "USER_REQUIRED", targets: safeTargets, items, reason: "ONE_OR_MORE_BODY_PARTS_NOT_SAFELY_CLASSIFIED" };
    }
    if (automatic.length === 0) {
      return { status: STATUS.NOT_APPLICABLE, targets: [], items, reason: "NO_BODY_TARGET_APPLICABLE" };
    }
    return {
      status: STATUS.AUTO,
      targets: safeTargets,
      items,
      reason: "ALL_RELEVANT_BODY_PARTS_SAFELY_CLASSIFIED"
    };
  }

  function validateCrosswalk(expectedSources) {
    const errors = [];
    const sources = BODY_PART_CROSSWALK.map((entry) => entry.source);
    const duplicates = sources.filter((source, index) => sources.indexOf(source) !== index);
    if (duplicates.length > 0) errors.push(`DUPLICATE_SOURCES:${[...new Set(duplicates)].join(",")}`);
    if (Array.isArray(expectedSources)) {
      const expected = new Set(expectedSources);
      const actual = new Set(sources);
      const missing = [...expected].filter((source) => !actual.has(source));
      const unexpected = [...actual].filter((source) => !expected.has(source));
      if (missing.length > 0) errors.push(`MISSING_SOURCES:${missing.join(",")}`);
      if (unexpected.length > 0) errors.push(`UNEXPECTED_SOURCES:${unexpected.join(",")}`);
    }
    for (const entry of BODY_PART_CROSSWALK) {
      if (!Object.values(STATUS).includes(entry.status)) errors.push(`INVALID_STATUS:${entry.source}`);
      const targets = [...(entry.targets || []), ...Object.values(entry.targetByLaterality || {}).flat()];
      if (targets.some((target) => !PROTECTOR_BODY_TARGETS.includes(target))) errors.push(`INVALID_TARGET:${entry.source}`);
      if (entry.status === STATUS.AUTO && targets.length === 0) errors.push(`AUTO_WITHOUT_TARGET:${entry.source}`);
      if (entry.status !== STATUS.AUTO && targets.length > 0) errors.push(`NON_AUTO_WITH_TARGET:${entry.source}`);
    }
    return { ok: errors.length === 0, errors, summary: summarizeCrosswalk() };
  }

  return {
    STATUS,
    PROTECTOR_BODY_TARGETS,
    BODY_PART_CROSSWALK,
    normalizeSource,
    normalizeLaterality,
    resolveBodyPart,
    resolveBodyParts,
    summarizeCrosswalk,
    validateCrosswalk
  };
});
