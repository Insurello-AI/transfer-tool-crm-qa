(function (root, factory) {
  const api = factory();

  root.__crmWorkflowMode = api;

  if (typeof module === "object" && module && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const DEFAULT_MODE = "pregame";
  const ENDGAME_MODE = "endgame";
  const STORAGE_KEY = "crmClipboardWorkflowModeV1";

  function normalizeWorkflowMode(value) {
    return value === ENDGAME_MODE ? ENDGAME_MODE : DEFAULT_MODE;
  }

  function isEndgameMode(value) {
    return normalizeWorkflowMode(value) === ENDGAME_MODE;
  }

  function getPrimaryActionLabel(value) {
    return isEndgameMode(value) ? "Folksam Portal - Komplettera" : "Skadeanmälan – hämta & öppna";
  }

  function getPrimaryActionPendingText(value) {
    return isEndgameMode(value) ? "Hämtar CRM-data och öppnar Folksam Portal…" : "Hämtar CRM-data och öppnar Skadeanmälan…";
  }

  return {
    DEFAULT_MODE,
    ENDGAME_MODE,
    STORAGE_KEY,
    normalizeWorkflowMode,
    isEndgameMode,
    getPrimaryActionLabel,
    getPrimaryActionPendingText
  };
});
