(function (root, factory) {
  const api = factory();
  root.__crmProtectorPlan = api;
  if (typeof module === "object" && module && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const canonicalAdapters = globalThis.__crmProtectorCanonicalAdapters ||
    (typeof require === "function" ? require("./protectorCanonicalAdapters.js") : null);
  const crmCrosswalk = globalThis.__crmProtectorCrmCrosswalk ||
    (typeof require === "function" ? require("./protectorCrmCrosswalk.js") : null);
  const sportCrosswalk = globalThis.__crmProtectorSportCrosswalk ||
    (typeof require === "function" ? require("./protectorSportCrosswalk.js") : null);
  const insurerCrosswalk = globalThis.__crmProtectorInsurerCrosswalk ||
    (typeof require === "function" ? require("./protectorInsurerCrosswalk.js") : null);
  const semanticCoverage = globalThis.__crmProtectorSemanticCoverage ||
    (typeof require === "function" ? require("./protectorSemanticCoverage.js") : null);
  const AUTO = "AUTO";
  const USER_REQUIRED = "USER_REQUIRED";
  const UNSUPPORTED = "UNSUPPORTED";
  const HARD_STOP = "HARD_STOP";

  function fold(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .toLowerCase();
  }

  function compact(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function booleanChoice(value) {
    if (value === true) return "Ja";
    if (value === false) return "Nej";
    return null;
  }

  function resolveVehicleRegistration(canonical) {
    if (!canonicalAdapters?.normalizeRegistrationNumber) return null;
    return canonicalAdapters.normalizeRegistrationNumber(canonical?.vehicle?.registrationNumber);
  }

  function resolveVehicleMotorcycleChoice(canonical) {
    const vehicle = canonical?.vehicle || {};
    if (typeof vehicle.isMotorcycleOrMoped === "boolean") return booleanChoice(vehicle.isMotorcycleOrMoped);

    const tags = new Set(
      (Array.isArray(vehicle.tags) ? vehicle.tags : [])
        .map((value) => compact(value).toUpperCase())
        .filter(Boolean)
    );
    if (tags.has("MOPED_CLASS_1")) return "Ja";

    if (canonicalAdapters?.resolveVehicleType && compact(vehicle.type)) {
      const resolution = canonicalAdapters.resolveVehicleType(vehicle.type);
      if (resolution?.status === AUTO && typeof resolution.isMotorcycleOrMoped === "boolean") {
        return booleanChoice(resolution.isMotorcycleOrMoped);
      }
    }
    return null;
  }

  function resolvePersonInVehicleChoice(canonical) {
    const vehicle = canonical?.vehicle || {};
    if (typeof vehicle.personInVehicle === "boolean") return booleanChoice(vehicle.personInVehicle);
    const tags = new Set(
      (Array.isArray(vehicle.tags) ? vehicle.tags : [])
        .map((value) => compact(value).toUpperCase())
        .filter(Boolean)
    );
    if (tags.has("DRIVER") || tags.has("PASSENGER")) return "Ja";
    return null;
  }

  function resolveElementarySchoolChoice(canonical) {
    const educationLevel = fold(canonical?.incident?.school?.educationLevel);
    if (!educationLevel) return null;
    if (educationLevel === "grundskola") return "Ja";
    return null;
  }

  function clickStep(text, note) {
    return { execution: AUTO, actions: [{ type: "click_text", text }], note: note || null };
  }

  function manualStep(reason, note) {
    return { execution: USER_REQUIRED, reason, note: note || "Välj manuellt – flödet fortsätter när du går vidare." };
  }

  function resolveInsuranceType(canonical) {
    const matter = canonical?.meta?.insuranceMatter || {};
    const classify = (values) => {
      const kinds = new Set();
      for (const value of Array.isArray(values) ? values : [values]) {
        const text = fold(value);
        if (!text) continue;
        if (/kommunforsakring|skolforsakring|kommun|forskol|elevforsakring/.test(text)) kinds.add("Kommun-/skolförsäkring");
        if (/foretagsforsakring|arbetsgivar|tjanste/.test(text)) kinds.add("Företagsförsäkring");
        if (/privat|forbund|medlem|gruppforsakring|licensforsakring/.test(text)) kinds.add("Privatförsäkring");
      }
      return {
        value: kinds.size === 1 ? [...kinds][0] : null,
        conflict: kinds.size > 1
      };
    };

    const protectorCards = (Array.isArray(matter.cards) ? matter.cards : []).filter((card) =>
      /\bprotector\b/.test(fold(card?.insurer)) || /\bprotector\b/.test(fold(card?.displayName))
    );
    if (protectorCards.length > 0) {
      const fromProtectorCards = classify(protectorCards.flatMap((card) => [card?.product, card?.displayName]));
      if (fromProtectorCards.conflict) return null;
      if (fromProtectorCards.value) return fromProtectorCards.value;
    }

    const activeEntries = (Array.isArray(matter.entries) ? matter.entries : [])
      .filter((entry) => !entry?.stateKind || entry.stateKind === "active")
      .map((entry) => entry?.displayName)
      .filter(Boolean);
    const matterTexts = activeEntries.length > 0
      ? [...activeEntries, matter.product]
      : [matter.displayName, ...(Array.isArray(matter.displayNames) ? matter.displayNames : []), matter.product];
    const fromMatter = classify(matterTexts);
    if (fromMatter.conflict) return null;
    if (fromMatter.value) return fromMatter.value;

    const schoolPolicyholder = fold(canonical?.incident?.school?.policyholder);
    if (/\bkommun\b|\bstad\b/.test(schoolPolicyholder)) return "Kommun-/skolförsäkring";
    return null;
  }

  function hasPrivateSportInsuranceEvidence(canonical) {
    const matter = canonical?.meta?.insuranceMatter || {};
    const values = [
      ...(Array.isArray(matter.cards)
        ? matter.cards.flatMap((card) => [card?.product, card?.displayName])
        : []),
      ...(Array.isArray(matter.entries) ? matter.entries.map((entry) => entry?.displayName) : []),
      matter.displayName,
      ...(Array.isArray(matter.displayNames) ? matter.displayNames : [])
    ].map(fold).filter(Boolean);
    // This is intentionally narrower than "a private insurance exists". It
    // only identifies insurance whose own label says it is tied to sport or a
    // sport licence/federation, as observed in the Svedea licence case.
    return values.some((text) =>
      /licensforsakring|idrottsforsakring|sportforsakring|idrottsforbund|budo.*kampsport/.test(text)
    );
  }

  function resolveLocation(canonical, insuranceType) {
    const text = fold(canonical?.incident?.context);
    if (!text) return null;
    // Travel to/from sport is neither verified school/work travel nor proof
    // that the accident happened during the activity. Fail closed.
    if (/(?:pa vag|till fran).*(?:idrott|sport|traning|gym)|(?:idrott|sport|traning|gym).*(?:pa vag|till fran)/.test(text)) {
      return null;
    }
    if (/fritid|ovrig tid/.test(text)) return "På fritid";
    // Explicit sport plus a sport-specific private/licence insurance is strong
    // leisure evidence even if the same CRM case also contains a Protector
    // municipal card. Never use this shortcut when the incident context itself
    // says school/work, where sport can legitimately happen during covered time.
    const explicitSport = /under.*(?:idrott|sport|traning)|(?:idrott|sport|traning).*under/.test(text);
    const explicitSchoolOrWork = /skol|verksamhet|arbete|arbetstid|arbetsplats/.test(text);
    if (
      explicitSport &&
      !explicitSchoolOrWork &&
      (insuranceType === "Privatförsäkring" || hasPrivateSportInsuranceEvidence(canonical))
    ) {
      return "På fritid";
    }
    if (/(?:pa vag|till fran).*(?:skol|verksamhet)|(?:skol|verksamhet).*(?:pa vag|till fran)/.test(text)) {
      return "På väg till/från skolan/verksamheten";
    }
    if (/(?:pa vag|till fran).*(?:arbete|jobbet|arbetsplats)|(?:arbete|jobbet|arbetsplats).*(?:pa vag|till fran)/.test(text)) {
      return "På väg till/från arbetet";
    }
    // A generic travel context does not identify the destination. Insurance
    // type is not sufficient evidence for school-vs-work travel.
    if (/pa vag|till fran/.test(text)) return null;
    if (/skol|verksamhet/.test(text)) return "På skol-/verksamhetstid";
    if (/arbete|arbetstid/.test(text)) return "På arbetet";
    return null;
  }

  function resolveTimeOfDay(value) {
    const match = String(value || "").match(/\b(\d{1,2}):(\d{2})\b/);
    if (!match) return null;
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    const minutes = hour * 60 + minute;
    return minutes >= 7 * 60 && minutes < 19 * 60 ? "På dagen" : "På kvällen/natten";
  }

  function normalizeIncidentDate(value) {
    const text = compact(value);
    let match = text.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
    if (!match) {
      const dmy = text.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
      if (dmy) match = [dmy[0], dmy[3], dmy[2], dmy[1]];
    }
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const candidate = new Date(Date.UTC(year, month - 1, day));
    if (
      candidate.getUTCFullYear() !== year ||
      candidate.getUTCMonth() !== month - 1 ||
      candidate.getUTCDate() !== day
    ) return null;
    return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }

  function detectSide(text) {
    if (/\bvanster\b|\(v\)/.test(text)) return "LEFT";
    if (/\bhoger\b|\(h\)/.test(text)) return "RIGHT";
    return null;
  }

  function resolveBodyPartsLegacy(injuries, incidentDescription) {
    const values = new Set();
    const ambiguous = [];
    const unsupported = [];
    for (const raw of Array.isArray(injuries) ? injuries : []) {
      const text = fold(raw);
      if (!text) continue;
      if (/hela kroppen|forfrysning|varmeslag/.test(text)) {
        values.add("WHOLE_BODY");
        continue;
      }
      const side = detectSide(text);
      if (/fotled|vrist/.test(text)) {
        if (side) {
          values.add(`LEG_${side}`);
          values.add(`FOOT_${side}`);
        } else {
          ambiguous.push({ source: raw, reason: "MISSING_SIDE" });
        }
        continue;
      }
      if (/handled|hoft/.test(text)) {
        ambiguous.push({ source: raw, reason: "BOUNDARY_BODY_PART" });
        continue;
      }
      if (/ansikte|oga|oron|ora|nasa|mun|panna/.test(text)) {
        values.add("HEAD_FRONT");
        continue;
      }
      if (/nacke|bakhuvud/.test(text)) {
        values.add("HEAD_BACK");
        continue;
      }
      if (/huvud|skalle|skallfraktur|hjarnblodning|hjarnskakning/.test(text)) {
        ambiguous.push({ source: raw, reason: "HEAD_FRONT_OR_BACK" });
        continue;
      }
      if (/brost|mage|buk|ljumske/.test(text)) {
        values.add("TORSO_FRONT");
        continue;
      }
      if (/rygg|landrygg|skulderblad|rumpa/.test(text)) {
        values.add("TORSO_BACK");
        continue;
      }
      let family = null;
      if (/finger|tumme|handflata|\bhand\b/.test(text)) family = "HAND";
      else if (/axel|overarm|underarm|armbage|\barm\b/.test(text)) family = "ARM";
      else if (/\bfot\b|fotrygg|hal|tar|\bta\b/.test(text)) family = "FOOT";
      else if (/lar|kna|knaskal|menisk|underben|vad|skenben|\bben\b/.test(text)) family = "LEG";
      if (family && side) values.add(`${family}_${side}`);
      else if (family) ambiguous.push({ source: raw, reason: "MISSING_SIDE" });
      else unsupported.push(raw);
    }
    const description = fold(incidentDescription);
    if (/ogonbryn|ansikte|panna|nasa|mun|haka|kind/.test(description)) {
      const unresolved = ambiguous.filter((item) => item.reason !== "HEAD_FRONT_OR_BACK");
      if (unresolved.length !== ambiguous.length) {
        values.add("HEAD_FRONT");
        ambiguous.length = 0;
        ambiguous.push(...unresolved);
      }
    }
    if (ambiguous.length > 0 || unsupported.length > 0) return { execution: USER_REQUIRED, values: [...values], ambiguous, unsupported };
    if (values.size === 0) return { execution: USER_REQUIRED, values: [], ambiguous, unsupported };
    return { execution: AUTO, values: [...values], ambiguous, unsupported };
  }

  const BODY_SOURCE_RULES = Object.freeze([
    ["great_toe", /\bstorta\b|\bgreat toe\b/],
    ["toe", /\bta\b|\btar\b|\btoe\b|\btoes\b/],
    ["ankle", /fotled|vrist|\bankle\b/],
    ["foot", /\bfot\b|fotrygg|\bfoot\b/],
    ["achilles", /halsena|achilles/],
    ["lower_leg", /underben|skenben|\bvad\b|lower leg|tibia/],
    ["meniscus", /menisk|meniscus/],
    ["cruciate_ligament", /korsband|cruciate/],
    ["kneecap", /knaskal|kneecap|patella/],
    ["knee", /kna(?:led)?|\bknee\b/],
    ["thigh", /\blar\b|\bthigh\b/],
    ["hip", /hoft|\bhip\b/],
    ["finger", /finger/],
    ["thumb", /tumme|thumb/],
    ["wrist", /handled|wrist/],
    ["hand", /\bhand(?:\b|fraktur|skada)|handflata/],
    ["forearm", /underarm|forearm/],
    ["elbow", /armbage|elbow/],
    ["upper_arm", /overarm|upper arm/],
    ["shoulder_blade", /skulderblad|shoulder blade|scapula/],
    ["collar_bone", /nyckelben|collar bone|clavicle/],
    ["shoulder", /axel|shoulder/],
    ["cervical_spine", /halsrygg|cervical spine/],
    ["larynx", /struphuvud|larynx/],
    ["throat", /\bhals\b|\bthroat\b/],
    ["neck", /\bnacke\b|\bneck\b/],
    ["eyelid", /ogonlock|eyelid/],
    ["eye", /\boga\b|\bogon\b|\beye\b/],
    ["cheek", /\bkind\b|\bcheek\b/],
    ["ear_drum", /trumhinna|ear drum|eardrum/],
    ["ear", /\bora\b|\boron\b|\bear\b/],
    ["jaw", /\bkake\b|\bjaw\b/],
    ["mouth", /\bmun\b|\bmouth\b/],
    ["nose", /\bnasa\b|\bnose\b/],
    ["face", /ansikte|\bface\b/],
    ["teeth", /\btand\b|tander|\bteeth\b/],
    ["brain", /hjarna|hjarn|\bbrain\b/],
    ["scalp", /harbotten|scalp/],
    ["head", /\bhuvud\b|skalle|skall|\bhead\b|cranium/],
    ["breast", /\bbrost\b|\bbreast\b/],
    ["chest", /brostkorg|\bchest\b/],
    ["abdominal_wall", /bukvagg|abdominal wall/],
    ["abdomen", /\bbuk\b|\bmage\b|abdomen/],
    ["lower_back_and_pelvis", /landrygg.*backen|backen.*landrygg|lower back and pelvis/],
    ["torso", /\btorso\b|\bbal\b/],
    ["kidney", /njure|kidney/],
    ["bladder", /urinblasa|bladder/],
    ["uterus", /livmoder|uterus/],
    ["ovary", /aggstock|ovary/],
    ["penis", /\bpenis\b/],
    ["vagina_and_vulva", /vagina|vulva/],
    ["scrotum_and_testes", /pung|testikel|scrotum|testes/]
  ]);

  function classifyBodySourceConcept(raw) {
    const text = fold(raw);
    if (!text) return null;
    for (const [source, pattern] of BODY_SOURCE_RULES) {
      if (pattern.test(text)) return { source, laterality: detectSide(text), raw };
    }
    return null;
  }

  function resolveDirectionalHeadEvidence(value) {
    const text = fold(value);
    if (!text) return null;
    if (/huvudets framsida|framsida av huvudet|ogonbryn|ansikte|panna|nasa|mun|haka|kind/.test(text)) return "HEAD_FRONT";
    if (/huvudets baksida|baksida av huvudet|bakhuvud/.test(text)) return "HEAD_BACK";
    return null;
  }

  function resolveBodyParts(injuries, incidentDescription) {
    const rawEntries = Array.isArray(injuries) ? injuries : [];
    const formalEntries = [];
    const unclassified = [];
    const directTargets = new Set();

    for (const raw of rawEntries) {
      const text = fold(raw);
      if (/huvud.*framsida|framsida.*huvud|head.*front|front.*head/.test(text)) {
        directTargets.add("HEAD_FRONT");
        continue;
      }
      if (/huvud.*baksida|baksida.*huvud|bakhuvud|head.*back|back.*head/.test(text)) {
        directTargets.add("HEAD_BACK");
        continue;
      }
      const classified = classifyBodySourceConcept(raw);
      if (classified) formalEntries.push(classified);
      else unclassified.push(raw);
    }

    if (formalEntries.length > 0 && crmCrosswalk?.resolveBodyParts) {
      const formal = crmCrosswalk.resolveBodyParts(formalEntries);
      if (formal.status === USER_REQUIRED) {
        (formal.targets || []).forEach((target) => directTargets.add(target));
        const blockers = formal.items.filter((item) => item.status === "AMBIGUOUS" || item.status === "UNKNOWN");
        const headDirection = resolveDirectionalHeadEvidence(incidentDescription);
        const onlyDirectionallyResolvableHead = Boolean(headDirection) && blockers.length > 0 && blockers.every((item) =>
          ["head", "brain", "scalp"].includes(item.source)
        );
        if (onlyDirectionallyResolvableHead) {
          formal.items
            .filter((item) => item.status === AUTO)
            .flatMap((item) => item.targets || [])
            .forEach((target) => directTargets.add(target));
          directTargets.add(headDirection);
        } else {
        return {
          execution: USER_REQUIRED,
          values: [...directTargets],
          ambiguous: blockers,
          unsupported: unclassified,
          formalItems: formal.items
        };
        }
      }
      if (formal.status === AUTO) formal.targets.forEach((target) => directTargets.add(target));
    }

    // Only the residue that could not be classified to the reviewed Insuro
    // concepts may use the legacy bounded resolver. A formally recognized
    // ambiguous concept can never be rescued by free-text regex.
    if (unclassified.length > 0) {
      const legacy = resolveBodyPartsLegacy(unclassified, incidentDescription);
      if (legacy.execution !== AUTO) {
        return {
          execution: USER_REQUIRED,
          values: [...directTargets, ...(legacy.values || [])],
          ambiguous: legacy.ambiguous || [],
          unsupported: legacy.unsupported || unclassified,
          formalItems: []
        };
      }
      (legacy.values || []).forEach((target) => directTargets.add(target));
    }

    if (directTargets.size > 0) {
      return { execution: AUTO, values: [...directTargets], ambiguous: [], unsupported: [], formalItems: formalEntries };
    }
    return resolveBodyPartsLegacy(rawEntries, incidentDescription);
  }

  function resolveCause(canonical) {
    const text = fold([canonical?.incident?.description, canonical?.incident?.place].filter(Boolean).join(" "));
    const injuryText = fold([
      ...(Array.isArray(canonical?.injuries?.bodyInjuries) ? canonical.injuries.bodyInjuries : []),
      ...(Array.isArray(canonical?.injuries?.consequenceSourceTexts) ? canonical.injuries.consequenceSourceTexts : []),
      ...(Array.isArray(canonical?.injuries?.consequencesEvidence) ? canonical.injuries.consequencesEvidence : [])
    ].join(" "));
    const explicitCollision = /krock|kollision|sammanstot|tacklad|tackling/.test(text);
    const bodyToBodyImpact = /\b(?:hans|hennes|motstandarens|spelarens)[^.]{0,40}\b(?:kna|knaskal|armbage|axel|huvud|fot)[^.]{0,60}\b(?:kom|traffade|landade|slog)[^.]{0,30}\b(?:pa|mot|i)\b[^.]{0,40}\b(?:mitt|min|mina)\b/.test(text) ||
      /\bfick\b[^.]{0,80}\b(?:kna|knaskal|armbage|axel|huvud|fot)\b[^.]{0,40}\b(?:i|mot|pa)\b[^.]{0,40}\b(?:ansikte|huvud|kropp|ben|arm)\b/.test(text);
    const impactTarget = "(?:bord|bordshorn|vagg|dorr|stol|stolpe|person|foremal|lekredskap|hinder(?:et)?|fonsterkarm(?:en)?|knaskal(?:en)?|kna(?:et)?)";
    const directObjectImpact = new RegExp(`(?:slog|stotte)[^.]{0,120}\\b(?:in i|mot|i|pa)\\b[^.]{0,50}\\b${impactTarget}\\b`).test(text);
    const fallIntoObject = new RegExp(`(?:foll|raml(?:ade|at)|trillade)[^.]{0,120}\\b(?:in i|mot)\\b[^.]{0,50}\\b${impactTarget}\\b`).test(text);
    const objectImpact = directObjectImpact || fallIntoObject;
    const tableCorner = /\bbordshorn(?:et)?\b|\bhornet pa (?:ett|en)(?: av)? bord(?:et|en)?\b/.test(text);
    const directedCornerImpact = /(?:foll|ramlade|snubblade)[^.]{0,160}\bin i\b|(?:slog|stotte)[^.]{0,120}\b(?:i|mot)\b/.test(text);
    if (explicitCollision || bodyToBodyImpact || objectImpact || (tableCorner && directedCornerImpact)) return "Krock/sammanstötning";
    const jointDislocationEvidence = /luxation|ur led|dislokation/.test(injuryText);
    const jointGaveWayBeforeFall = /\b(?:kna|knaskal|fotled|ankel)[^.]{0,100}\b(?:forsvann|gav vika|vek sig|hoppade ur|ur led)[^.]{0,100}\b(?:ramlade|foll|trillade)\b/.test(text);
    const explicitTwistBeforeFall = /\b(?:vred|vrider|vrida|vrickade|vridning|vridvald)[^.]{0,100}\b(?:ramlade|foll|trillade)\b/.test(text);
    if ((jointDislocationEvidence && jointGaveWayBeforeFall) || explicitTwistBeforeFall) return "Vridvåld";
    if (/raml(?:ade|at|ar)|foll|snubblade|halkade|trillade/.test(text)) return "Fall";
    if (/skarde|skarsar|skarverktyg/.test(text)) return "Skärskada";
    if (/klamde|klamskada/.test(text)) return "Klämskada";
    if (/vred|vrider|vrida|vridvald|vrickade/.test(text)) return "Vridvåld";
    if (/misshandel/.test(text)) return "Misshandel";
    if (/brann|brannskada/.test(text)) return "Brännskada";
    if (/elstot/.test(text)) return "Elstöt";
    if (/kemikal/.test(text)) return "Kemikalier";
    if (/forfrys|varmeslag/.test(text)) return "Värme/förfrysning";
    if (/djurbett|hundbett|kattbett/.test(text)) return "Djurbett";
    return null;
  }

  function resolveConsequences(injuries, explicitEvidence) {
    const text = fold([
      ...(Array.isArray(injuries) ? injuries : []),
      ...(Array.isArray(explicitEvidence) ? explicitEvidence : [])
    ].join(" "));
    const values = [];
    if (/sarskada|sar\b/.test(text)) values.push("Sårskada");
    if (/mjukdel|muskel|sena|menisk|korsband|ligament|ruptur|kontusion|svullnad|blamarke/.test(text)) values.push("Mjukdelsskada");
    if (/stukning|vrickning|strackning/.test(text)) values.push("Stukning");
    if (/ur led|luxation|dislokation/.test(text)) values.push("Urledvridning");
    if (/spricka/.test(text)) values.push("Spricka");
    if (/fraktur|brott/.test(text)) values.push("Fraktur");
    if (/kross/.test(text)) values.push("Kross-skada");
    return [...new Set(values)];
  }

  function splitName(value) {
    const parts = compact(value).split(" ").filter(Boolean);
    if (parts.length < 2) return { firstName: parts[0] || "", lastName: "" };
    return { firstName: parts.slice(0, -1).join(" "), lastName: parts[parts.length - 1] };
  }

  function formatPersonNumber(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (digits.length === 12) return `${digits.slice(2, 8)}-${digits.slice(8)}`;
    if (digits.length === 10) return `${digits.slice(0, 6)}-${digits.slice(6)}`;
    return "";
  }

  function deriveAgeAtIncident(personNumber, incidentDateValue) {
    const incidentDate = normalizeIncidentDate(incidentDateValue);
    const digits = String(personNumber || "").replace(/\D/g, "");
    if (!incidentDate || ![10, 12].includes(digits.length)) return null;
    const incidentYear = Number(incidentDate.slice(0, 4));
    let year = digits.length === 12 ? Number(digits.slice(0, 4)) : 2000 + Number(digits.slice(0, 2));
    if (digits.length === 10 && year > incidentYear) year -= 100;
    const month = Number(digits.slice(digits.length === 12 ? 4 : 2, digits.length === 12 ? 6 : 4));
    let day = Number(digits.slice(digits.length === 12 ? 6 : 4, digits.length === 12 ? 8 : 6));
    if (day > 60) day -= 60;
    const birthDate = new Date(Date.UTC(year, month - 1, day));
    if (birthDate.getUTCFullYear() !== year || birthDate.getUTCMonth() !== month - 1 || birthDate.getUTCDate() !== day) return null;
    const [incidentMonth, incidentDay] = incidentDate.slice(5).split("-").map(Number);
    let age = incidentYear - year;
    if (incidentMonth < month || (incidentMonth === month && incidentDay < day)) age -= 1;
    return age >= 0 && age <= 120 ? age : null;
  }

  function samePerson(left, right) {
    const normalizeComparableNumber = (value) => {
      const digits = String(value || "").replace(/\D/g, "");
      if (digits.length === 12) return digits.slice(2);
      return digits.length === 10 ? digits : "";
    };
    const leftNumber = normalizeComparableNumber(left?.personNumber);
    const rightNumber = normalizeComparableNumber(right?.personNumber);
    if (leftNumber && rightNumber) return leftNumber === rightNumber;
    const leftName = fold(left?.name);
    const rightName = fold(right?.name);
    return Boolean(leftName && rightName && leftName === rightName);
  }

  function canComparePersons(left, right) {
    const leftNumber = String(left?.personNumber || "").replace(/\D/g, "");
    const rightNumber = String(right?.personNumber || "").replace(/\D/g, "");
    const comparableNumbers = [leftNumber, rightNumber].every((digits) => digits.length === 10 || digits.length === 12);
    const comparableNames = Boolean(fold(left?.name) && fold(right?.name));
    return comparableNumbers || comparableNames;
  }

  function resolveClaimReporterRole(canonical) {
    const customer = canonical?.customer || {};
    const claimant = canonical?.claimant || {};
    if (!canComparePersons(customer, claimant)) {
      return { role: null, relation: null, reporter: null, comparison: "AMBIGUOUS" };
    }
    if (samePerson(customer, claimant)) {
      return { role: "Mig själv", relation: null, reporter: null, comparison: "SAME_PERSON" };
    }
    const statedAge = Number.isFinite(claimant?.ageAtIncident) ? Number(claimant.ageAtIncident) : null;
    const claimantAge = statedAge === null
      ? deriveAgeAtIncident(claimant?.personNumber, canonical?.incident?.date)
      : statedAge;
    if (claimantAge === null || claimantAge >= 18) {
      return {
        role: null,
        relation: null,
        reporter: null,
        comparison: claimantAge === null ? "DIFFERENT_PERSON_AGE_UNKNOWN" : "DIFFERENT_PERSON_ADULT"
      };
    }
    return {
      role: "Ett barn",
      relation: "Förälder/vårdnadshavare",
      reporter: { ...customer, relationship: null, source: "customer" },
      comparison: "DIFFERENT_PERSON"
    };
  }

  function resolveReporter(canonical) {
    const explicit = canonical?.reporter || {};
    if (compact(explicit.name) || compact(explicit.personNumber)) return explicit;
    const customer = canonical?.customer || {};
    if ((compact(customer.name) || compact(customer.personNumber)) && !samePerson(customer, canonical?.claimant)) {
      return { ...customer, relationship: customer.relationship || null, source: "customer" };
    }
    return {};
  }

  function resolveReporterRelation(reporter) {
    const relationship = fold(reporter?.relationship);
    if (/foralder|vardnadshavare|parent|guardian/.test(relationship)) return "Förälder/vårdnadshavare";
    if (/annan|other/.test(relationship)) return "Annan";
    return null;
  }

  function buildInformationStep(fields, requiredIds, note) {
    const actions = fields.filter((action) => compact(action.value));
    const valuesById = Object.fromEntries(actions.map((action) => [action.id, action.value]));
    const complete = requiredIds.every((id) => compact(valuesById[id]));
    if (complete) return {
      execution: AUTO,
      actions: [
        ...actions,
        { type: "verify_fields", fields: actions.filter((action) => action.id).map((action) => ({ id: action.id, value: action.value })) },
        { type: "click_text", text: "Gå vidare" }
      ]
    };
    return {
      execution: USER_REQUIRED,
      reason: "PERSON_INFORMATION_INCOMPLETE",
      note,
      prefill: actions
    };
  }

  function resolveTeethOrBody(injuries) {
    const entries = (Array.isArray(injuries) ? injuries : []).map(fold).filter(Boolean);
    if (entries.length === 0) return null;
    const isDental = (entry) => /\btand(?:en|er|erna)?\b|\btander\b|\btandskada\b|\bteeth?\b/.test(entry);
    const hasTeeth = entries.some(isDental);
    const hasBody = entries.some((entry) => !isDental(entry));
    if (hasTeeth && hasBody) return "Både kropp och tänder";
    return hasTeeth ? "Tand/tänder" : "Kropp";
  }

  function resolveDomestic(canonical) {
    const resolution = canonicalAdapters?.resolveDomesticEvidence?.({
      category: canonical?.meta?.category,
      country: canonical?.incident?.country,
      abroad: canonical?.incident?.abroad
    });
    return resolution?.status === AUTO ? resolution.value : null;
  }

  function resolveDuringSport(canonical) {
    const context = fold(canonical?.incident?.context);
    if (/(?:pa vag|till fran).*(?:idrott|sport|traning|gym)|(?:idrott|sport|traning|gym).*(?:pa vag|till fran)/.test(context)) {
      return null;
    }
    if (/(?:under|vid|i samband med).*(?:idrott|sport|traning|match|tavling|gym)|(?:idrott|sport|traning|match|tavling|gym).*(?:under|vid|i samband med)/.test(context)) {
      return "Ja";
    }
    const description = fold(canonical?.incident?.description);
    if (/inte.*(?:idrott|sport)|ej.*(?:idrott|sport)/.test(`${context} ${description}`)) return "Nej";
    if (/fritid|ovrig tid/.test(context) && description && !/idrott|sport|traning|match|tavling/.test(description)) {
      return "Nej";
    }
    // Sport metadata may be present on a case even when the incident did not
    // happen during the activity. The incident context must carry the timing
    // semantics; metadata alone is not proof.
    return null;
  }

  function parseWeeks(value) {
    const text = fold(value);
    const numeric = text.match(/\b(\d{1,2})\s*(?:veck|v\b)/);
    if (numeric) return Number(numeric[1]);
    const words = {
      en: 1, ett: 1, tva: 2, tre: 3, fyra: 4, fem: 5, sex: 6,
      sju: 7, atta: 8, nio: 9, tio: 10, elva: 11, tolv: 12
    };
    const word = text.match(/\b(en|ett|tva|tre|fyra|fem|sex|sju|atta|nio|tio|elva|tolv)\s+veck/);
    return word ? words[word[1]] : null;
  }

  function resolvePlaster(canonical) {
    const explicitWeeks = parseWeeks(canonical?.incident?.gipsWeeks);
    const additionalInfo = canonical?.incident?.customerAdditionalInfo;
    const describedWeeks = /\bgips\b/.test(fold(additionalInfo)) ? parseWeeks(additionalInfo) : null;
    const performed = Array.isArray(canonical?.treatments?.performed) ? canonical.treatments.performed : [];
    const plasterTreatments = performed.filter((item) => /gips/.test(fold(item?.type)));
    const hasPlasterTreatment = plasterTreatments.length > 0;
    const treatmentWeeks = plasterTreatments.map((item) => {
      const from = normalizeIncidentDate(item?.dateFrom || item?.date);
      const to = normalizeIncidentDate(item?.dateTo);
      if (!from || !to || to < from) return null;
      const dayMs = 24 * 60 * 60 * 1000;
      const inclusiveDays = Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / dayMs) + 1;
      return inclusiveDays > 0 ? Math.ceil(inclusiveDays / 7) : null;
    }).find((value) => value !== null) || null;
    const explicit = canonical?.incident?.gipsed;
    const secondaryEvidence = explicitWeeks !== null || describedWeeks !== null || hasPlasterTreatment;
    if (explicit === true) {
      return { hasPlaster: true, weeks: explicitWeeks || describedWeeks || null, conflict: false };
    }
    if (explicit === false) {
      return { hasPlaster: false, weeks: null, conflict: secondaryEvidence };
    }
    // CRM normally represents plaster under performed treatments rather than through the
    // optional incident QA field. A recorded plaster treatment is therefore the primary fallback.
    if (hasPlasterTreatment) {
      return { hasPlaster: true, weeks: explicitWeeks || describedWeeks || treatmentWeeks, conflict: false };
    }
    if (explicitWeeks !== null) return { hasPlaster: true, weeks: explicitWeeks, conflict: false };
    return { hasPlaster: null, weeks: null, conflict: describedWeeks !== null };
  }

  function resolveExpenses(canonical) {
    if (!Array.isArray(canonical?.expenses)) return { hasExpenses: null, malformed: false };
    const sourceStatus = compact(canonical?.expensesMeta?.sourceStatus).toUpperCase();
    if (canonical.expenses.length === 0) {
      return sourceStatus === "EXPLICIT_NONE"
        ? { hasExpenses: false, malformed: false }
        : { hasExpenses: null, malformed: sourceStatus === "UNRECOGNIZED" };
    }
    const meaningful = canonical.expenses.some((expense) => {
      if (!expense || typeof expense !== "object") return false;
      const amount = Number(expense.amount);
      return Boolean(
        compact(expense.type) ||
        (Number.isFinite(amount) && amount > 0) ||
        normalizeIncidentDate(expense.date)
      );
    });
    return meaningful
      ? { hasExpenses: true, malformed: false }
      : { hasExpenses: null, malformed: true };
  }

  function normalizeMunicipality(value) {
    return compact(value).replace(/\s*\((?:kommun|stad)\)\s*$/i, "").trim();
  }

  function resolveSchool(canonical) {
    const school = canonical?.incident?.school || {};
    const address = school?.address && typeof school.address === "object" ? school.address : {};
    const street = compact(school.streetAddress || address.streetAddress || address.street);
    const zip = compact(school.postalCode || address.postalCode).replace(/\s+/g, "");
    const city = compact(school.city || address.city || address.locality);
    return {
      name: compact(school.name),
      municipality: normalizeMunicipality(school.municipality || school.policyholder),
      street,
      zip,
      city
    };
  }

  function getEarliestCareDate(canonical) {
    const dates = [];
    for (const provider of Array.isArray(canonical?.care?.providers) ? canonical.care.providers : []) {
      for (const visit of Array.isArray(provider?.visits) ? provider.visits : []) {
        const date = normalizeIncidentDate(visit?.date || visit?.dateFrom);
        if (date) dates.push(date);
      }
    }
    dates.sort();
    return dates[0] || null;
  }

  function resolvePreviousInjury(canonical, incidentDate) {
    const explicit = canonical?.incident?.previousInjuryHad;
    if (!incidentDate) {
      return typeof explicit === "boolean"
        ? { hadPrevious: explicit, source: "EXPLICIT_PREVIOUS_INJURY", firstCareDate: null, conflict: false }
        : { hadPrevious: null, source: "INCIDENT_DATE_MISSING", firstCareDate: null, conflict: false };
    }

    const firstCareDate = getEarliestCareDate(canonical);
    if (explicit === false && firstCareDate && firstCareDate < incidentDate) {
      return {
        hadPrevious: null,
        source: "SOURCE_CONFLICT",
        firstCareDate,
        conflict: true
      };
    }
    if (typeof explicit === "boolean") {
      return {
        hadPrevious: explicit,
        source: "EXPLICIT_PREVIOUS_INJURY",
        firstCareDate,
        conflict: false
      };
    }
    if (!firstCareDate) {
      return { hadPrevious: null, source: "FIRST_CARE_DATE_MISSING", firstCareDate: null, conflict: false };
    }
    return {
      hadPrevious: firstCareDate < incidentDate,
      source: "FIRST_CARE_DATE_VS_INCIDENT_DATE",
      firstCareDate,
      conflict: false
    };
  }

  function buildManualSourceContext(canonical, {
    includeInjuries = true,
    includeConsequences = false,
    includeDescription = false,
    includeIncidentContext = false,
    includeIncidentPlace = false,
    includeIncidentDate = false,
    includeIncidentTime = false,
    includeIncidentDateTime = false,
    includeSportTypeOnly = false,
    includeDomestic = false,
    includeResidualIssues = false,
    includeDoctorCare = false,
    includeDentistCare = false,
    includeFirstCareDate = false,
    includeProtectorInsurance = false,
    includeOtherInsurance = false,
    includeAssociationEvidence = false,
    includeExpenses = false,
    includeSchool = false,
    includeSchoolEducation = false,
    includeSchoolPolicyholder = false,
    includeSchoolTransport = false,
    includeVehicle = false,
    includeTreatment = false,
    includePlasterEvidence = false,
    includePreviousInjury = false
  } = {}) {
    const sections = [];
    const addSection = (label, rawValues) => {
      const values = (Array.isArray(rawValues) ? rawValues : [rawValues])
        .map(compact)
        .filter(Boolean);
      if (values.length > 0) sections.push({ label, values: [...new Set(values)] });
    };
    const isTechnicalToken = (value) => /^[A-Z0-9]+(?:_[A-Z0-9]+)+$/.test(compact(value)) || /^[a-z0-9]+(?:_[a-z0-9]+)+$/.test(compact(value));
    const stripInsurerPrefix = (value, insurer) => {
      const text = compact(value);
      const prefix = compact(insurer);
      if (!prefix) return text;
      const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return text.replace(new RegExp(`^${escapedPrefix}\\s*[-–—:]\\s*`, "i"), "").trim();
    };
    const formatCareRows = (predicate) => {
      const providers = Array.isArray(canonical?.care?.providers) ? canonical.care.providers : [];
      return providers.filter(predicate).map((provider) => {
        const dates = (Array.isArray(provider?.visits) ? provider.visits : [])
          .flatMap((visit) => [visit?.date, visit?.dateFrom && visit?.dateTo ? `${visit.dateFrom}–${visit.dateTo}` : visit?.dateFrom])
          .filter(Boolean);
        return [provider?.providerType, provider?.providerName, dates.join(", ")].filter(Boolean).join(" – ");
      });
    };
    const injuries = (Array.isArray(canonical?.injuries?.bodyInjuries) ? canonical.injuries.bodyInjuries : [])
      .map(compact)
      .filter(Boolean);
    if (includeInjuries && injuries.length > 0) addSection("Kroppsskador", injuries);

    if (includeConsequences) {
      const injuryKeys = new Set(injuries.map(fold));
      const sourceTexts = (Array.isArray(canonical?.injuries?.consequenceSourceTexts)
        ? canonical.injuries.consequenceSourceTexts
        : [])
        .map(compact)
        .filter((value) => value && !injuryKeys.has(fold(value)));
      if (sourceTexts.length > 0) {
        const uniqueDetails = [...new Set(sourceTexts)];
        let injurySection = sections.find((section) => section?.label === "Kroppsskador");
        if (!injurySection) {
          injurySection = { label: "Kroppsskador", values: [] };
          sections.push(injurySection);
        }
        injurySection.detailValues = uniqueDetails;
      } else {
        const consequences = (Array.isArray(canonical?.injuries?.consequencesEvidence)
          ? canonical.injuries.consequencesEvidence
          : [])
          .map(compact)
          .filter(Boolean);
        if (consequences.length > 0) addSection("Skadetyp/detalj", consequences);
      }
    }

    if (includeIncidentContext) {
      addSection("Händelsekontext", canonical?.incident?.context);
    }

    if (includeDescription) {
      const description = compact(canonical?.incident?.description);
      if (description) addSection("Händelsebeskrivning", description);
    }

    if (includeIncidentPlace) {
      addSection("Plats", canonical?.incident?.place);
    }

    if (includeIncidentDateTime) {
      const dateTime = [canonical?.incident?.date, canonical?.incident?.time].map(compact).filter(Boolean).join(" ");
      addSection("Datum och tid", dateTime);
    }

    if (includeIncidentDate) {
      addSection("Skadedatum", canonical?.incident?.date);
    }

    if (includeIncidentTime) {
      addSection("Tid", canonical?.incident?.time);
    }

    if (includeSportTypeOnly) {
      addSection("Idrott", canonical?.incident?.sport?.sportType);
    }

    if (includeDomestic) {
      addSection("Ärendekategori", canonical?.meta?.category);
      addSection("Land", canonical?.incident?.country);
      if (typeof canonical?.incident?.abroad === "boolean") {
        addSection("Utomlands", canonical.incident.abroad ? "Ja" : "Nej");
      }
    }

    if (includeResidualIssues) {
      addSection("Kvarstående besvär", canonical?.injuries?.residualIssues || []);
    }

    if (includeDoctorCare) {
      addSection("Vårdkontakter", formatCareRows((provider) => !isDentistProvider(provider)));
    }

    if (includeDentistCare) {
      addSection("Tandvård", formatCareRows((provider) => isDentistProvider(provider)));
    }

    if (includeFirstCareDate) {
      const firstCareDate = getEarliestCareDate(canonical);
      addSection("Första vårddatum", firstCareDate);
    }

    if (includeProtectorInsurance) {
      const matter = canonical?.meta?.insuranceMatter || {};
      const protectorCards = (Array.isArray(matter.cards) ? matter.cards : [])
        .filter((card) => /\bprotector\b/.test(fold([card?.insurer, card?.displayName].filter(Boolean).join(" "))))
        .map((card) => card?.product || stripInsurerPrefix(card?.displayName, card?.insurer));
      const fallbackEntries = (Array.isArray(matter.entries) ? matter.entries : [])
        .filter((entry) => /kommunforsakring|skolforsakring|foretagsforsakring|privatforsakring|licensforsakring/.test(fold(entry?.displayName)))
        .map((entry) => entry?.displayName);
      addSection("Protector-försäkring", protectorCards.length > 0 ? protectorCards : fallbackEntries);
    }

    if (includeOtherInsurance) {
      const matter = canonical?.meta?.insuranceMatter || {};
      const explicitOther = canonical?.otherAccidentInsurance || {};
      const explicitRows = [
        [explicitOther.insurer, explicitOther.type].filter(Boolean).join(" – ")
      ].filter(Boolean);
      const otherCards = (Array.isArray(matter.cards) ? matter.cards : [])
        .filter((card) => !/\bprotector\b/.test(fold([card?.insurer, card?.displayName].filter(Boolean).join(" "))))
        .map((card) => [card?.insurer, card?.product || stripInsurerPrefix(card?.displayName, card?.insurer)].filter(Boolean).join(" – "));
      addSection("Övrig olycksfallsförsäkring", otherCards.length > 0 ? otherCards : explicitRows);
    }

    if (includeAssociationEvidence) {
      const matter = canonical?.meta?.insuranceMatter || {};
      const names = [
        matter?.displayName,
        ...(Array.isArray(matter?.displayNames) ? matter.displayNames : []),
        ...(Array.isArray(matter?.entries) ? matter.entries.map((entry) => entry?.displayName) : [])
      ].map(compact).filter(Boolean);
      addSection("Försäkrings-/avtalsnamn", names);
    }

    if (includeExpenses) {
      const expenses = (Array.isArray(canonical?.expenses) ? canonical.expenses : []).map((expense) =>
        [
          expense?.type || expense?.expenseType,
          Number.isFinite(Number(expense?.amount)) ? `${Number(expense.amount)} kr` : expense?.amount,
          expense?.date,
          typeof expense?.hasReceipt === "boolean" ? `Kvitto: ${expense.hasReceipt ? "Ja" : "Nej"}` : null
        ].filter((value) => value !== null && value !== undefined && value !== "").join(" – ")
      );
      addSection("Utgifter", expenses);
    }

    if (includeSchool) {
      const school = canonical?.incident?.school || {};
      addSection("Skola", school.name);
      addSection("Kommun", school.municipality);
      addSection("Gatuadress", school.streetAddress || school?.address?.streetAddress || school?.address?.street);
      addSection("Postnummer", school.postalCode || school?.address?.postalCode);
      addSection("Ort", school.city || school?.address?.city || school?.address?.locality);
    }

    if (includeSchoolEducation) {
      addSection("Utbildningsnivå", canonical?.incident?.school?.educationLevel);
    }

    if (includeSchoolPolicyholder) {
      addSection("Försäkringstagare", canonical?.incident?.school?.policyholder);
    }

    if (includeSchoolTransport && typeof canonical?.incident?.schoolTransportOrdered === "boolean") {
      addSection("Ordinerad skolskjuts", canonical.incident.schoolTransportOrdered ? "Ja" : "Nej");
    }

    if (includeVehicle) {
      const vehicle = canonical?.vehicle || {};
      const tagLabels = {
        DRIVER: "Förare",
        PASSENGER: "Passagerare",
        KNOWN_PERSON_OWNS_VEHICLE: "Fordonet ägs av känd person",
        MOPED_CLASS_1: "Moped klass 1"
      };
      const readableType = compact(vehicle.crmType) && !isTechnicalToken(vehicle.crmType) ? vehicle.crmType : null;
      addSection("Fordonstyp", readableType);
      addSection("Registreringsnummer", vehicle.registrationNumber);
      if (typeof vehicle.involved === "boolean") addSection("Fordon inblandat", vehicle.involved ? "Ja" : "Nej");
      addSection("Fordonsdetaljer", (Array.isArray(vehicle.tags) ? vehicle.tags : []).map((tag) => tagLabels[tag]).filter(Boolean));
    }

    if (includeTreatment) {
      const planned = canonical?.treatments?.planned || {};
      const statusLabels = {
        customer_says_no_more: "Ingen ytterligare behandling planeras"
      };
      const rawStatus = compact(planned.status);
      const plannedStatus = statusLabels[rawStatus] || (!isTechnicalToken(rawStatus) ? rawStatus : null);
      addSection("Behandlingsstatus", plannedStatus);
      addSection("Planerad behandling", planned.details);
      addSection("Planerad uppföljning", planned.followUpDate);
    }

    if (includePlasterEvidence) {
      if (typeof canonical?.incident?.gipsed === "boolean") {
        addSection("Gips enligt CRM", canonical.incident.gipsed ? "Ja" : "Nej");
      }
      addSection("Gipsbehandlingens längd", canonical?.incident?.gipsWeeks);
      const additionalInfo = compact(canonical?.incident?.customerAdditionalInfo);
      if (/\bgips\b/.test(fold(additionalInfo))) addSection("Kunduppgift om gips", additionalInfo);
      const plasterTreatments = (Array.isArray(canonical?.treatments?.performed) ? canonical.treatments.performed : [])
        .filter((item) => /gips/.test(fold(item?.type)))
        .map((item) => [item?.type, item?.date || (item?.dateFrom && item?.dateTo ? `${item.dateFrom}–${item.dateTo}` : item?.dateFrom)].filter(Boolean).join(" – "));
      addSection("Registrerad gipsbehandling", plasterTreatments);
    }

    if (includePreviousInjury) {
      addSection("Skadedatum", canonical?.incident?.date);
      if (typeof canonical?.incident?.previousInjuryHad === "boolean") {
        addSection("Tidigare skada enligt CRM", canonical.incident.previousInjuryHad ? "Ja" : "Nej");
      }
      addSection("Tidigare skadedatum", canonical?.incident?.previousInjuryDate);
    }

    return sections.length > 0 ? { title: "Underlag från CRM", sections } : null;
  }

  function buildInjuryDecisionContext(canonical, { includePlace = false } = {}) {
    return buildManualSourceContext(canonical, {
      includeInjuries: true,
      includeConsequences: true,
      includeDescription: true,
      includeIncidentPlace: includePlace
    });
  }

  function resolveDoctorCare(canonical, incidentDate) {
    const providers = Array.isArray(canonical?.care?.providers) ? canonical.care.providers : [];
    const visits = [];
    let hasAmbiguousProviderEvidence = false;
    let rejectedBeforeIncident = false;
    for (const provider of providers) {
      if (isDentistProvider(provider)) continue;
      const providerTypeText = fold(provider?.providerType);
      const providerContextText = fold([
        provider?.providerName,
        ...(Array.isArray(provider?.visits) ? provider.visits.map((visit) => visit?.department) : [])
      ].filter(Boolean).join(" "));
      const explicitlyNonDoctorType = /fysioterapeut|sjukgymnast|rehab|naprapat|kiropraktor|arbetsterapeut/.test(providerTypeText);
      const clearlyDoctorType = /akutmottag|narakut|sjukhus|vardcentral|lakare|ortopedi/.test(providerTypeText);
      const clearlyDoctorContext = !explicitlyNonDoctorType && /akutmottag|narakut|sjukhus|vardcentral|lakare|ortopedi/.test(providerContextText);
      // Claims@Net's care branch explicitly offers SCHOOL_NURSE after this
      // yes/no question. A dated school-nurse/elevhälsa visit must therefore
      // enter the branch even though the provider is not literally a doctor;
      // otherwise the explicit Skolsköterska mapping below is unreachable.
      const clearlySchoolNurseContext = /skolskoters|elevhalsa|skolhalsovard|school nurse/.test(
        `${providerTypeText} ${providerContextText}`
      );
      const clearlyCareBranch = clearlyDoctorType || clearlyDoctorContext || clearlySchoolNurseContext;
      if (!clearlyCareBranch && (providerTypeText || providerContextText)) hasAmbiguousProviderEvidence = true;
      if (!clearlyCareBranch) continue;
      for (const visit of Array.isArray(provider?.visits) ? provider.visits : []) {
        const date = normalizeIncidentDate(visit?.date || visit?.dateFrom);
        if (!date) continue;
        if (incidentDate && date < incidentDate) {
          rejectedBeforeIncident = true;
          continue;
        }
        visits.push({ date, provider, visit });
      }
    }
    visits.sort((a, b) => a.date.localeCompare(b.date));
    const firstVisit = visits[0] || null;
    const explicit = canonical?.incident?.hasDoctorVisit;
    const conflict = explicit === false && Boolean(firstVisit);
    const hasDoctor = conflict
      ? null
      : explicit === true
        ? true
        : explicit === false
          ? false
          : firstVisit
            ? true
            : null;
    return { hasDoctor, firstVisit, rejectedBeforeIncident, hasAmbiguousProviderEvidence, conflict };
  }

  function isDentistProvider(provider) {
    const text = fold([
      provider?.providerType,
      provider?.providerName,
      ...(Array.isArray(provider?.visits) ? provider.visits.map((visit) => visit?.department) : [])
    ].filter(Boolean).join(" "));
    return /tandlak|tandvard|folktand|dentist|dental/.test(text);
  }

  function resolveDentistCare(canonical) {
    const candidates = [];
    for (const provider of Array.isArray(canonical?.care?.providers) ? canonical.care.providers : []) {
      if (!isDentistProvider(provider)) continue;
      const visits = Array.isArray(provider?.visits) ? provider.visits : [];
      if (visits.length === 0) candidates.push({ date: null, provider, visit: null });
      for (const visit of visits) {
        candidates.push({ date: normalizeIncidentDate(visit?.date || visit?.dateFrom), provider, visit });
      }
    }
    candidates.sort((left, right) => String(left.date || "9999-99-99").localeCompare(String(right.date || "9999-99-99")));
    const firstVisit = candidates[0] || null;
    return { hasDentist: firstVisit ? true : null, firstVisit };
  }

  function resolveMedicalInstitutionType(firstVisit) {
    if (!firstVisit) return null;
    const text = fold([
      firstVisit.provider?.providerType,
      firstVisit.visit?.department,
      firstVisit.provider?.providerName
    ].filter(Boolean).join(" "));
    if (/skolskoters|elevhalsa|skolhalsovard|school nurse/.test(text)) return "Skolsköterska";
    if (/e vard|digital|video|chatt|online/.test(text)) return "E-vård";
    if (/akut|sjukhus|vardcentral|lakare|ortopedi/.test(text)) {
      return "Sjukhus/vårdcentral";
    }
    return null;
  }

  function resolveTreatmentFinished(canonical) {
    const planned = canonical?.treatments?.planned || {};
    const status = fold(planned.status);
    if (/customer says no more|kund.*inga fler|inga fler|avslutad/.test(status)) return "Ja";
    if (/planerad|scheduled|planned|ongoing|pagaende/.test(status) || compact(planned.details) || compact(planned.followUpDate)) {
      return "Nej";
    }
    return null;
  }

  function resolveInvalidity(canonical) {
    const resolved = canonicalAdapters?.resolveResidualIssues?.(canonical);
    return {
      value: resolved?.value || null,
      conflict: resolved?.conflict === true,
      status: resolved?.status || "UNKNOWN",
      reason: resolved?.reason || "RESIDUAL_ADAPTER_UNAVAILABLE"
    };
  }

  function normalizeOtherInsuranceCompany(value) {
    const resolution = insurerCrosswalk?.resolveInsurer?.(value);
    return resolution?.status === AUTO ? resolution.protectorValue : null;
  }

  function resolveOtherInsurance(canonical) {
    const explicit = canonical?.otherAccidentInsurance || {};
    const explicitCompany = normalizeOtherInsuranceCompany(explicit.insurer);
    const explicitEvidence = [explicit.insurer, explicit.type, explicit.claimNumber].some((value) => compact(value));
    if (explicit.hasOther === false) return { hasOther: false, company: null, source: "explicit_false" };
    if (explicit.hasOther === true || explicitEvidence) {
      return { hasOther: true, company: explicitCompany, source: "otherAccidentInsurance" };
    }

    const matter = canonical?.meta?.insuranceMatter || {};
    const cards = Array.isArray(matter.cards) ? matter.cards : [];
    const otherCard = cards.find((card) => {
      const text = fold([card?.insurer, card?.displayName, card?.product].filter(Boolean).join(" "));
      return text && !/protector/.test(text);
    });
    if (otherCard) {
      return {
        hasOther: true,
        company: normalizeOtherInsuranceCompany(otherCard.insurer || otherCard.displayName),
        source: "insuranceMatter.cards"
      };
    }

    const sourceStatus = compact(matter.sourceStatus);
    if (sourceStatus === "EXPLICIT_NONE") {
      return { hasOther: false, company: null, source: "insuranceMatter.explicit_none" };
    }
    if (sourceStatus !== "LOADED") return { hasOther: null, company: null, source: null };

    const entries = Array.isArray(matter.entries) ? matter.entries : [];
    const trustedCurrentEntry = entries.some((entry) => {
      const text = fold(entry?.displayName);
      return /^kommunforsakring\b|^skolforsakring\b/.test(text);
    });
    const ambiguousOrOtherEntry = entries.some((entry) => {
      const text = fold([entry?.displayName, entry?.statusText, entry?.stateTitle].filter(Boolean).join(" "));
      if (!text) return false;
      if (/^kommunforsakring\b|^skolforsakring\b/.test(fold(entry?.displayName))) return false;
      if (/kunden har inte forsakringen/.test(text)) return false;
      return true;
    });
    const trustedProtectorCard = cards.some((card) => {
      const text = fold([card?.insurer, card?.displayName, card?.product].filter(Boolean).join(" "));
      return /protector/.test(text);
    });

    if (!ambiguousOrOtherEntry && (trustedCurrentEntry || trustedProtectorCard)) {
      return { hasOther: false, company: null, source: "insuranceMatter.loaded_no_other" };
    }
    return { hasOther: null, company: null, source: null };
  }

  function resolveHasAttachment() {
    // Insurello's Protector flow always includes a manually uploaded fullmakt
    // and försättsblad. The portal yes/no question is therefore a business
    // constant, independent of whether CRM happened to expose other files.
    return true;
  }

  const PROTECTOR_ASSOCIATIONS = Object.freeze([
    ["802004-7737", "Adoptionscentrum"],
    ["556662-3210", "AHF HockeyAllsvenskan AB"],
    ["852000-3693", "Barnen Framförallt (Frivillig Barnförsäkring)"],
    ["897000-7459", "Barnens Vänner (Obligatorisk Barnförsäkring)"],
    ["802002-3605", "Neuroförbundet"],
    ["556908-9203", "Reitan Convenience Sweden AB"],
    ["802003-0246", "Skattebetalarnas Förening"],
    ["556820-0926", "Småföretagarna"],
    ["556092-9936", "Svenska Byggingenjörers Riksförbund"],
    ["802007-6512", "Svenska Diabetesförbundet"],
    ["898200-2902", "Svenska Fallskärmsförbundet"],
    ["802005-4246", "Sveriges Tandteknikerförbund"],
    ["556187-0410", "Sydskånes avfallsaktiebolag"],
    ["556474-8803", "Sysav Industri"]
  ]);

  function resolveAssociation(canonical) {
    const candidates = [
      canonical?.meta?.insuranceMatter?.displayName,
      ...(Array.isArray(canonical?.meta?.insuranceMatter?.displayNames) ? canonical.meta.insuranceMatter.displayNames : []),
      ...(Array.isArray(canonical?.meta?.insuranceMatter?.entries) ? canonical.meta.insuranceMatter.entries.map((entry) => entry?.displayName) : [])
    ].map(fold).filter(Boolean);
    const matches = PROTECTOR_ASSOCIATIONS.filter(([, label]) => candidates.some((candidate) => candidate === fold(label)));
    return matches.length === 1 ? { value: matches[0][0], label: matches[0][1] } : null;
  }

  function buildProtectorPlan(canonical, config) {
    const injuries = canonical?.injuries?.bodyInjuries || [];
    const insuranceType = resolveInsuranceType(canonical);
    const location = resolveLocation(canonical, insuranceType);
    const bodyParts = resolveBodyParts(injuries, canonical?.incident?.description);
    const cause = resolveCause(canonical);
    const consequences = resolveConsequences(injuries, canonical?.injuries?.consequencesEvidence);
    const everyBodyHeadingClassified = injuries.length > 0 && injuries.every((injury) =>
      resolveConsequences([injury], []).length > 0
    );
    const consequencesComplete = canonical?.injuries?.consequencesEvidenceComplete === true && everyBodyHeadingClassified;
    const timeOfDay = resolveTimeOfDay(canonical?.incident?.time);
    const incidentDate = normalizeIncidentDate(canonical?.incident?.date);
    const teethOrBody = resolveTeethOrBody(injuries);
    const domestic = resolveDomestic(canonical);
    const duringSport = resolveDuringSport(canonical);
    const sportResolution = sportCrosswalk?.resolveSportType
      ? sportCrosswalk.resolveSportType(canonical?.incident?.sport?.sportType)
      : { status: "UNKNOWN", source: compact(canonical?.incident?.sport?.sportType) || null };
    const vehicleRegistration = resolveVehicleRegistration(canonical);
    const vehicleMotorcycleChoice = resolveVehicleMotorcycleChoice(canonical);
    const personInVehicleChoice = resolvePersonInVehicleChoice(canonical);
    const previousInjuryDate = normalizeIncidentDate(canonical?.incident?.previousInjuryDate);
    const previousInjury = resolvePreviousInjury(canonical, incidentDate);
    const elementarySchoolChoice = resolveElementarySchoolChoice(canonical);
    const plaster = resolvePlaster(canonical);
    const plasterChoice = plaster.conflict ? null : booleanChoice(plaster.hasPlaster);
    const expenseResolution = resolveExpenses(canonical);
    const doctorCare = resolveDoctorCare(canonical, incidentDate);
    const dentistCare = resolveDentistCare(canonical);
    const medicalInstitutionType = resolveMedicalInstitutionType(doctorCare.firstVisit);
    const treatmentFinished = resolveTreatmentFinished(canonical);
    const invalidity = resolveInvalidity(canonical);
    const autoPrivacyConsent = config?.PROTECTOR_BETA_AUTO_PRIVACY === true;
    const otherInsurance = resolveOtherInsurance(canonical);
    const hasAttachment = resolveHasAttachment(canonical);
    const association = resolveAssociation(canonical);
    const transportChoice = canonical?.incident?.schoolTransportOrdered === true ? "Ja" : null;
    const claimantName = splitName(canonical?.claimant?.name);
    const bank = config?.INSURELLO_BANK_ACCOUNT || {};
    const contact = config?.INSURELLO_CONTACT || {};
    const school = resolveSchool(canonical);
    const personNumber = formatPersonNumber(canonical?.claimant?.personNumber);
    const claimReporterResolution = resolveClaimReporterRole(canonical);
    const reporter = claimReporterResolution.reporter || resolveReporter(canonical);
    const reporterRelation = claimReporterResolution.relation;
    const reporterName = splitName(reporter.name);
    const accountHolder = config?.INSURELLO_ACCOUNT_HOLDER || {};

    const steps = {
      "/swe/sv": clickStep("Person"),
      "/swe/sv/captcha": manualStep("CAPTCHA", "Lös CAPTCHA manuellt. Flödet fortsätter automatiskt."),
      "/swe/sv/5/category": clickStep("Olycka"),
      "/swe/sv/5/accident/claim-reporter-role": claimReporterResolution.role
        ? clickStep(claimReporterResolution.role)
        : manualStep("CLAIM_REPORTER_ROLE", "Välj vem anmälan gäller."),
      "/swe/sv/5/accident/claim-reporter": reporterRelation
        ? clickStep(reporterRelation)
        : manualStep("CLAIM_REPORTER_RELATION", "Välj vem som anmäler."),
      "/swe/sv/5/accident/insurance-type": insuranceType
        ? clickStep(insuranceType)
        : manualStep("INSURANCE_TYPE"),
      "/swe/sv/5/accident/privacy": autoPrivacyConsent
        ? { execution: AUTO, actions: [
            { type: "check_id", id: "acceptedPrivacy" },
            { type: "click_text", text: "Gå vidare" }
          ], note: "Samtycket markeras automatiskt enligt Protector-konfigurationen." }
        : manualStep("PRIVACY_CONSENT", "Läs och godkänn samtycket manuellt."),
      "/swe/sv/5/accident/claim-location": location ? clickStep(location) : manualStep("CLAIM_LOCATION"),
      "/swe/sv/5/accident/claim-date": incidentDate
        ? {
            execution: AUTO,
            actions: [
              { type: "select_date", value: incidentDate },
              { type: "click_text", text: "Gå vidare" }
            ]
          }
        : manualStep("CLAIM_DATE", `Välj skadedatum ${compact(canonical?.incident?.date) || "manuellt"}.`),
      "/swe/sv/5/accident/claim-time-of-day": timeOfDay ? clickStep(timeOfDay) : manualStep("TIME_OF_DAY"),
      "/swe/sv/5/accident/is-vehicle-involved": booleanChoice(canonical?.vehicle?.involved)
        ? clickStep(booleanChoice(canonical.vehicle.involved))
        : manualStep("VEHICLE_INVOLVED"),
      "/swe/sv/5/accident/vehicle-information": vehicleRegistration
        ? {
            execution: AUTO,
            actions: [{
              type: "vehicle_lookup_exact",
              registrationNumber: vehicleRegistration,
              lookupText: "Sök",
              selectText: "Välj",
              continueText: "Gå vidare"
            }],
            note: "Söker via portalens ordinarie fordonsfält och fortsätter endast vid exakt registreringsnummermatchning."
          }
        : manualStep(
            "VEHICLE_REGISTRATION_MISSING",
            "Välj fordon manuellt."
          ),
      "/swe/sv/5/accident/is-vehicle-motorcycle": vehicleMotorcycleChoice
        ? clickStep(vehicleMotorcycleChoice)
        : manualStep(
            "VEHICLE_MOTORCYCLE_AMBIGUOUS",
            "Välj om fordonet ska räknas som motorcykel/moped."
          ),
      "/swe/sv/5/accident/person-in-vehicle": personInVehicleChoice
        ? clickStep(personInVehicleChoice)
        : manualStep(
            "PERSON_IN_VEHICLE_AMBIGUOUS",
            "Välj om den skadade färdades med fordonet."
          ),
      "/swe/sv/5/accident/has-license": manualStep(
        "LICENSE_MAPPING_PENDING",
        "Välj om föraren hade körkort."
      ),
      "/swe/sv/5/accident/has-helmet": manualStep(
        "HELMET_MAPPING_PENDING",
        "Välj om hjälm användes."
      ),
      "/swe/sv/5/accident/happen-domestically": domestic ? clickStep(domestic) : manualStep("DOMESTIC_OR_ABROAD"),
      "/swe/sv/5/accident/during-sport": duringSport ? clickStep(duringSport) : manualStep("DURING_SPORT"),
      "/swe/sv/5/accident/type-of-sport": sportResolution.status === AUTO
        ? {
            execution: AUTO,
            actions: [
              {
                type: "select_exact_id",
                id: "typeOfSport",
                value: sportResolution.protectorValue,
                label: sportResolution.protectorLabel
              },
              { type: "click_text", text: "Gå vidare" }
            ],
            note: `Sport ${sportResolution.source} → ${sportResolution.protectorLabel}.`
          }
        : manualStep(
            sportResolution.status === "AMBIGUOUS" ? "SPORT_TYPE_AMBIGUOUS" : "SPORT_TYPE_UNMAPPED",
            "Välj rätt idrott utifrån CRM-underlaget."
          ),
      "/swe/sv/5/accident/teeth-or-body": teethOrBody
        ? clickStep(teethOrBody)
        : manualStep("TEETH_OR_BODY"),
      "/swe/sv/5/accident/body-parts": bodyParts.execution === AUTO
        ? { execution: AUTO, actions: [
            ...bodyParts.values.map((id) => ({ type: "check_id", id: `checkbox-${id}` })),
            { type: "click_text", text: "Gå vidare" }
          ] }
        : {
            execution: USER_REQUIRED,
            reason: "BODY_PART",
            note: bodyParts.values.length > 0
              ? "Säkra kroppsdelar har markerats. Kontrollera och komplettera den tvetydiga kroppsdelen/sidan manuellt."
              : "Kontrollera kroppsdel och sida manuellt.",
            prefill: bodyParts.values.map((id) => ({ type: "check_id", id: `checkbox-${id}` })),
            manualContext: buildInjuryDecisionContext(canonical)
          },
      "/swe/sv/5/accident/teeth": manualStep(
        "TEETH_MAPPING_PENDING",
        "Välj skadad tand eller tänder manuellt."
      ),
      "/swe/sv/5/accident/claim-cause": cause ? clickStep(cause) : manualStep("CLAIM_CAUSE"),
      "/swe/sv/5/accident/claim-cause-consequences": consequences.length > 0 && consequencesComplete
        ? { execution: AUTO, actions: [
            ...consequences.map((text) => ({ type: "click_text", text })),
            { type: "click_text", text: "Gå vidare" }
        ] }
        : {
            ...manualStep(
              consequencesComplete ? "CLAIM_CONSEQUENCE" : "INJURY_CONSEQUENCE_SOURCE_INCOMPLETE",
              consequencesComplete
                ? undefined
                : "Kontrollera skadeföljderna manuellt."
            ),
            manualContext: buildInjuryDecisionContext(canonical, { includePlace: true })
          },
      "/swe/sv/5/accident/has-plaster-treatment": plasterChoice
        ? clickStep(plasterChoice)
        : manualStep(
            plaster.conflict ? "SOURCE_CONFLICT" : "PLASTER_TREATMENT",
            plaster.conflict
              ? "CRM-uppgifterna om gips motsäger varandra. Välj manuellt."
              : undefined
          ),
      "/swe/sv/5/accident/weeks-of-plaster-treatment": plaster.weeks
        ? { execution: AUTO, actions: [
            { type: "fill_id", id: "weeksOfPlasterTreatment", value: String(plaster.weeks) },
            { type: "click_text", text: "Gå vidare" }
          ] }
        : manualStep("PLASTER_TREATMENT_WEEKS"),
      "/swe/sv/5/accident/previous-injury": booleanChoice(previousInjury.hadPrevious)
        ? clickStep(
            booleanChoice(previousInjury.hadPrevious),
            previousInjury.source === "FIRST_CARE_DATE_VS_INCIDENT_DATE"
              ? `Första vårdbesök ${previousInjury.firstCareDate} jämfört med skadedatum ${incidentDate}.`
              : null
          )
        : manualStep(
            previousInjury.conflict ? "SOURCE_CONFLICT" : "PREVIOUS_INJURY",
            previousInjury.conflict
              ? "CRM säger ingen tidigare skada, men första vårddatum ligger före skadedatum. Kontrollera manuellt."
              : undefined
          ),
      "/swe/sv/5/accident/date-of-previous-injury": previousInjuryDate
        ? {
            execution: AUTO,
            actions: [
              { type: "select_date", value: previousInjuryDate },
              { type: "click_text", text: "Gå vidare" }
            ]
          }
        : manualStep(
            "PREVIOUS_INJURY_DATE_MISSING",
            "Välj datum för den tidigare skadan."
          ),
      "/swe/sv/5/accident/is-doctor-contacted": booleanChoice(doctorCare.hasDoctor)
        ? clickStep(booleanChoice(doctorCare.hasDoctor))
        : manualStep(
            doctorCare.conflict ? "SOURCE_CONFLICT" : "DOCTOR_CONTACTED",
            doctorCare.conflict
              ? "CRM-uppgifterna om läkarvård motsäger varandra. Kontrollera manuellt."
              : doctorCare.hasAmbiguousProviderEvidence
                ? "Välj om läkarvård har uppsökts."
                : undefined
          ),
      "/swe/sv/5/accident/is-dentist-contacted": dentistCare.hasDentist === true
        ? clickStep("Ja")
        : manualStep(
            "DENTIST_CONTACT_SOURCE_MISSING",
            "Välj om tandvård har uppsökts."
          ),
      "/swe/sv/5/accident/date-of-dentist-treatment": dentistCare.firstVisit?.date
        ? {
            execution: AUTO,
            actions: [
              { type: "select_date", value: dentistCare.firstVisit.date },
              { type: "click_text", text: "Gå vidare" }
            ]
          }
        : manualStep(
            "DENTIST_TREATMENT_DATE_MISSING",
            "Välj datum för tandvården."
          ),
      "/swe/sv/5/accident/dentist-information": compact(dentistCare.firstVisit?.provider?.providerName)
        ? {
            execution: AUTO,
            actions: [
              { type: "fill_name", name: "dentist", value: compact(dentistCare.firstVisit.provider.providerName) },
              { type: "click_text", text: "Gå vidare" }
            ]
          }
        : manualStep(
            "DENTIST_INFORMATION_MISSING",
            "Fyll i tandläkare eller vårdgivare."
          ),
      "/swe/sv/5/accident/type-of-medical-institution": medicalInstitutionType
        ? clickStep(medicalInstitutionType)
        : manualStep("MEDICAL_INSTITUTION_TYPE"),
      "/swe/sv/5/accident/date-of-treatment": doctorCare.firstVisit?.date
        ? { execution: AUTO, actions: [
            { type: "select_date", value: doctorCare.firstVisit.date },
            { type: "click_text", text: "Gå vidare" }
          ] }
        : manualStep("DATE_OF_TREATMENT"),
      "/swe/sv/5/accident/medical-institution-information": compact(doctorCare.firstVisit?.provider?.providerName)
        ? { execution: AUTO, actions: [
            { type: "fill_name", name: "medicalInstitution", value: compact(doctorCare.firstVisit.provider.providerName) },
            { type: "click_text", text: "Gå vidare" }
          ] }
        : manualStep("MEDICAL_INSTITUTION_INFORMATION"),
      "/swe/sv/5/accident/finished-treatment": treatmentFinished
        ? clickStep(treatmentFinished)
        : manualStep("FINISHED_TREATMENT"),
      "/swe/sv/5/accident/invalidity": invalidity.value
        ? clickStep(invalidity.value)
        : manualStep(invalidity.conflict ? "SOURCE_CONFLICT" : "INVALIDITY"),
      "/swe/sv/5/accident/has-expenses": booleanChoice(expenseResolution.hasExpenses)
        ? clickStep(booleanChoice(expenseResolution.hasExpenses))
        : manualStep(
            expenseResolution.malformed ? "EXPENSES_MALFORMED" : "EXPENSES",
            expenseResolution.malformed
              ? "Kontrollera kostnaderna manuellt."
              : "Välj om kostnader finns."
          ),
      "/swe/sv/5/accident/need-transport": transportChoice
        ? clickStep(transportChoice)
        : manualStep(
            "TRANSPORT_POLICY_OR_SOURCE_MISSING",
            "Välj om barnet behöver transport till och från skolan."
          ),
      "/swe/sv/5/accident/in-elementary-school": elementarySchoolChoice
        ? clickStep(elementarySchoolChoice)
        : manualStep(
            "ELEMENTARY_SCHOOL_AMBIGUOUS",
            "Välj om barnet går i grundskola."
          ),
      "/swe/sv/5/accident/upload-medical-certificate": manualStep(
        "UPLOAD_MEDICAL_CERTIFICATE",
        "Ladda upp läkarintyg om det finns."
      ),
      "/swe/sv/5/accident/has-other-expenses": manualStep(
        "OTHER_EXPENSES_MAPPING_PENDING",
        "Välj om det finns andra kostnader."
      ),
      "/swe/sv/5/accident/upload-receipt": Array.isArray(canonical?.expenses) && canonical.expenses.length > 0 && canonical.expenses.every((expense) => expense?.hasReceipt === false)
        ? { execution: AUTO, actions: [{ type: "click_text", text: "Gå vidare" }] }
        : manualStep("UPLOAD_RECEIPT", "Ladda upp kvitto om det finns."),
      "/swe/sv/5/accident/has-other-insurance": booleanChoice(otherInsurance.hasOther)
        ? clickStep(booleanChoice(otherInsurance.hasOther))
        : manualStep("OTHER_INSURANCE"),
      "/swe/sv/5/accident/other-insurance-company": otherInsurance.hasOther === true && otherInsurance.company
        ? { execution: AUTO, actions: [
            { type: "select_autocomplete_id", id: "otherInsuranceCompany", value: otherInsurance.company },
            { type: "click_text", text: "Gå vidare" }
          ] }
        : manualStep(
            "OTHER_INSURANCE_COMPANY",
            otherInsurance.hasOther === true
              ? "Välj försäkringsbolag."
              : undefined
          ),
      "/swe/sv/5/accident/has-attachment": clickStep("Ja"),
      "/swe/sv/5/accident/upload-attachment": manualStep(
        "UPLOAD_ATTACHMENT",
        "Ladda upp underlag och gå vidare."
      ),
      "/swe/sv/5/accident/situation-summary": canonical?.incident?.description
        ? { execution: AUTO, actions: [
            { type: "fill_id", id: "claimDescription", value: compact(canonical.incident.description) },
            { type: "click_text", text: "Gå vidare" }
        ] }
        : manualStep("CLAIM_DESCRIPTION"),
      "/swe/sv/5/accident/company-information": manualStep(
        "COMPANY_INFORMATION_MAPPING_PENDING",
        "Fyll i företagsuppgifterna manuellt."
      ),
      "/swe/sv/5/accident/is-municipality": insuranceType === "Kommun-/skolförsäkring"
        ? clickStep("Ja")
        : insuranceType
        ? clickStep("Nej")
        : manualStep("MUNICIPAL_INSURANCE"),
      "/swe/sv/5/accident/school-information": {
        execution: Object.values(school).every(Boolean) ? AUTO : USER_REQUIRED,
        reason: Object.values(school).every(Boolean) ? null : "SCHOOL_INFORMATION_INCOMPLETE",
        note: Object.values(school).every(Boolean)
          ? null
          : Object.values(school).some(Boolean)
            ? "Tillgängliga skoluppgifter har fyllts. Komplettera det som saknas och gå vidare."
            : "Skoluppgifter saknas i CRM. Fyll i uppgifterna manuellt och gå vidare.",
        [Object.values(school).every(Boolean) ? "actions" : "prefill"]: [
          { type: "fill_name", name: "name", value: school.name },
          { type: "select_autocomplete_id", id: "municipality", value: school.municipality },
          { type: "fill_name", name: "street", value: school.street },
          { type: "fill_name", name: "zip", value: school.zip },
          { type: "fill_name", name: "city", value: school.city },
          ...(Object.values(school).every(Boolean) ? [
            { type: "verify_fields", fields: [
              { id: "name", value: school.name },
              { id: "municipality", value: school.municipality },
              { id: "street", value: school.street },
              { id: "zip", value: school.zip },
              { id: "city", value: school.city }
            ] },
            { type: "click_text", text: "Gå vidare" }
          ] : [])
        ].filter((action) => action.type === "click_text" || action.type === "verify_fields" || action.value)
      },
      "/swe/sv/5/accident/association-information": association
        ? {
            execution: AUTO,
            actions: [
              { type: "select_exact_id", id: "selectAssociation", value: association.value, label: association.label },
              { type: "click_text", text: "Gå vidare" }
            ],
            note: `Exakt CRM-förbund → ${association.label}.`
          }
        : manualStep("ASSOCIATION", "Välj förbund eller förening manuellt."),
      "/swe/sv/5/accident/claimant-information": buildInformationStep([
          { type: "fill_id", id: "firstName", value: claimantName.firstName },
          { type: "fill_id", id: "lastName", value: claimantName.lastName },
          { type: "fill_national_identity", id: "nationalIdentity", value: personNumber },
          { type: "fill_id", id: "email", value: compact(contact.email) },
          { type: "fill_id", id: "phone", value: compact(contact.phone) },
          { type: "fill_id", id: "street", value: compact(contact.address) },
          { type: "fill_id", id: "zip", value: compact(contact.postalCode) },
          { type: "fill_id", id: "city", value: compact(contact.city) }
        ], ["firstName", "lastName", "nationalIdentity", "email", "phone", "street", "zip", "city"],
        "Tillgängliga uppgifter har fyllts. Komplettera barnets identitet eller Insurellos kontaktuppgifter och gå vidare manuellt."),
      "/swe/sv/5/accident/reporter-information": buildInformationStep([
          { type: "fill_id", id: "firstName", value: reporterName.firstName },
          { type: "fill_id", id: "lastName", value: reporterName.lastName },
          { type: "fill_national_identity", id: "nationalIdentity", value: formatPersonNumber(reporter.personNumber) },
          { type: "fill_id", id: "email", value: compact(contact.email) },
          { type: "fill_id", id: "phone", value: compact(contact.phone) }
        ], ["firstName", "lastName", "nationalIdentity", "email", "phone"],
        "Tillgängliga uppgifter har fyllts. Komplettera vårdnadshavarens identitet och gå vidare manuellt."),
      "/swe/sv/5/accident/bank-account-information": {
        execution: HARD_STOP,
        reason: bank.clearingNumber && bank.accountNumber ? "READY_FOR_REVIEW" : "BANK_CONFIG_MISSING",
        note: bank.clearingNumber && bank.accountNumber
          ? "Insurellos konto är ifyllt. Kontrollera uppgifterna. Gå inte vidare."
          : "Insurellos clearing- och kontonummer saknas i Protector-konfigurationen. Gå inte vidare.",
        actions: [
          { type: "fill_optional_candidates", selectors: ["#ownerGivenName", "[name='ownerGivenName']"], value: compact(accountHolder.givenName) },
          { type: "fill_optional_candidates", selectors: ["#ownerFamilyName", "[name='ownerFamilyName']"], value: compact(accountHolder.familyName) },
          { type: "fill_id", id: "clearingNumber", value: compact(bank.clearingNumber) },
          { type: "fill_id", id: "accountNumber", value: compact(bank.accountNumber) }
        ].filter((action) => action.value),
        expectedBankName: compact(bank.expectedBankName),
        expectedOwnerGivenName: compact(accountHolder.givenName),
        expectedOwnerFamilyName: compact(accountHolder.familyName)
      },
      "/swe/sv/5/accident/final-summary": manualStep(
        "FINAL_REVIEW_REQUIRED",
        "Granska slutsammanfattningen manuellt. Automation skickar aldrig anmälan."
      ),
      "/swe/sv/5/accident/report-completed": manualStep(
        "REPORT_COMPLETED",
        "Protector visar bekräftelsesidan. Ingen ytterligare automation körs."
      )
    };

    // Manual stops should reduce tab-switching, not create it. Attach the most
    // relevant already-captured CRM evidence to existing USER_REQUIRED steps.
    // This is presentation-only: it never changes AUTO/USER_REQUIRED decisions.
    const manualContextByRoute = {
      "/swe/sv/5/accident/insurance-type": buildManualSourceContext(canonical, { includeInjuries: false, includeProtectorInsurance: true, includeSchoolPolicyholder: true }),
      "/swe/sv/5/accident/claim-location": buildManualSourceContext(canonical, { includeInjuries: false, includeIncidentContext: true, includeDescription: true, includeIncidentPlace: true, includeIncidentDateTime: true }),
      "/swe/sv/5/accident/claim-date": buildManualSourceContext(canonical, { includeInjuries: false, includeIncidentDate: true }),
      "/swe/sv/5/accident/claim-time-of-day": buildManualSourceContext(canonical, { includeInjuries: false, includeIncidentTime: true }),
      "/swe/sv/5/accident/is-vehicle-involved": buildManualSourceContext(canonical, { includeInjuries: false, includeVehicle: true }),
      "/swe/sv/5/accident/vehicle-information": buildManualSourceContext(canonical, { includeInjuries: false, includeVehicle: true }),
      "/swe/sv/5/accident/is-vehicle-motorcycle": buildManualSourceContext(canonical, { includeInjuries: false, includeVehicle: true }),
      "/swe/sv/5/accident/person-in-vehicle": buildManualSourceContext(canonical, { includeInjuries: false, includeVehicle: true }),
      "/swe/sv/5/accident/happen-domestically": buildManualSourceContext(canonical, { includeInjuries: false, includeDomestic: true }),
      "/swe/sv/5/accident/during-sport": buildManualSourceContext(canonical, { includeInjuries: false, includeIncidentContext: true, includeDescription: true }),
      "/swe/sv/5/accident/type-of-sport": buildManualSourceContext(canonical, { includeInjuries: false, includeSportTypeOnly: true }),
      "/swe/sv/5/accident/teeth-or-body": buildManualSourceContext(canonical, { includeConsequences: true }),
      "/swe/sv/5/accident/teeth": buildManualSourceContext(canonical, { includeConsequences: true }),
      "/swe/sv/5/accident/claim-cause": buildInjuryDecisionContext(canonical, { includePlace: true }),
      "/swe/sv/5/accident/has-plaster-treatment": buildManualSourceContext(canonical, { includeInjuries: false, includePlasterEvidence: true }),
      "/swe/sv/5/accident/weeks-of-plaster-treatment": buildManualSourceContext(canonical, { includeInjuries: false, includePlasterEvidence: true }),
      "/swe/sv/5/accident/previous-injury": buildManualSourceContext(canonical, { includeInjuries: false, includePreviousInjury: true, includeFirstCareDate: true }),
      "/swe/sv/5/accident/date-of-previous-injury": buildManualSourceContext(canonical, { includeInjuries: false, includePreviousInjury: true }),
      "/swe/sv/5/accident/is-doctor-contacted": buildManualSourceContext(canonical, { includeInjuries: false, includeDoctorCare: true }),
      "/swe/sv/5/accident/is-dentist-contacted": buildManualSourceContext(canonical, { includeInjuries: false, includeDentistCare: true }),
      "/swe/sv/5/accident/date-of-dentist-treatment": buildManualSourceContext(canonical, { includeInjuries: false, includeDentistCare: true }),
      "/swe/sv/5/accident/dentist-information": buildManualSourceContext(canonical, { includeInjuries: false, includeDentistCare: true }),
      "/swe/sv/5/accident/type-of-medical-institution": buildManualSourceContext(canonical, { includeInjuries: false, includeDoctorCare: true }),
      "/swe/sv/5/accident/date-of-treatment": buildManualSourceContext(canonical, { includeInjuries: false, includeDoctorCare: true }),
      "/swe/sv/5/accident/medical-institution-information": buildManualSourceContext(canonical, { includeInjuries: false, includeDoctorCare: true }),
      "/swe/sv/5/accident/finished-treatment": buildManualSourceContext(canonical, { includeInjuries: false, includeTreatment: true }),
      "/swe/sv/5/accident/invalidity": buildManualSourceContext(canonical, { includeInjuries: false, includeResidualIssues: true }),
      "/swe/sv/5/accident/has-expenses": buildManualSourceContext(canonical, { includeInjuries: false, includeExpenses: true }),
      "/swe/sv/5/accident/upload-receipt": buildManualSourceContext(canonical, { includeInjuries: false, includeExpenses: true }),
      "/swe/sv/5/accident/need-transport": buildManualSourceContext(canonical, { includeInjuries: false, includeSchoolTransport: true }),
      "/swe/sv/5/accident/in-elementary-school": buildManualSourceContext(canonical, { includeInjuries: false, includeSchoolEducation: true }),
      "/swe/sv/5/accident/has-other-insurance": buildManualSourceContext(canonical, { includeInjuries: false, includeOtherInsurance: true }),
      "/swe/sv/5/accident/other-insurance-company": buildManualSourceContext(canonical, { includeInjuries: false, includeOtherInsurance: true }),
      "/swe/sv/5/accident/is-municipality": buildManualSourceContext(canonical, { includeInjuries: false, includeProtectorInsurance: true, includeSchoolPolicyholder: true }),
      "/swe/sv/5/accident/school-information": buildManualSourceContext(canonical, { includeInjuries: false, includeSchool: true }),
      "/swe/sv/5/accident/association-information": buildManualSourceContext(canonical, { includeInjuries: false, includeAssociationEvidence: true })
    };
    for (const [route, context] of Object.entries(manualContextByRoute)) {
      if (steps[route]?.execution === USER_REQUIRED && !steps[route].manualContext && context) {
        steps[route].manualContext = context;
      }
    }

    const diagnosticContracts = {
      "/swe/sv": { canonicalPathsChecked: [], diagnosisHint: "MANUAL_BY_DESIGN" },
      "/swe/sv/captcha": { canonicalPathsChecked: [], diagnosisHint: "MANUAL_BY_DESIGN" },
      "/swe/sv/5/category": { canonicalPathsChecked: [], diagnosisHint: "MANUAL_BY_DESIGN" },
      "/swe/sv/5/accident/claim-reporter-role": {
        canonicalPathsChecked: ["customer.name", "customer.personNumber", "claimant.name", "claimant.personNumber"],
        diagnosisHint: claimReporterResolution.role ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { comparison: claimReporterResolution.comparison }
      },
      "/swe/sv/5/accident/claim-reporter": {
        canonicalPathsChecked: ["customer.name", "customer.personNumber", "claimant.name", "claimant.personNumber"],
        diagnosisHint: reporterRelation ? "PLAN_MAPPING_MISSING" : "MANUAL_BY_DESIGN"
      },
      "/swe/sv/5/accident/insurance-type": {
        canonicalPathsChecked: ["meta.insuranceMatter", "employment.employer", "incident.school.policyholder"],
        diagnosisHint: insuranceType ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/privacy": { canonicalPathsChecked: [], diagnosisHint: "MANUAL_BY_DESIGN" },
      "/swe/sv/5/accident/claim-location": {
        canonicalPathsChecked: ["incident.context", "meta.insuranceMatter"],
        diagnosisHint: location ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/claim-date": {
        canonicalPathsChecked: ["incident.date"],
        diagnosisHint: incidentDate ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/claim-time-of-day": {
        canonicalPathsChecked: ["incident.time"],
        diagnosisHint: timeOfDay ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/is-vehicle-involved": {
        canonicalPathsChecked: ["vehicle.involved"],
        diagnosisHint: "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/vehicle-information": {
        canonicalPathsChecked: ["vehicle.registrationNumber"],
        diagnosisHint: vehicleRegistration ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { normalizedRegistrationPresent: Boolean(vehicleRegistration) }
      },
      "/swe/sv/5/accident/is-vehicle-motorcycle": {
        canonicalPathsChecked: ["vehicle.isMotorcycleOrMoped", "vehicle.type", "vehicle.tags"],
        diagnosisHint: vehicleMotorcycleChoice ? "PLAN_MAPPING_MISSING" : "AMBIGUOUS_BY_POLICY",
        evidence: { resolvedChoice: vehicleMotorcycleChoice }
      },
      "/swe/sv/5/accident/person-in-vehicle": {
        canonicalPathsChecked: ["vehicle.personInVehicle", "vehicle.tags"],
        diagnosisHint: personInVehicleChoice ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { resolvedChoice: personInVehicleChoice }
      },
      "/swe/sv/5/accident/date-of-previous-injury": {
        canonicalPathsChecked: ["incident.previousInjuryDate"],
        diagnosisHint: previousInjuryDate ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { explicitDatePresent: Boolean(previousInjuryDate) }
      },
      "/swe/sv/5/accident/happen-domestically": {
        canonicalPathsChecked: ["meta.category", "incident.country", "incident.abroad"],
        diagnosisHint: domestic ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/during-sport": {
        canonicalPathsChecked: ["incident.sport.sportType", "incident.context", "incident.description"],
        diagnosisHint: duringSport ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/type-of-sport": {
        canonicalPathsChecked: ["incident.sport.sportType"],
        diagnosisHint: sportResolution.status === AUTO
          ? "PLAN_MAPPING_MISSING"
          : sportResolution.status === "AMBIGUOUS"
            ? "AMBIGUOUS_BY_POLICY"
            : "CAPTURE_INCONCLUSIVE",
        evidence: {
          source: sportResolution.source || null,
          crosswalkStatus: sportResolution.status || "UNKNOWN",
          protectorValue: sportResolution.protectorValue || null,
          protectorLabel: sportResolution.protectorLabel || null,
          reason: sportResolution.reason || null
        }
      },
      "/swe/sv/5/accident/in-elementary-school": {
        canonicalPathsChecked: ["incident.school.educationLevel"],
        diagnosisHint: elementarySchoolChoice ? "PLAN_MAPPING_MISSING" : "AMBIGUOUS_BY_POLICY",
        evidence: { resolvedChoice: elementarySchoolChoice }
      },
      "/swe/sv/5/accident/teeth-or-body": {
        canonicalPathsChecked: ["injuries.bodyInjuries"],
        diagnosisHint: "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/body-parts": {
        canonicalPathsChecked: ["injuries.bodyInjuries"],
        diagnosisHint: bodyParts.execution === USER_REQUIRED && bodyParts.ambiguous.length > 0
          ? "AMBIGUOUS_BY_POLICY"
          : "CAPTURE_INCONCLUSIVE",
        evidence: { ambiguous: bodyParts.ambiguous, unsupported: bodyParts.unsupported }
      },
      "/swe/sv/5/accident/claim-cause": {
        canonicalPathsChecked: ["incident.description", "incident.place"],
        diagnosisHint: "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/claim-cause-consequences": {
        canonicalPathsChecked: ["injuries.bodyInjuries", "injuries.consequencesEvidence", "injuries.consequencesEvidenceComplete", "injuries.consequenceSourceTexts"],
        diagnosisHint: consequences.length > 0 && consequencesComplete ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: {
          everyBodyHeadingClassified,
          sourceComplete: canonical?.injuries?.consequencesEvidenceComplete === true
        }
      },
      "/swe/sv/5/accident/has-plaster-treatment": {
        canonicalPathsChecked: ["incident.gipsed", "incident.gipsWeeks", "incident.customerAdditionalInfo", "treatments.performed"],
        diagnosisHint: plaster.conflict ? "SOURCE_CONFLICT" : plaster.hasPlaster !== null ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/weeks-of-plaster-treatment": {
        canonicalPathsChecked: ["incident.gipsWeeks", "incident.customerAdditionalInfo", "treatments.performed"],
        diagnosisHint: plaster.weeks ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/previous-injury": {
        canonicalPathsChecked: ["incident.previousInjuryHad", "incident.date", "care.providers"],
        diagnosisHint: previousInjury.conflict ? "SOURCE_CONFLICT" : previousInjury.hadPrevious !== null ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: {
          source: previousInjury.source,
          firstCareDate: previousInjury.firstCareDate,
          conflict: previousInjury.conflict === true
        }
      },
      "/swe/sv/5/accident/is-doctor-contacted": {
        canonicalPathsChecked: ["incident.hasDoctorVisit", "care.providers"],
        diagnosisHint: doctorCare.conflict ? "SOURCE_CONFLICT" : doctorCare.hasDoctor !== null ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: {
          ambiguousProviderEvidence: doctorCare.hasAmbiguousProviderEvidence,
          conflict: doctorCare.conflict
        }
      },
      "/swe/sv/5/accident/type-of-medical-institution": {
        canonicalPathsChecked: ["care.providers"],
        diagnosisHint: medicalInstitutionType ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/date-of-treatment": {
        canonicalPathsChecked: ["incident.date", "care.providers"],
        diagnosisHint: doctorCare.firstVisit?.date ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { rejectedBeforeIncident: doctorCare.rejectedBeforeIncident }
      },
      "/swe/sv/5/accident/medical-institution-information": {
        canonicalPathsChecked: ["care.providers"],
        diagnosisHint: doctorCare.firstVisit?.provider?.providerName ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/finished-treatment": {
        canonicalPathsChecked: ["treatments.planned"],
        diagnosisHint: treatmentFinished ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/invalidity": {
        canonicalPathsChecked: ["injuries.residualIssues"],
        diagnosisHint: invalidity.conflict ? "SOURCE_CONFLICT" : invalidity.value ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/has-expenses": {
        canonicalPathsChecked: ["expenses", "expensesMeta.sourceStatus"],
        diagnosisHint: expenseResolution.malformed ? "CAPTURE_INCONCLUSIVE" : expenseResolution.hasExpenses !== null ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/upload-receipt": {
        canonicalPathsChecked: ["expenses"],
        diagnosisHint: "MANUAL_BY_DESIGN"
      },
      "/swe/sv/5/accident/has-other-insurance": {
        canonicalPathsChecked: [
          "otherAccidentInsurance",
          "meta.insuranceMatter.sourceStatus",
          "meta.insuranceMatter.entries",
          "meta.insuranceMatter.cards"
        ],
        diagnosisHint: otherInsurance.hasOther !== null ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { source: otherInsurance.source }
      },
      "/swe/sv/5/accident/other-insurance-company": {
        canonicalPathsChecked: ["otherAccidentInsurance.insurer", "meta.insuranceMatter.cards"],
        diagnosisHint: otherInsurance.company ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/has-attachment": {
        canonicalPathsChecked: [],
        diagnosisHint: "PLAN_MAPPING_MISSING",
        evidence: { businessRule: "ALWAYS_ATTACH_FULLMAKT_AND_FORSATTSBLAD" }
      },
      "/swe/sv/5/accident/upload-attachment": {
        canonicalPathsChecked: [],
        diagnosisHint: "MANUAL_BY_DESIGN"
      },
      "/swe/sv/5/accident/situation-summary": {
        canonicalPathsChecked: ["incident.description"],
        diagnosisHint: "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/is-municipality": {
        canonicalPathsChecked: ["meta.insuranceMatter", "incident.school.policyholder"],
        diagnosisHint: insuranceType ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/school-information": {
        canonicalPathsChecked: ["incident.school"],
        diagnosisHint: Object.values(school).every(Boolean) ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE",
        evidence: { availableFields: Object.entries(school).filter(([, value]) => value).map(([key]) => key) }
      },
      "/swe/sv/5/accident/association-information": {
        canonicalPathsChecked: ["meta.insuranceMatter"],
        diagnosisHint: association ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/claimant-information": {
        canonicalPathsChecked: ["claimant.name", "claimant.personNumber", "INSURELLO_CONTACT"],
        diagnosisHint: steps["/swe/sv/5/accident/claimant-information"].execution === AUTO ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/reporter-information": {
        canonicalPathsChecked: ["reporter", "customer", "INSURELLO_CONTACT"],
        diagnosisHint: steps["/swe/sv/5/accident/reporter-information"].execution === AUTO ? "PLAN_MAPPING_MISSING" : "CAPTURE_INCONCLUSIVE"
      },
      "/swe/sv/5/accident/bank-account-information": {
        canonicalPathsChecked: ["INSURELLO_ACCOUNT_HOLDER", "INSURELLO_BANK_ACCOUNT"],
        diagnosisHint: "MANUAL_BY_DESIGN"
      }
    };

    for (const [route, step] of Object.entries(steps)) {
      step.diagnostics = diagnosticContracts[route] || {
        canonicalPathsChecked: [],
        diagnosisHint: "CAPTURE_INCONCLUSIVE"
      };
    }

    return {
      schemaId: "protector_plan_v1",
      caseNumber: canonical?.meta?.caseNumber || null,
      createdAt: new Date().toISOString(),
      steps,
      semanticCoverage: semanticCoverage?.summarizePlan?.(steps) || null,
      warnings: [
        ...bodyParts.ambiguous.map((item) => `${item.reason}: ${item.source}`),
        ...bodyParts.unsupported.map((item) => `UNMAPPED_BODY_PART: ${item}`),
        ...(doctorCare.rejectedBeforeIncident ? ["CARE_VISIT_BEFORE_INCIDENT_IGNORED"] : []),
        ...(plaster.conflict ? ["SOURCE_CONFLICT:PLASTER"] : [])
      ]
    };
  }

  function getStep(plan, path) {
    return plan?.steps?.[String(path || "").replace(/\/+$/, "")] || {
      execution: UNSUPPORTED,
      reason: "UNKNOWN_ROUTE",
      note: "Protector-sidan är inte kartlagd. Fortsätt manuellt eller avbryt körningen."
    };
  }

  return {
    AUTO,
    USER_REQUIRED,
    UNSUPPORTED,
    HARD_STOP,
    buildProtectorPlan,
    getStep,
    __test: {
      fold,
      resolveInsuranceType,
      resolveLocation,
      resolveTimeOfDay,
      normalizeIncidentDate,
      resolveBodyParts,
      resolveCause,
      resolveConsequences,
      splitName,
      formatPersonNumber,
      deriveAgeAtIncident,
      samePerson,
      canComparePersons,
      resolveClaimReporterRole,
      resolveReporter,
      resolveReporterRelation,
      resolveTeethOrBody,
      resolveDomestic,
      resolveDuringSport,
      resolvePlaster,
      resolveExpenses,
      resolveSchool,
      resolvePreviousInjury,
      buildManualSourceContext,
      buildInjuryDecisionContext,
      resolveDoctorCare,
      resolveDentistCare,
      resolveMedicalInstitutionType,
      resolveTreatmentFinished,
      resolveInvalidity,
      resolveOtherInsurance,
      resolveHasAttachment,
      resolveAssociation,
      classifyBodySourceConcept
    }
  };
});
