/* Shared same-origin reader and source-verified care adapter. No DOM-derived care data. */
(function (root) {
  'use strict';
  const ORIGIN = 'https://crm.insurello.se';
  // Browser reducer contract plus the separately pinned server/domain review
  // below. Selected event payloads are inputs, not necessarily current values.
  const CONTRACT_REVISION = 'dd2b056581d23fd3d4bf18cf2f3afec5467792f1';
  const CASE_EVENTS = new Set(['claim_created', 'claim', 'claim_details_finished', 'corrected_case', 'hospitalized_during_treatment', 'system_asked_treatments_question', 'system_scheduled_maturity_check', 'interrupted_treatment_wait']);
  // Non-case workflow/history events recognized by Timeline.elm, plus the
  // activity categories explicitly excluded from this task's data scope.
  const NON_CASE_EVENTS = new Set(['rejected', 'power_of_attorney', 'power_of_attorney_signed', 'system_determined_case_ready', 'assigned', 'note', 'reminder']);
  const CASE_ANSWERS = new Set(['PersonalAccidentInsurance', 'EmploymentConfirmation', 'PriorBodyPartIssues', 'SickLeave', 'Treatments', 'LicensePlate', 'PreviousTrafficInsuranceAssessment', 'PreviousReportToAFA', 'VerifyRecovery']);
  const NON_CASE_ANSWERS = new Set(['PermissionToTakeOverInsuranceCaseClaim', 'FreeText', 'FileUpload', 'ClarifyTheIncident', 'PreviousRejectReason', 'PreviousReimbursement', 'HorseName', 'HospitalVisitReason', 'SoughtCareForInjury', 'SelfDeclaration', 'SportClubMembership', 'TravelInsurance', 'HorseInsurance', 'WrongDateOfIncident', 'WrongHealthcareProvider', 'SignInsuranceClaim']);
  const LEGACY_CASE_ANSWERS = new Set(['first_hospital_visit', 'afa_claim_status', 'traffic_incident', 'traffic_insurance', 'personal_accident_insurance', 'child_insurance', 'home_insurance', 'additional_visited_hospitals', 'union_membership', 'accident_insurance_via_union_claim_status', 'opted_for_accident_insurance_via_union', 'employer_contact_details', 'treatments', 'expenses']);
  const LEGACY_NON_CASE_ANSWERS = new Set(['scar_pictures', 'bank_account', 'self_declaration']);
  const PROJECTION_FIELDS = new Set(['caseCategory', 'dateOfIncident', 'employment', 'firstHealthcareProviderVisited', 'incidentDescription', 'insuranceCases', 'unconnectedInsuranceCases', 'mainInsuranceCaseId', 'sickLeave', 'visitedHealthcareProviders']);
  const PROJECTION_ACTIVITY = new Set(['caseCategoryHistory', 'caseClosable', 'caseRejectable', 'complements', 'manualFollowupQuestions', 'receivedMail', 'selfDeclarationLegacyProcesses', 'selfDeclarationProcesses', 'sentCustomerMessages', 'sentMail', 'unansweredPredefinedQuestions', 'warnings']);
  // Source review and scope decisions: docs/structured-crm/server-event-review-2026-10-02.md.
  // Kept separate from source-selection issues: old plugins omitted these
  // payloads, so web review must never erase the original diagnostic evidence.
  const REVIEWED_ACTIVITY_EVENTS = new Set(['took_case', 'left_case', 'sent_mail_requested', 'sent_mail_added', 'sent_mail_status_changed', 'mail_received', 'received_mail_metadata_updated', 'customer_message_sent', 'customer_message_read', 'system_did_not_reject', 'all_automated_insurance_cases_added',
    'system_asked_child_insurance_question', 'system_asked_union_membership_question', 'system_asked_personal_accident_insurance_question', 'system_asked_expenses_question', 'system_asked_scar_pictures_question', 'agent_asked_additional_visited_hospitals_question']);
  const CURRENT_PROJECTION_RULES = {
  "categorized": {
    "id": "categorized_current_projection_v1",
    "decision": "conditional_retained_current_category",
    "paths": [
      "caseProjection.caseCategory"
    ],
    "evidence": {
      "url": "https://github.com/insurello/DomainSweden/blob/53cfb5e105d32c1fc4bfc33e6a5da70e15bef6bc/src/DomainSweden/CaseCategory.fs",
      "symbol": "codec"
    },
    "limit": "Known category retained; not all category fields interpreted"
  },
  "visited_healthcare_provider_added": {
    "id": "visited_healthcare_provider_added_current_projection_v1",
    "decision": "conditional_validated_current_visits",
    "paths": [
      "caseProjection.visitedHealthcareProviders"
    ],
    "evidence": {
      "url": "https://github.com/insurello/InsurelloSweden/blob/60121de4432f53bbaec0d4a88b2828c458a75587/services/CrmApi/src/Queries/Case/Query.fs",
      "symbol": "fetchVisitedHealthcareProviderTimelinesFromCaseTimeline; initProjectCase"
    },
    "limit": "Current provider list validated; does not establish historical aggregate correspondence"
  },
  "first_healthcare_provider_visited": {
    "id": "first_healthcare_provider_visited_current_projection_v1",
    "decision": "conditional_validated_first_visit",
    "paths": [
      "caseProjection.firstHealthcareProviderVisited"
    ],
    "evidence": {
      "url": "https://github.com/insurello/InsurelloSweden/blob/60121de4432f53bbaec0d4a88b2828c458a75587/services/CrmApi/src/Queries/Case/CaseProjection.fs",
      "symbol": "projectIntermediateCase; project"
    },
    "limit": "Exact current first provider/visit reference validated"
  },
  "insurance_case_added": {
    "id": "insurance_case_added_current_projection_v1",
    "decision": "conditional_decoded_current_matters",
    "paths": [
      "caseProjection.insuranceCases",
      "caseProjection.unconnectedInsuranceCases"
    ],
    "evidence": {
      "url": "https://github.com/insurello/InsurelloSweden/blob/60121de4432f53bbaec0d4a88b2828c458a75587/services/CrmApi/src/Queries/Case/Query.fs",
      "symbol": "fetchInsuranceCaseDataFromCaseTimeline; projectInsuranceCases"
    },
    "limit": "Present decoded current matters; not a current policy selection"
  },
  "primary_insurance_case_selected": {
    "id": "primary_insurance_case_selected_current_projection_v1",
    "decision": "conditional_decoded_main_matter_reference",
    "paths": [
      "caseProjection.mainInsuranceCaseId"
    ],
    "evidence": {
      "url": "https://github.com/insurello/DomainSweden/blob/53cfb5e105d32c1fc4bfc33e6a5da70e15bef6bc/src/DomainSweden/MainInsuranceCaseProjection.fs",
      "symbol": "update; fromTimeline"
    },
    "limit": "Current reference validated by insuranceMatters decoder"
  },
  "connected_to_customer": {
    "id": "connected_to_customer_current_projection_v1",
    "decision": "conditional_current_identity",
    "paths": [
      "caseIdentity.customer",
      "caseIdentity.case_refers_to_person"
    ],
    "evidence": {
      "url": "https://github.com/insurello/app/blob/dd2b056581d23fd3d4bf18cf2f3afec5467792f1/sweden/src/Sweden/Admin/Types/InboxCase.elm",
      "symbol": "decoder"
    },
    "limit": "Bound current identity validated; historical relationship not independently replayed"
  },
  "child_connected_to_spar_subscription": {
    "id": "child_connected_to_spar_subscription_current_projection_v1",
    "decision": "unresolved_identity_provenance",
    "paths": [
      "caseIdentity.case_refers_to_person.personal_number"
    ],
    "evidence": {
      "url": "https://github.com/insurello/InsurelloSweden/blob/60121de4432f53bbaec0d4a88b2828c458a75587/services/CrmApi/src/Queries/Case/Query.fs",
      "symbol": "fetchSparSubscriptionTimelinesFromTimelines"
    },
    "limit": "A present personal number does not prove it is the result of this subscription"
  }
};
  function knownGenericComplement(value) {
    const shape = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).every(key => keys.includes(key));
    if (!shape(value, ['complementType', 'actor', 'timestamp'])) return false;
    const type = value.complementType;
    if (type?.tag === 'Complement' && shape(type, ['tag', 'complement'])) {
      return shape(type.complement, ['tag', 'description']) && type.complement.tag === 'OtherComplement' && typeof type.complement.description === 'string';
    }
    if (type?.tag === 'FileUpload' && shape(type, ['tag', 'fileUpload'])) {
      const upload = type.fileUpload;
      return shape(upload, ['fileType', 'files']) && shape(upload.fileType, ['tag', 'description']) && upload.fileType.tag === 'OtherFileType' && typeof upload.fileType.description === 'string' && Array.isArray(upload.files);
    }
    return false;
  }
  function caseInputs(key, value) {
    const issues = []; const issueByKey = new Map(); let discarded = 0; let selected; const unmapped = {};
    const recordIssue = issue => {
      const key = JSON.stringify([issue.code, issue.event, issue.tag]);
      const previous = issueByKey.get(key);
      if (previous) previous.count = (previous.count || 1) + 1;
      else { issueByKey.set(key, issue); issues.push(issue); }
    };
    if (key === 'caseTimeline') {
      if (!Array.isArray(value)) fail('SCHEMA', '$.caseTimeline');
      selected = [];
      value.forEach((commit, index) => {
        object(commit, `$.caseTimeline[${index}]`);
        const event = string(commit.event, `$.caseTimeline[${index}].event`);
        let keep = CASE_EVENTS.has(event);
        if (event === 'complemented_case') {
          if (!knownGenericComplement(commit.payload)) recordIssue({ code: 'UNREVIEWED_COMPLEMENT_STRUCTURE', index, event });
        } else if (event === 'answered_followup_question') {
          const payload = object(commit.payload, `$.caseTimeline[${index}].payload`);
          const tag = string(payload.tag, `$.caseTimeline[${index}].payload.tag`);
          keep = CASE_ANSWERS.has(tag);
          if (!keep && !NON_CASE_ANSWERS.has(tag)) recordIssue({ code: 'UNKNOWN_FOLLOWUP_VARIANT', index, tag });
        } else if (event === 'asked_followup_question') {
          const tag = string(object(commit.payload, `$.caseTimeline[${index}].payload`).tag, `$.caseTimeline[${index}].payload.tag`);
          keep = ['EmploymentConfirmation', 'SickLeave', 'PriorBodyPartIssues', 'VerifyRecovery'].includes(tag);
          if (!keep && !CASE_ANSWERS.has(tag) && !NON_CASE_ANSWERS.has(tag)) recordIssue({ code: 'UNKNOWN_FOLLOWUP_QUESTION_VARIANT', index, tag });
        } else if (event.startsWith('customer_answered_') && event.endsWith('_question')) {
          const kind = event.slice('customer_answered_'.length, -'_question'.length);
          keep = LEGACY_CASE_ANSWERS.has(kind);
          if (!keep && !LEGACY_NON_CASE_ANSWERS.has(kind)) recordIssue({ code: 'UNKNOWN_LEGACY_ANSWER', index, event });
        } else if (!keep && !NON_CASE_EVENTS.has(event) && !REVIEWED_ACTIVITY_EVENTS.has(event)) {
          recordIssue({ code: 'UNCLASSIFIED_TIMELINE_EVENT', index, event, count: 1 });
        }
        // Unclassified activity is a visible coverage gap, not an automatic
        // invitation to export arbitrary notes or conversation payloads.
        if (keep) {
          string(commit.timestamp, `$.caseTimeline[${index}].timestamp`);
          if (event !== 'interrupted_treatment_wait') object(commit.payload, `$.caseTimeline[${index}].payload`);
          // Signup contact is historical; current, role-bound identity comes from InboxCase.
          const payload = event === 'claim_created' ? Object.fromEntries(Object.entries(commit.payload).filter(([key]) => key !== 'contact')) : commit.payload;
          selected.push({ timestamp: commit.timestamp, event, ...(Object.hasOwn(commit, 'payload') ? { payload } : {}) });
        } else discarded++;
      });
    } else if (key === 'caseProjection') {
      object(value, '$.caseProjection'); selected = {};
      for (const [name, field] of Object.entries(value)) {
        if (PROJECTION_FIELDS.has(name)) selected[name] = field;
        else {
          discarded++;
          if (name === 'complements' && (!Array.isArray(field) || field.some(entry => !knownGenericComplement(entry)))) {
            recordIssue({ code: 'UNREVIEWED_COMPLEMENT_STRUCTURE', key: name });
          }
          if (!PROJECTION_ACTIVITY.has(name)) {
            Object.defineProperty(unmapped, name, { value: field, enumerable: true, writable: true, configurable: true });
            issues.push({ code: 'UNCLASSIFIED_CASE_CATEGORY', key: name });
          }
        }
      }
      // Keep the case facts inside filing/confirmation actions. Remaining action
      // payloads, signature/file references, warnings and rejectable UI stay outside scope.
      if (Array.isArray(selected.insuranceCases)) selected.insuranceCases = selected.insuranceCases.map(entry => {
        const { actions, warnings, rejectable, ...caseData } = object(entry, '$.insuranceCases[]');
        if (actions !== undefined) {
          if (!Array.isArray(actions)) fail('SCHEMA', '$.insuranceCases[].actions');
          caseData.actions = actions.filter(action => {
            object(action, '$.insuranceCases[].actions[]');
            return action.tag === 'ClaimFiled' || action.tag === 'ClaimConfirmed';
          }).map(action => {
            const state = object(action.state, '$.insuranceCases[].actions[].state');
            const payload = {};
            if (state.tag === 'Done') {
              const original = object(state.payload, '$.insuranceCases[].actions[].state.payload');
              for (const name of action.tag === 'ClaimFiled' ? ['tag', 'claimProcessFiledBy'] : ['caseIdAtInsuranceCompany']) {
                if (Object.hasOwn(original, name)) payload[name] = original[name];
              }
            }
            return { tag: action.tag, state: { tag: state.tag, payload } };
          });
        }
        return caseData;
      });
    } else if (key === 'caseIdentity') {
      object(value, '$.caseIdentity');
      selected = { case_id: value.case_id, case_category: value.case_category };
      for (const field of ['customer', 'case_refers_to_person']) {
        if (value[field] == null) selected[field] = value[field];
        else {
          const { other_cases, previous_name, previous_email, previous_phone, ...person } = object(value[field], `$.caseIdentity.${field}`);
          selected[field] = person;
        }
      }
    } else if (key === 'caseBasics') {
      object(value, '$.caseBasics');
      const { taken, followup_answer_status, ...caseData } = value;
      selected = caseData;
    } else fail('UNSUPPORTED_SOURCE', key);
    return { raw: selected, ...(Object.keys(unmapped).length ? { unmapped } : {}), selection: { contractRevision: CONTRACT_REVISION, discarded, issues,
      normalized: false, scope: 'case_state_inputs' } };
  }
  // References come from approved case inputs, never from a website URL list.
  function workLookupReferences(timeline) {
    const schools = new Set(), employmentOffices = new Set(), healthcareProviders = new Set(), injuries = new Set();
    const school = value => { if (value?.tag === 'InsuroSchool' && typeof value.schoolId === 'string') schools.add(value.schoolId); };
    for (const commit of timeline) {
      if (commit.event !== 'claim_details_finished') continue;
      const type = commit.payload?.caseType;
      const work = type?.tag === 'WorkRelated' ? type.workData : type?.tag === 'TrafficAccident' && type.trafficAccidentCaseType?.tag === 'WorkRelatedWithTimeBarredTraffic' ? type.trafficAccidentCaseType.workData : null;
      const employment = work?.typeOfEmployment;
      if (employment?.workStudy?.tag === 'StudiesPartTime') school(employment.workStudy.workSchool);
      const via = employment?.internshipVia;
      if (via?.tag === 'InternshipEducation') school(via.workSchool);
      if (via?.tag === 'Arbetsförmedlingen' && typeof via.arbetsförmedlingenId === 'string') employmentOffices.add(via.arbetsförmedlingenId);
    }
    // Walk selected case facts only. Never walk the activity feed or domains.
    const stack = timeline.flatMap(commit => {
      if (commit.event === 'claim_details_finished') return [commit.payload];
      if (commit.event === 'claim') return [commit.payload?.body_injury?.treatment];
      if (commit.event === 'answered_followup_question' && ['Treatments','PriorBodyPartIssues'].includes(commit.payload?.tag)) return [commit.payload.answer];
      if (commit.event === 'customer_answered_treatments_question') return [commit.payload];
      // Corrected injuries already contain their own display values. Traversing
      // every correction/history record would reintroduce the large-case cost.
      return [];
    }); let visited = 0;
    while (stack.length) {
      const item = stack.pop(); if (!item || typeof item !== 'object') continue;
      if (++visited > 50000) fail('LOOKUP_REFERENCE_LIMIT');
      if (item.tag === 'HealthcareProviderId' && typeof item.id === 'string') healthcareProviders.add(item.id);
      if (item.tag === 'InjuryFromList' && typeof item.data?.injuryId === 'string') injuries.add(item.data.injuryId);
      for (const child of Object.values(item)) if (child && typeof child === 'object') stack.push(child);
    }
    if (schools.size + employmentOffices.size + healthcareProviders.size + injuries.size > 256) fail('LOOKUP_REFERENCE_LIMIT');
    return { schools: [...schools].sort(), employmentOffices: [...employmentOffices].sort(), healthcareProviders: [...healthcareProviders].sort(), injuries: [...injuries].sort() };
  }
  function selectWorkLookupNames(value, references, domainWire = false) {
    object(value, '$.caseLookups.raw'); const selected = {};
    for (const group of ['schools', 'employmentOffices', 'healthcareProviders', 'injuries']) {
      const wanted = new Set(references[group]); const rows = value[domainWire && group === 'employmentOffices' ? 'arbetsförmedlingar' : group];
      if (!wanted.size || (!domainWire && rows === undefined && ['healthcareProviders','injuries'].includes(group))) { selected[group] = []; continue; }
      if (!Array.isArray(rows)) fail('SCHEMA', '$.caseLookups.raw.' + group);
      const matches = new Map();
      for (const row of rows) {
        if (!wanted.has(row?.id)) continue;
        object(row, '$.caseLookups.raw.' + group + '[]');
        if (typeof row.name !== 'string') fail('SCHEMA', '$.caseLookups.raw.' + group + '[].name');
        const bodyPartId = group === 'injuries' ? row[domainWire ? 'body_part_id' : 'bodyPartId'] : null;
        if (group === 'injuries' && typeof bodyPartId !== 'string') fail('SCHEMA', '$.caseLookups.raw.injuries[].bodyPartId');
        if (group === 'injuries' && matches.has(row.id)) fail('AMBIGUOUS_INJURY_LOOKUP');
        // CRM Dict.fromList retains the last value for duplicate domain IDs.
        matches.set(row.id, { id: row.id, name: row.name, ...(group === 'injuries' ? { bodyPartId } : {}) });
      }
      selected[group] = [...matches.values()].sort((a, b) => a.id.localeCompare(b.id));
    }
    const bodyPartIds = new Set(selected.injuries.map(row => row.bodyPartId));
    const bodyPartRows = value[domainWire ? 'bodyPartNames' : 'bodyParts'];
    selected.bodyParts = [];
    if (bodyPartIds.size && bodyPartRows != null) {
      if (!Array.isArray(bodyPartRows)) fail('SCHEMA', '$.caseLookups.raw.bodyParts');
      const matches = new Map();
      for (const row of bodyPartRows) if (bodyPartIds.has(row?.id)) {
        if (typeof row.name !== 'string') fail('SCHEMA', '$.caseLookups.raw.bodyParts[].name');
        matches.set(row.id, {id:row.id,name:row.name});
      }
      selected.bodyParts = [...matches.values()].sort((a,b) => a.id.localeCompare(b.id));
    }
    return selected;
  }
  // The case projection includes names under exact catalogue provider IDs.
  // No position, visited-provider ID or fuzzy text matching is used.
  function embeddedProviderLookups(projection, references) {
    if (references.schools.length || references.employmentOffices.length || references.injuries.length) return null;
    if (!Array.isArray(projection?.visitedHealthcareProviders)) return null;
    const wanted = new Set(references.healthcareProviders);
    const names = new Map();
    for (const entry of projection.visitedHealthcareProviders || []) {
      const row = entry?.provider?.tag === 'HealthcareProvider' ? entry.provider.healthcareProvider : null;
      if (!wanted.has(row?.id)) continue;
      if (typeof row.name !== 'string' || !row.name.trim()) return null;
      if (names.has(row.id) && names.get(row.id) !== row.name) return null;
      names.set(row.id, row.name);
    }
    if ([...wanted].some(id => !names.has(id))) return null;
    return { schools: [], employmentOffices: [], injuries: [], bodyParts: [],
      healthcareProviders: [...wanted].sort().map(id => ({id, name:names.get(id)})) };
  }
  // Saved Claim labels are case facts, not fresh catalogue/anatomical metadata.
  // Resolve only exact IDs; missing or conflicting facts retain the Domains path.
  function embeddedCaseLookups(projection, timeline, references) {
    if (references.schools.length || references.employmentOffices.length) return null;
    const selected = embeddedProviderLookups(projection, {...references, injuries:[]});
    if (!selected) return null;
    const wanted = new Set(references.injuries), names = new Map();
    for (const commit of timeline) {
      if (commit.event !== 'claim') continue;
      const rows = commit.payload?.body_injury?.injuries;
      if (!Array.isArray(rows)) continue;
      for (const row of rows) {
        if (row?.tag !== 'existing' || !wanted.has(row.injury_id)) continue;
        if (typeof row.name !== 'string' || !row.name.trim()) return null;
        if (names.has(row.injury_id) && names.get(row.injury_id) !== row.name) return null;
        names.set(row.injury_id, row.name);
      }
    }
    if ([...wanted].some(id => !names.has(id))) return null;
    selected.injuries = [...wanted].sort().map(id => ({id, name:names.get(id), bodyPartId:null, labelSource:'claim_snapshot'}));
    return selected;
  }
  // Bounded, value-free optional telemetry. Drop malformed metadata instead of
  // allowing diagnostics to invalidate otherwise valid case inputs.
  // Browser-recorded request phases. Numbers and fixed vocabularies only: no URL,
  // header value or Server-Timing description crosses this boundary.
  function browserTiming(value) {
    if (!value || typeof value !== 'object') return null;
    const metric = n => Number.isFinite(n) && n >= 0 && n <= 100 * 1024 * 1024;
    const safe = {};
    for (const field of ['queueMs','connectMs','waitMs','downloadMs','durationMs','transferBytes','leadMs']) if (metric(value[field])) safe[field] = Math.round(value[field]);
    if (['h2','h3','h2c','http/1.0','http/1.1','quic'].includes(value.protocol)) safe.protocol = value.protocol;
    if (value.match === 'url_time_candidate') safe.match = value.match;
    if (['fetch','xmlhttprequest','beacon','other'].includes(value.initiator)) safe.initiator = value.initiator;
    if (typeof value.overlapsOwn === 'boolean') safe.overlapsOwn = value.overlapsOwn;
    if (Array.isArray(value.serverTiming)) {
      const entries = value.serverTiming.slice(0, 8).filter(item => item && ['app','db','cache','total','cpu','sql'].includes(item.name) && metric(item.durationMs))
        .map(item => ({ name: item.name, durationMs: Math.round(item.durationMs) }));
      if (entries.length) safe.serverTiming = entries;
    }
    return Object.keys(safe).length ? safe : null;
  }
  function transportDiagnostics(value) {
    if (!value || value.schema !== 'crm_transport_diagnostics_v1') return null;
    const safe = { schema:'crm_transport_diagnostics_v1', sources:{} };
    const metric = n => Number.isFinite(n) && n >= 0 && n <= 100 * 1024 * 1024;
    for (const key of ['caseProjection','caseBasics','caseIdentity','caseTimeline','caseLookups']) {
      const source = value.sources?.[key]; if (!source || typeof source !== 'object') continue;
      const item = {};
      for (const field of ['elapsedMs','responseBytes','headersMs','bodyMs','processMs']) if (metric(source[field])) item[field] = source[field];
      if (typeof source.ok === 'boolean') item.ok = source.ok;
      if (typeof source.code === 'string' && /^[A-Z_]{1,80}$/.test(source.code)) item.code = source.code;
      if (['case_embedded','domains'].includes(source.resolution)) item.resolution = source.resolution;
      const browser = browserTiming(source.browser); if (browser) item.browser = browser;
      if (['recorded','not_found','ambiguous'].includes(source.browserTimingStatus)) item.browserTimingStatus = source.browserTimingStatus;
      safe.sources[key] = item;
    }
    if (['recorded','own_entries_not_found','unavailable'].includes(value.resourceTiming)) safe.resourceTiming = value.resourceTiming;
    if (Array.isArray(value.crmPageReads)) {
      const reads = value.crmPageReads.slice(-3).map(browserTiming).filter(Boolean);
      if (reads.length) safe.crmPageReads = reads;
    }
    if (metric(value.collectMs)) safe.collectMs = value.collectMs;
    if (typeof value.pluginVersion === 'string' && /^\d+\.\d+\.\d+$/.test(value.pluginVersion)) safe.pluginVersion = value.pluginVersion;
    if (typeof value.buildRevision === 'string' && /^[a-f0-9]{40}(?:-dirty)?$/.test(value.buildRevision)) safe.buildRevision = value.buildRevision;
    const stages = {};
    for (const key of ['contextMs','payloadMs','openMs','targetReadyMs','targetWaitMs','dispatchWaitMs','handoffAttempts'])
      if (metric(value.stages?.[key])) stages[key] = value.stages[key];
    if (value.stages?.targetPreloaded === true) stages.targetPreloaded = true;
    if (Object.keys(stages).length) safe.stages = stages;
    return safe;
  }
  function caseLookupHandoff(value, caseId, timeline, projection) {
    if (value == null) return null;
    object(value, '$.caseLookups');
    if (value.schema !== 'crm_case_lookups_v1' || value.caseId !== caseId || !['/admin-api/query/domains','/crm-api/query/case','case_inputs'].includes(value.endpoint)) fail('UNEXPECTED_CASE_LOOKUPS');
    const references = workLookupReferences(timeline);
    if (!Object.values(references).some(ids => ids.length)) return null;
    // Sentinel for multiple bound case sources, not an HTTP endpoint.
    // Reconstruct from those sources; ignore caller-supplied labels/IDs.
    if (value.endpoint === 'case_inputs') {
      const raw = embeddedCaseLookups(projection, timeline, references);
      if (value.ok !== true || !raw) fail('UNEXPECTED_CASE_LOOKUPS');
      return {schema:value.schema, caseId, endpoint:value.endpoint, ok:true, resolution:'case_embedded',
        metadataState:raw.injuries.length ? 'anatomy_unavailable' : 'available', raw};
    }
    if (value.endpoint === '/crm-api/query/case') {
      const raw = embeddedProviderLookups(projection, references);
      if (value.ok !== true || !raw) fail('UNEXPECTED_CASE_LOOKUPS');
      return { schema:value.schema, caseId, endpoint:value.endpoint, ok:true, resolution:'case_embedded', raw };
    }
    if (value.ok === true) return { schema: value.schema, caseId, endpoint: value.endpoint, ok: true, raw: selectWorkLookupNames(value.raw, references) };
    if (value.ok !== false || typeof value.code !== 'string' || !/^[A-Z_]+$/.test(value.code)) fail('SCHEMA', '$.caseLookups');
    return { schema: value.schema, caseId, endpoint: value.endpoint, ok: false, code: value.code };
  }
  const CASE_INPUT_SCHEMA = 'transfer_tool_case_inputs_v1';
  const MAX_CASE_INPUT_BYTES = 5 * 1024 * 1024;
  // Call after required bound identity/care decoding and supplementary slices.
  // This classifies collection coverage; it does not replace those validators.
  function reviewCaseSources(inputs, decodeIssues = []) {
    const projection = inputs.sources.caseProjection.raw;
    const identity = inputs.sources.caseIdentity.raw;
    const timeline = inputs.sources.caseTimeline.raw;
    const isObject = value => !!value && typeof value === 'object' && !Array.isArray(value);
    const healthy = group => !decodeIssues.some(issue => issue.group === group);
    const mattersPresent = healthy('insuranceMatters') && Array.isArray(projection.insuranceCases) && Array.isArray(projection.unconnectedInsuranceCases) && projection.insuranceCases.length + projection.unconnectedInsuranceCases.length > 0;
    const covered = {
      categorized: ['Traffic', 'Assault', 'Hospital', 'Work', 'Sport', 'Abroad', 'Freetime', 'Diagnosis'].includes(projection.caseCategory),
      visited_healthcare_provider_added: healthy('care') && Array.isArray(projection.visitedHealthcareProviders) && projection.visitedHealthcareProviders.length > 0,
      first_healthcare_provider_visited: healthy('care') && isObject(projection.firstHealthcareProviderVisited),
      insurance_case_added: mattersPresent,
      primary_insurance_case_selected: mattersPresent && typeof projection.mainInsuranceCaseId === 'string' && !!projection.mainInsuranceCaseId,
      connected_to_customer: isObject(identity.customer) && isObject(identity.case_refers_to_person),
      // Current identity remains usable, but SPAR subscription provenance is unverified.
      child_connected_to_spar_subscription: false
    };
    const classified = [], unresolved = [];
    for (const [source, input] of Object.entries(inputs.sources)) {
      for (const issue of input.selection?.issues || []) {
        let status = 'unresolved';
        if (source === 'caseTimeline' && issue.code === 'UNCLASSIFIED_TIMELINE_EVENT') {
          if (REVIEWED_ACTIVITY_EVENTS.has(issue.event)) status = 'excluded_activity';
          else if (Object.hasOwn(CURRENT_PROJECTION_RULES, issue.event) && covered[issue.event]) status = 'collected_current_projection';
          else if (issue.event === 'claim_created' && timeline.some(commit => commit.event === issue.event && isObject(commit.payload))) status = 'collected_not_interpreted';
        } else if (source === 'caseProjection' && issue.code === 'UNCLASSIFIED_CASE_CATEGORY' && Object.hasOwn(input.unmapped || {}, issue.key)) {
          status = 'retained_unmapped_category';
        }
        const ruleId = source === 'caseTimeline' && issue.code === 'UNCLASSIFIED_TIMELINE_EVENT' ? CURRENT_PROJECTION_RULES[issue.event]?.id : undefined;
        const result = { source, ...issue, status, ...(ruleId ? { ruleId } : {}) };
        classified.push(result);
        if (status === 'unresolved') unresolved.push(result);
      }
    }
    // Retention is not interpretation. Assess actual retained input, even when
    // the collector has emitted no historical selection issue for this event.
    const creation = timeline.filter(commit => commit.event === 'claim_created').at(-1);
    if (creation) {
      if (!classified.some(issue => issue.event === 'claim_created')) classified.push({ source: 'caseTimeline', event: 'claim_created', code: 'RETAINED_CREATION_INPUT', status: 'collected_not_interpreted' });
      const claim = timeline.filter(commit => commit.event === 'claim').at(-1)?.payload;
      if (!isObject(claim)) unresolved.push({ source: 'caseTimeline', event: 'claim_created', code: 'CREATION_WITHOUT_CLAIM', status: 'unresolved' });
      // Only compare the verified shared person relation. LegacyClaim.toClaimPerson
      // maps Self/Child directly; detailed incident scenes may legitimately refine
      // signup answers. Current InboxCase identity remains authoritative.
      const person = creation.payload?.person?.tag;
      const happened = creation.payload?.whatHappened?.tag;
      const knownPerson = ['Self', 'Child', 'Ward'].includes(person);
      const knownHappened = ['Overexertion', 'Accident', 'Infection', 'TickBiteOrFrostbite', 'Assault', 'Surgery', 'Diagnosis', 'InjuredByMedication', 'AcneScars'].includes(happened);
      if (!knownPerson || !knownHappened) unresolved.push({ source: 'caseTimeline', event: 'claim_created', code: 'UNREVIEWED_CREATION_VARIANT', status: 'unresolved' });
      const claimRelation = claim?.person?.relation;
      if (knownPerson && ['self', 'child', 'legal_guardian'].includes(claimRelation)
          && (person === 'Self') !== (claimRelation === 'self')) {
        unresolved.push({ source: 'caseTimeline', event: 'claim_created', code: 'CREATION_CLAIM_CONFLICT', path: 'person.relation', status: 'unresolved' });
      }
    }
    return { schema: 'crm_source_review_v1', serverRevision: '60121de4432f53bbaec0d4a88b2828c458a75587', domainRevision: '53cfb5e105d32c1fc4bfc33e6a5da70e15bef6bc', classified, unresolved };
  }
  function caseHandoff(bundle) {
    object(bundle, '$.caseInputs');
    if (bundle.schema === CASE_INPUT_SCHEMA) {
      if (bundle.version !== 1 || bundle.scope !== 'case_state_inputs') fail('UNSUPPORTED_CASE_INPUT_CONTRACT');
    } else if (bundle.schema !== 'crm_case_inputs_v3' || bundle.version !== 3 || bundle.scope !== 'case_state_inputs' || bundle.normalized !== false) {
      fail('UNSUPPORTED_CASE_INPUT_CONTRACT');
    }
    const source = object(bundle.source, '$.source');
    const binding = identity(source.pageUrl);
    if (source.origin !== ORIGIN || source.caseId !== binding.caseId) fail('RESPONSE_CASE_MISMATCH', '$.source');
    if (typeof source.capturedAt !== 'string' || !Number.isFinite(Date.parse(source.capturedAt))) fail('SCHEMA', '$.source.capturedAt');
    const wire = JSON.stringify(bundle);
    if (new TextEncoder().encode(wire).length > MAX_CASE_INPUT_BYTES) fail('CASE_INPUT_TOO_LARGE');
    const sources = {};
    const endpointByKey = {
      caseProjection: '/crm-api/query/case', caseBasics: `/admin-api/search/case/${binding.caseId}`,
      caseIdentity: `/admin-api/inbox/${binding.caseId}`, caseTimeline: `/admin-api/query/case-timeline?caseId=${binding.caseId}`
    };
    for (const [key, endpoint] of Object.entries(endpointByKey)) {
      const input = object(bundle.sources?.[key], `$.sources.${key}`);
      if (input.ok !== true) fail('INCOMPLETE_CASE_INPUTS', `$.sources.${key}`);
      if (input.endpoint !== endpoint) fail('UNEXPECTED_SOURCE_ENDPOINT', `$.sources.${key}.endpoint`);
      if (key === 'caseBasics' || key === 'caseIdentity') {
        if (String(input.raw?.case_id) !== binding.caseId) fail('RESPONSE_CASE_MISMATCH', `$.sources.${key}.raw.case_id`);
      }
      // Reapply the same scoped selection at the handoff boundary. Extra
      // endpoints, responseText, notes and generic answer payloads do not cross.
      const selected = caseInputs(key, input.raw);
      const unmapped = key === 'caseProjection' ? caseInputs(key, input.unmapped || {}).unmapped : null;
      const issues = Array.isArray(input.selection?.issues) ? input.selection.issues.map(issue => {
        object(issue, `$.sources.${key}.selection.issues[]`);
        return Object.fromEntries(['code', 'event', 'tag', 'key', 'index', 'count'].filter(k => Object.hasOwn(issue, k)).map(k => {
          const value = issue[k];
          if (!['string', 'number'].includes(typeof value)) fail('SCHEMA', `$.sources.${key}.selection.issues[].${k}`);
          return [k, value];
        }));
      }) : [];
      const additions = { ...(unmapped || {}), ...(selected.unmapped || {}) };
      sources[key] = { ok: true, endpoint, raw: selected.raw,
        ...(Object.keys(additions).length ? { unmapped: additions } : {}),
        selection: { contractRevision: CONTRACT_REVISION, issues: [...issues, ...selected.selection.issues] } };
    }
    const caseLookups = caseLookupHandoff(bundle.caseLookups, binding.caseId, sources.caseTimeline.raw, sources.caseProjection.raw);
    const diagnostics = transportDiagnostics(bundle.transportDiagnostics);
    // A detached JSON value prevents caller mutation after the handoff is built.
    return JSON.parse(JSON.stringify({ schema: CASE_INPUT_SCHEMA, version: 1, scope: 'case_state_inputs',
      source: { origin: ORIGIN, caseId: binding.caseId, pageUrl: `${ORIGIN}/admin/case/${binding.caseId}`, capturedAt: source.capturedAt }, sources, ...(caseLookups ? { caseLookups } : {}), ...(diagnostics ? {transportDiagnostics:diagnostics} : {}) }));
  }
  class ProbeError extends Error {
    constructor(code, path = null, status = null) {
      super(code); this.code = code; this.path = path; this.status = status;
    }
  }
  const fail = (code, path) => { throw new ProbeError(code, path); };
  function object(value, path) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail('SCHEMA', path);
    return value;
  }
  function string(value, path) {
    if (typeof value !== 'string' || !value.trim()) fail('SCHEMA', path);
    return value;
  }
  function identity(href) {
    const url = new URL(href);
    if (url.origin !== ORIGIN) fail('WRONG_ORIGIN');
    const match = /^\/admin\/case\/([1-9]\d*)\/?$/.exec(url.pathname);
    if (!match) fail('UNSUPPORTED_CASE_ROUTE');
    return { caseId: match[1], href: url.href };
  }
  function projectCare(raw) {
    object(raw, '$');
    if (!Array.isArray(raw.visitedHealthcareProviders)) fail('SCHEMA', '$.visitedHealthcareProviders');
    const providerIds = new Set(); const visitIds = new Set();
    const providers = raw.visitedHealthcareProviders.map((entry, index) => {
      const path = `$.visitedHealthcareProviders[${index}]`;
      object(entry, path);
      const id = string(entry.visitedHealthcareProviderId, `${path}.visitedHealthcareProviderId`);
      if (providerIds.has(id)) fail('DUPLICATE_ID', `${path}.visitedHealthcareProviderId`);
      providerIds.add(id);
      const provider = object(entry.provider, `${path}.provider`);
      const kind = string(provider.tag, `${path}.provider.tag`);
      let name; let catalogueId = null;
      if (kind === 'HealthcareProvider') {
        const catalog = object(provider.healthcareProvider, `${path}.provider.healthcareProvider`);
        name = string(catalog.name, `${path}.provider.healthcareProvider.name`);
        catalogueId = string(catalog.id, `${path}.provider.healthcareProvider.id`);
      } else if (kind === 'ManuallyAdded') {
        name = string(provider.name, `${path}.provider.name`);
      } else fail('UNSUPPORTED_VARIANT', `${path}.provider.tag`);
      if (!Array.isArray(entry.visits)) fail('SCHEMA', `${path}.visits`);
      const visits = entry.visits.map((value, visitIndex) => {
        const vp = `${path}.visits[${visitIndex}]`;
        object(value, vp);
        const visitId = string(value.visitId, `${vp}.visitId`);
        if (visitIds.has(visitId)) fail('DUPLICATE_ID', `${vp}.visitId`);
        visitIds.add(visitId);
        let reasonTag = null;
        if (value.visitReason != null) {
          object(value.visitReason, `${vp}.visitReason`);
          reasonTag = string(value.visitReason.tag, `${vp}.visitReason.tag`);
          if (!['Hospitalization', 'PriorBodyPartIssueVisit', 'UnspecifiedWithPractitioner', 'Treatment', 'Unspecified'].includes(reasonTag))
            fail('UNSUPPORTED_VARIANT', `${vp}.visitReason.tag`);
          if (reasonTag === 'Treatment') {
            const treatment = object(value.visitReason.treatmentVisit, `${vp}.visitReason.treatmentVisit`);
            const type = object(treatment.treatmentType, `${vp}.visitReason.treatmentVisit.treatmentType`);
            if (!['Surgery', 'Other', 'Physiotherapy', 'Naprapathy', 'Cast', 'DentalCare', 'GlueTape', 'Medication', 'SlingCrutches', 'Stitches', 'WoundCare', 'Chiropractic', 'DoctorsVisit'].includes(type.tag))
              fail('UNSUPPORTED_VARIANT', `${vp}.visitReason.treatmentVisit.treatmentType.tag`);
          }
        }
        return { visitId, reasonTag, reasonState: !Object.hasOwn(value, 'visitReason') ? 'missing' : value.visitReason === null ? 'null' : 'present' };
      });
      return { id, kind, catalogueId, name, visits };
    });
    const firstState = !Object.hasOwn(raw, 'firstHealthcareProviderVisited') ? 'missing' : raw.firstHealthcareProviderVisited === null ? 'null' : 'present';
    let first = null;
    if (firstState === 'present') {
      const value = object(raw.firstHealthcareProviderVisited, '$.firstHealthcareProviderVisited');
      first = {
        providerId: string(value.visitedHealthcareProviderId, '$.firstHealthcareProviderVisited.visitedHealthcareProviderId'),
        visitId: string(value.visitId, '$.firstHealthcareProviderVisited.visitId')
      };
      const provider = providers.find(p => p.id === first.providerId);
      if (!provider || !provider.visits.some(v => v.visitId === first.visitId)) fail('BROKEN_FIRST_VISIT', '$.firstHealthcareProviderVisited');
    }
    return { providers, first, firstState };
  }
  function snapshot(raw, responseText, binding, care, mappingError) {
    object(raw, '$');
    // Preserve the exact body as well as its parsed form: unknown values and
    // large JSON number literals must remain available for later adapters.
    return {
      schema: 'crm_case_snapshot_v1', version: 1,
      source: { origin: ORIGIN, endpoint: '/crm-api/query/case', caseId: binding.caseId, pageUrl: binding.href, capturedAt: new Date().toISOString() },
      responseText, raw,
      mapping: { careIdentity: care, error: mappingError },
      categories: Object.keys(raw).map(key => ({
        key,
        state: care && ['visitedHealthcareProviders', 'firstHealthcareProviderVisited'].includes(key) ? 'partially_mapped' : 'unmapped',
        type: raw[key] === null ? 'null' : Array.isArray(raw[key]) ? 'array' : typeof raw[key]
      }))
    };
  }
  const DEPARTMENTS = { IntensiveCareUnit: 'Intensivvård', OrthopedicsCareDepartment: 'Ortopedi',
    Radiology: 'Radiologi (Röntgen)', ChildCareDepartment: 'Barnvård', PediatricOrthopedics: 'Barnortopedi',
    Emergency: 'Akutmottagning', EarNoseThroatAndBalance: 'Öron-näsa-mun och balans',
    MedicalPsychology: 'Medicinsk psykologi', HealthCenterVisit: 'Övrigt besök',
    UnknownDepartment: 'Vet ej', UnspecifiedDepartment: 'Har ej angetts' };
  const TREATMENTS = { Surgery: 'Operation', Physiotherapy: 'Sjukgymnastik/Fysioterapi', Naprapathy: 'Naprapati',
    Cast: 'Gips/Ortos', DentalCare: 'Tandvård', GlueTape: 'Lim/Tejp', Medication: 'Medicin/Sprutor',
    SlingCrutches: 'Mitella/Kryckor', Stitches: 'Stygn', WoundCare: 'Sårvård', Chiropractic: 'Kiropraktik', DoctorsVisit: 'Läkarbesök' };
  function isoDate(value, path) {
    string(value, path);
    const parsed = new Date(value + 'T00:00:00Z');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value)
      fail('INVALID_DATE', path);
    return value;
  }
  function dateRange(value, path) {
    object(value, path);
    const dateFrom = isoDate(value.startDate, path + '.startDate');
    const dateTo = isoDate(value.endDate, path + '.endDate');
    if (dateTo < dateFrom) fail('INVALID_DATE_RANGE', path);
    return { date: dateFrom, dateFrom, dateTo };
  }
  function departmentName(value, path) {
    object(value, path); const tag = string(value.tag, path + '.tag');
    if (Object.hasOwn(DEPARTMENTS, tag)) return DEPARTMENTS[tag];
    if (tag === 'OtherDepartment') return string(value.name, path + '.name').trim();
    if (tag === 'Rehabilitation') return 'Rehabilitering' + (value.practitioner == null ? '' : ' (' + string(value.practitioner, path + '.practitioner').trim() + ')');
    fail('UNSUPPORTED_VARIANT', path + '.tag');
  }
  function canonicalVisit(value, path, isFirstVisit) {
    const visit = { date: null, dateFrom: null, dateTo: null, reason: null,
      department: departmentName(value.department, path + '.department'), isFirstVisit };
    const reason = value.visitReason;
    if (reason == null) return visit;
    const rp = path + '.visitReason'; object(reason, rp);
    if (reason.tag === 'Hospitalization') {
      Object.assign(visit, dateRange(reason.hospitalized, rp + '.hospitalized')); visit.reason = 'Inlagd';
    } else if (reason.tag === 'Unspecified' || reason.tag === 'UnspecifiedWithPractitioner') {
      if (reason.tag === 'UnspecifiedWithPractitioner' && !['doctor', 'nurse', 'physiotherapist', 'other'].includes(reason.practitioner)) fail('UNSUPPORTED_VARIANT', rp + '.practitioner');
      visit.date = isoDate(reason.visitDate, rp + '.visitDate');
    } else if (reason.tag === 'PriorBodyPartIssueVisit') {
      // A year is not a complete visit date. Never manufacture January 1.
      const prior = object(reason.priorBodyPartIssueVisit, rp + '.priorBodyPartIssueVisit');
      if (!Number.isInteger(prior.visitYear) || String(prior.visitYear).length !== 4) fail('SCHEMA', rp + '.priorBodyPartIssueVisit.visitYear');
      if (prior.description != null) visit.reason = string(prior.description, rp + '.priorBodyPartIssueVisit.description').trim();
    } else if (reason.tag === 'Treatment') {
      const tp = rp + '.treatmentVisit.treatmentType';
      const treatment = object(object(reason.treatmentVisit, rp + '.treatmentVisit').treatmentType, tp);
      visit.reason = treatment.tag === 'Other' ? string(treatment.description, tp + '.description').trim() : TREATMENTS[treatment.tag];
      if (treatment.tag === 'Surgery') visit.date = isoDate(treatment.surgery, tp + '.surgery');
      else if (treatment.tag === 'DoctorsVisit') visit.date = isoDate(treatment.visit, tp + '.visit');
      else if (['Cast', 'Other'].includes(treatment.tag)) visit.date = isoDate(treatment.visitDate, tp + '.visitDate');
      else if (['Physiotherapy', 'Naprapathy'].includes(treatment.tag)) Object.assign(visit, dateRange(treatment.duration, tp + '.duration'));
    }
    return visit;
  }
  function projectCanonicalCare(raw) {
    const identityCare = projectCare(raw);
    const providers = [];
    identityCare.providers.forEach((provider, index) => {
      const entry = raw.visitedHealthcareProviders[index]; const path = `$.visitedHealthcareProviders[${index}]`;
      const confirmation = object(entry.confirmation, path + '.confirmation');
      if (confirmation.tag === 'Dismissed') {
        const dismissal = object(confirmation.dismissalReason, path + '.confirmation.dismissalReason');
        if (!['HealthcareProviderDoesNotRecognizeCustomer', 'WrongHealthcareProvider'].includes(dismissal.tag)) fail('UNSUPPORTED_VARIANT', path + '.confirmation.dismissalReason.tag');
        if (identityCare.first?.providerId === provider.id) fail('DISMISSED_FIRST_PROVIDER', '$.firstHealthcareProviderVisited');
        return;
      }
      if (confirmation.tag !== 'NotConfirmed') fail('UNSUPPORTED_VARIANT', path + '.confirmation.tag');
      const source = object(entry.source, path + '.source');
      if (!['MedicalRecord', 'InsuranceCompany', 'Complement', 'ComGame', 'SelfDeclaration', 'FollowupAnswer', 'Signup', 'Other'].includes(source.tag)) fail('UNSUPPORTED_VARIANT', path + '.source.tag');
      providers.push({ providerName: provider.name.trim(), source: source.tag,
        visits: entry.visits.map((visit, vi) => canonicalVisit(visit, `${path}.visits[${vi}]`,
          identityCare.first?.providerId === provider.id && identityCare.first?.visitId === visit.visitId)) });
    });
    const firstProvider = providers.find(p => p.visits.some(v => v.isFirstVisit));
    const firstVisit = firstProvider?.visits.find(v => v.isFirstVisit);
    return { care: { providers, firstVisitState: identityCare.firstState }, incident: { hasDoctorVisit: providers.some(p => p.visits.length > 0) ? true : null,
      firstDoctorName: firstProvider?.providerName ?? null, firstDoctorVisitDate: firstVisit?.date ?? null },
      contractRevision: CONTRACT_REVISION, firstVisitState: identityCare.firstState };
  }
  async function responseBody(response, budget, maxResponseBytes) {
    const announced = Number(response.headers.get('content-length'));
    if (announced > maxResponseBytes || announced > budget.remaining) {
      await response.body?.cancel().catch(() => {});
      fail(announced > maxResponseBytes ? 'RESPONSE_TOO_LARGE' : 'CAPTURE_TOO_LARGE');
    }
    const account = bytes => {
      budget.remaining -= bytes;
      if (budget.remaining < 0) fail('CAPTURE_TOO_LARGE');
    };
    if (!response.body?.getReader) {
      const text = await response.text(); const size = new TextEncoder().encode(text).length;
      if (size > maxResponseBytes) fail('RESPONSE_TOO_LARGE'); account(size); return text;
    }
    const reader = response.body.getReader(); const decoder = new TextDecoder(); let size = 0; const pieces = [];
    try {
      while (true) {
        const chunk = await reader.read(); if (chunk.done) break;
        size += chunk.value.byteLength;
        if (size > maxResponseBytes) fail('RESPONSE_TOO_LARGE');
        account(chunk.value.byteLength); pieces.push(decoder.decode(chunk.value, { stream: true }));
      }
      pieces.push(decoder.decode()); return pieces.join('');
    } catch (error) { await reader.cancel().catch(() => {}); throw error; }
    finally { reader.releaseLock(); }
  }
  function requestPhases(entry) {
    const span = (from, to) => Number.isFinite(from) && Number.isFinite(to) && from >= 0 && to >= from ? to - from : null;
    return { queueMs: entry.requestStart > 0 ? span(entry.startTime, entry.requestStart) : null,
      connectMs: entry.connectStart > 0 ? span(entry.connectStart, entry.connectEnd) : null,
      waitMs: entry.requestStart > 0 && entry.responseStart > 0 ? span(entry.requestStart, entry.responseStart) : null,
      downloadMs: entry.responseStart > 0 ? span(entry.responseStart, entry.responseEnd) : null,
      durationMs: entry.duration, transferBytes: entry.transferSize, protocol: entry.nextHopProtocol, initiator: entry.initiatorType,
      serverTiming: Array.isArray(entry.serverTiming) ? entry.serverTiming.slice(0, 8).map(item => ({ name: item.name, durationMs: item.duration })) : undefined };
  }
  // Resource Timing has no request ID or extension-world identity. Match only a
  // unique fetch candidate inside this read's measured lifetime; never resolve
  // overlapping same-URL reads by picking the first entry. Even a unique match is
  // correlation, not proof that the entry came from this content script.
  async function collectBrowserTimings(perf, starts, caseId) {
    const unavailable = () => ({ resourceTiming: 'unavailable', own: {}, statuses: {}, page: [] });
    try {
      if (!perf || typeof perf.getEntriesByType !== 'function') return unavailable();
      await new Promise(resolve => setTimeout(resolve, 0));
      const entries = perf.getEntriesByType('resource');
      if (!Array.isArray(entries)) return unavailable();
      const reads = [];
      for (const entry of entries.slice(-1000)) {
        try {
          const url = new URL(entry.name);
          if (url.origin === ORIGIN && ['fetch','xmlhttprequest'].includes(entry.initiatorType)) reads.push({ entry, url });
        } catch { /* malformed optional telemetry */ }
      }
      const own = {}, statuses = {};
      for (const [key, { path, startedAt, finishedAt }] of Object.entries(starts)) {
        const href = new URL(`${ORIGIN}${path}`).href;
        const matches = reads.filter(read => read.url.href === href && read.entry.initiatorType === 'fetch' &&
          Number.isFinite(read.entry.startTime) && read.entry.startTime >= startedAt - 2 &&
          read.entry.startTime <= finishedAt && Number.isFinite(read.entry.responseEnd) &&
          read.entry.responseEnd >= read.entry.startTime && read.entry.responseEnd <= finishedAt + 2);
        statuses[key] = matches.length > 1 ? 'ambiguous' : matches.length ? 'recorded' : 'not_found';
        if (matches.length === 1) own[key] = { ...requestPhases(matches[0].entry), match: 'url_time_candidate' };
      }
      const projectionStart = starts.caseProjection?.startedAt;
      const page = projectionStart == null ? [] : reads
        .filter(read => read.url.pathname === '/crm-api/query/case' && read.url.searchParams.get('caseId') === caseId && read.entry.startTime < projectionStart - 2)
        .sort((a, b) => a.entry.startTime - b.entry.startTime).slice(-3)
        .map(read => ({ ...requestPhases(read.entry), leadMs: projectionStart - read.entry.startTime, overlapsOwn: read.entry.responseEnd > projectionStart }));
      return { resourceTiming: Object.keys(own).length ? 'recorded' : 'own_entries_not_found', own, statuses, page };
    } catch {
      // Telemetry must never turn valid structured case data into a failed read.
      return unavailable();
    }
  }
  async function run({ href, getHref, fetchFn, now = () => performance.now(), performanceApi = globalThis.performance, timeoutMs = 15000, captureAll = false, collectCaseSources = false, scopedCaseInputs = false, canonicalCare = false,
    maxResponseBytes = 8 * 1024 * 1024, maxCaptureBytes = 12 * 1024 * 1024 }) {
    const started = now(); let status = null; let responseBytes = null; const requestStarts = {};
    let controller; let timer; let watcher; let caseChanged = false;
    try {
      const budget = { remaining: maxCaptureBytes };
      const binding = identity(href);
      const assertCurrent = () => { if (caseChanged || getHref() !== binding.href) fail('CASE_CHANGED'); };
      assertCurrent();
      controller = new AbortController();
      timer = setTimeout(() => controller.abort('timeout'), timeoutMs);
      // Sticky detection also catches A -> B -> A while the request is pending.
      watcher = setInterval(() => { if (getHref() !== binding.href) { caseChanged = true; controller.abort('case_changed'); } }, 20);
      const extraSources = [
          ['caseBasics', `/admin-api/search/case/${binding.caseId}`],
          ['caseIdentity', `/admin-api/inbox/${binding.caseId}`],
          ['caseTimeline', `/admin-api/query/case-timeline?caseId=${binding.caseId}`],
          ...(!scopedCaseInputs ? [['domains', '/admin-api/query/domains']] : [])
        ];
      const readExtraSources = () => Promise.all(extraSources.map(async ([key, path]) => {
          const sourceStarted = now(); requestStarts[key] = { path, startedAt: sourceStarted };
          try {
            assertCurrent();
            const result = await fetchFn(`${ORIGIN}${path}`, {
              method: 'GET', credentials: 'same-origin', redirect: 'error', cache: 'no-store',
              headers: { Accept: 'application/json' }, signal: controller.signal
            });
            const headersMs = Math.round(now() - sourceStarted);
            assertCurrent();
            if (result.status === 401 || result.status === 403) throw new ProbeError('AUTH_OR_PERMISSION', null, result.status);
            if (!result.ok) throw new ProbeError('HTTP', null, result.status);
            if (result.redirected) fail('LOGIN_OR_REDIRECT');
            if (new URL(result.url).href !== `${ORIGIN}${path}`) fail('UNEXPECTED_RESPONSE_URL');
            if (!/^application\/(?:json|[\w.+-]+\+json)(?:\s*;|$)/i.test(result.headers.get('content-type') || '')) fail('NON_JSON_OR_LOGIN');
            const bodyStarted = now();
            const text = await responseBody(result, budget, maxResponseBytes);
            const bodyMs = Math.round(now() - bodyStarted), processStarted = now();
            assertCurrent();
            if (controller.signal.aborted) fail(controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT');
            let value; try { value = JSON.parse(text); } catch { fail('MALFORMED_JSON'); }
            if (!value || typeof value !== 'object') fail('SCHEMA', '$');
            if (scopedCaseInputs && ['caseBasics', 'caseIdentity'].includes(key)) {
              if (value.case_id == null) fail('SCHEMA', '$.case_id');
              if (String(value.case_id) !== binding.caseId) fail('RESPONSE_CASE_MISMATCH', '$.case_id');
            }
            return [key, { ok: true, endpoint: path, ...(scopedCaseInputs ? caseInputs(key, value) : { raw: value, responseText: text }),
              responseBytes: new TextEncoder().encode(text).length, headersMs, bodyMs, processMs: Math.round(now() - processStarted), elapsedMs: Math.round(now() - sourceStarted) }];
          } catch (error) {
            return [key, { ok: false, endpoint: path, code: controller.signal.aborted ? controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT' : error instanceof ProbeError ? error.code : 'NETWORK_OR_BLOCKED_REDIRECT',
              status: error instanceof ProbeError ? error.status : null, elapsedMs: Math.round(now() - sourceStarted) }];
          } finally { requestStarts[key].finishedAt = now(); }
        }));
      const parallelSources = captureAll && collectCaseSources && scopedCaseInputs ? readExtraSources() : null;
      const requestStarted = now();
      requestStarts.caseProjection = { path: `/crm-api/query/case?caseId=${encodeURIComponent(binding.caseId)}`, startedAt: requestStarted };
      const response = await fetchFn(`${ORIGIN}/crm-api/query/case?caseId=${encodeURIComponent(binding.caseId)}`, {
        method: 'GET', credentials: 'same-origin', redirect: 'error', cache: 'no-store',
        headers: { Accept: 'application/json' }, signal: controller.signal
      });
      const headersMs = Math.round(now() - requestStarted);
      status = response.status;
      assertCurrent();
      if (controller.signal.aborted) fail(controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT');
      if (status === 401 || status === 403) throw new ProbeError('AUTH_OR_PERMISSION', null, status);
      if (!response.ok) throw new ProbeError('HTTP', null, status);
      if (response.redirected) fail('LOGIN_OR_REDIRECT');
      const finalUrl = new URL(response.url);
      if (finalUrl.origin !== ORIGIN || finalUrl.pathname !== '/crm-api/query/case' || finalUrl.searchParams.get('caseId') !== binding.caseId) fail('UNEXPECTED_RESPONSE_URL');
      if (!/^application\/(?:json|[\w.+-]+\+json)(?:\s*;|$)/i.test(response.headers.get('content-type') || '')) fail('NON_JSON_OR_LOGIN');
      const bodyStarted = now();
      const body = await responseBody(response, budget, maxResponseBytes);
      const bodyMs = Math.round(now() - bodyStarted), processStarted = now();
      responseBytes = new TextEncoder().encode(body).length;
      assertCurrent();
      if (controller.signal.aborted) fail(controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT');
      let raw;
      try { raw = JSON.parse(body); } catch { fail('MALFORMED_JSON'); }
      object(raw, '$');
      let care = null; let mappingError = null;
      if (captureAll) {
        try { care = projectCare(raw); }
        catch (error) {
          if (!(error instanceof ProbeError)) throw error;
          mappingError = { code: error.code, path: error.path };
        }
      } else care = projectCare(raw);
      let canonical = null; let canonicalError = null;
      if (canonicalCare) {
        try { canonical = projectCanonicalCare(raw); }
        catch (error) {
          if (!captureAll || !(error instanceof ProbeError)) throw error;
          canonicalError = { code: error.code, path: error.path };
        }
      }
      assertCurrent();
      const bundle = captureAll ? snapshot(raw, body, binding, care, mappingError) : null;
      requestStarts.caseProjection.finishedAt = now();
      if (bundle && canonicalCare) Object.assign(bundle.mapping, { canonicalCare: canonical, canonicalCareError: canonicalError });
      if (bundle && collectCaseSources) {
        bundle.schema = 'crm_case_snapshot_v2'; bundle.version = 2;
        bundle.sources = { caseProjection: { ok: true, endpoint: '/crm-api/query/case', raw, responseText: body, responseBytes, headersMs, bodyMs, processMs: Math.round(now() - processStarted), elapsedMs: Math.round(now() - started) } };
        // These read endpoints are defined in Sweden.Admin.Api, not inferred
        // from rendered DOM or guessed by probing possible API routes.
        Object.assign(bundle.sources, Object.fromEntries(await (parallelSources || readExtraSources())));
        assertCurrent();
        if (controller.signal.aborted && controller.signal.reason === 'case_changed') fail('CASE_CHANGED');
        if (scopedCaseInputs && Object.values(bundle.sources).every(source => source.ok)) {
          const references = workLookupReferences(bundle.sources.caseTimeline.raw);
          if (Object.values(references).some(ids => ids.length)) {
            const embedded = embeddedCaseLookups(raw, bundle.sources.caseTimeline.raw, references);
            if (embedded) {
              bundle.caseLookups = {schema:'crm_case_lookups_v1',caseId:binding.caseId,endpoint:'case_inputs',ok:true,resolution:'case_embedded',metadataState:embedded.injuries.length ? 'anatomy_unavailable' : 'available',raw:embedded,responseBytes:0,elapsedMs:0};
            } else {
            const path = '/admin-api/query/domains', lookupStarted = now(); requestStarts.caseLookups = { path, startedAt: lookupStarted };
            const envelope = { schema: 'crm_case_lookups_v1', caseId: binding.caseId, endpoint: path };
            try {
              assertCurrent();
              const result = await fetchFn(`${ORIGIN}${path}`, { method: 'GET', credentials: 'same-origin', redirect: 'error', cache: 'no-store', headers: { Accept: 'application/json' }, signal: controller.signal });
              const headersMs = Math.round(now() - lookupStarted);
              assertCurrent();
              if (result.status === 401 || result.status === 403) throw new ProbeError('AUTH_OR_PERMISSION', null, result.status);
              if (!result.ok) throw new ProbeError('HTTP', null, result.status);
              if (result.redirected) fail('LOGIN_OR_REDIRECT');
              if (new URL(result.url).href !== `${ORIGIN}${path}`) fail('UNEXPECTED_RESPONSE_URL');
              if (!/^application\/(?:json|[\w.+-]+\+json)(?:\s*;|$)/i.test(result.headers.get('content-type') || '')) fail('NON_JSON_OR_LOGIN');
              const bodyStarted = now();
              const text = await responseBody(result, budget, maxResponseBytes);
              const bodyMs = Math.round(now() - bodyStarted), processStarted = now();
              assertCurrent();
              if (controller.signal.aborted) fail(controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT');
              let value; try { value = JSON.parse(text); } catch { fail('MALFORMED_JSON'); }
              bundle.caseLookups = { ...envelope, ok: true, raw: selectWorkLookupNames(value, references, true), responseBytes: new TextEncoder().encode(text).length, headersMs, bodyMs, processMs: Math.round(now() - processStarted), elapsedMs: Math.round(now() - lookupStarted) };
            } catch (error) {
              bundle.caseLookups = { ...envelope, ok: false, elapsedMs: Math.round(now() - lookupStarted), code: controller.signal.aborted ? controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT' : error instanceof ProbeError ? error.code : 'NETWORK_OR_BLOCKED_REDIRECT' };
            }
            requestStarts.caseLookups.finishedAt = now();
            assertCurrent();
            if (caseChanged) fail('CASE_CHANGED');
            }
          }
        }
        bundle.coverage = { complete: Object.values(bundle.sources).every(s => s.ok),
          requested: Object.keys(bundle.sources), captured: Object.keys(bundle.sources).filter(k => bundle.sources[k].ok) };
      }
      if (bundle && scopedCaseInputs) {
        bundle.schema = 'crm_case_inputs_v3'; bundle.version = 3;
        bundle.scope = 'case_state_inputs'; bundle.normalized = false;
        const selected = caseInputs('caseProjection', raw);
        bundle.raw = selected.raw;
        delete bundle.responseText;
        if (bundle.sources) {
          Object.assign(bundle.sources.caseProjection, selected);
          delete bundle.sources.caseProjection.responseText;
          bundle.coverage.selectionVerified = Object.values(bundle.sources).every(s => s.ok && !s.selection.issues.length);
          bundle.coverage.canonicalComplete = false;
          const references = bundle.sources.caseTimeline.ok ? workLookupReferences(bundle.sources.caseTimeline.raw) : null;
          bundle.coverage.lookupNamesComplete = !!references && Object.entries(references).every(([key, ids]) => !ids.length || (bundle.caseLookups?.ok === true && ids.every(id => bundle.caseLookups.raw[key].some(entry => entry.id === id && entry.name.trim()))));
          const identityData = bundle.sources.caseIdentity?.raw;
          const hasPerson = person => person && typeof person.name === 'string' && !!person.name.trim() &&
            typeof person.personal_number === 'string' && !!person.personal_number.trim();
          bundle.coverage.requiredInputsPresent = !!(hasPerson(identityData?.customer) && hasPerson(identityData?.case_refers_to_person) &&
            Object.hasOwn(selected.raw, 'dateOfIncident') && Object.hasOwn(selected.raw, 'incidentDescription'));
          bundle.coverage.transportOnly = true;
        }
        bundle.categories = bundle.categories.filter(c => Object.hasOwn(selected.raw, c.key));
        // This is a source-selection audit. It must never certify a finished
        // canonical adapter merely because all four HTTP requests succeeded.
        bundle.mapping.status = 'current_state_reconstruction_pending';
      }
      assertCurrent();
      if (bundle && scopedCaseInputs) {
        const collectMs = Math.round(now() - started);
        const timings = await collectBrowserTimings(performanceApi, requestStarts, binding.caseId);
        assertCurrent();
        const sources = { ...bundle.sources, ...(bundle.caseLookups ? { caseLookups: bundle.caseLookups } : {}) };
        bundle.transportDiagnostics = transportDiagnostics({ schema: 'crm_transport_diagnostics_v1', collectMs, resourceTiming: timings.resourceTiming, crmPageReads: timings.page,
          sources: Object.fromEntries(Object.entries(sources).map(([key, source]) => [key, { ...source, browser: timings.own[key], browserTimingStatus: timings.statuses[key] }])) });
      }
      return { ok: true, care, ...(canonicalCare ? { canonical } : {}), ...(bundle ? { bundle } : {}), report: {
        schema: 'crm_care_probe_v1', status, elapsedMs: Math.round(now() - started), responseBytes,
        providers: care?.providers.length ?? null, visits: care ? care.providers.reduce((n, p) => n + p.visits.length, 0) : null,
        manualProviders: care ? care.providers.filter(p => p.kind === 'ManuallyAdded').length : null,
        firstVisitState: care?.firstState ?? null,
        ...(canonicalCare ? { canonicalCareMapping: canonicalError || (canonical ? 'mapped' : 'unavailable') } : {}),
        ...(captureAll ? { capture: scopedCaseInputs ? 'selected_case_inputs' : 'complete_case_response', categories: bundle.categories.length, careMapping: mappingError || 'identity_checked' } : {}),
        ...(bundle?.sources ? { sourceCoverage: Object.fromEntries(Object.entries(bundle.sources).map(([key, value]) => [key, {
          ok: value.ok, responseBytes: value.responseBytes ?? null, elapsedMs: value.elapsedMs ?? null, code: value.code ?? null, status: value.status ?? null,
          ...(value.selection ? { discarded: value.selection.discarded, contractGaps: value.selection.issues.length } : {})
        }])) } : {}),
        ...(bundle?.caseLookups ? { lookupCoverage: { ok: bundle.caseLookups.ok, code: bundle.caseLookups.code ?? null, responseBytes: bundle.caseLookups.responseBytes ?? null, elapsedMs: bundle.caseLookups.elapsedMs ?? null, schools: bundle.caseLookups.raw?.schools.length ?? 0, employmentOffices: bundle.caseLookups.raw?.employmentOffices.length ?? 0, namesComplete: bundle.coverage.lookupNamesComplete } } : {}),
        scope: scopedCaseInputs ? 'selected structured case inputs; full current-state replay and canonical mapping pending' : captureAll ? 'complete case response preserved; full canonical mapping pending' : canonicalCare ? 'structured care mapped; remaining case categories outside this read' : 'identity-and-first-visit-only; dates/departments/confirmation not yet validated'
      } };
    } catch (error) {
      const aborted = controller?.signal.aborted;
      const code = caseChanged || (error instanceof ProbeError && error.code === 'CASE_CHANGED') ? 'CASE_CHANGED' : aborted ? controller.signal.reason === 'case_changed' ? 'CASE_CHANGED' : 'TIMEOUT' : error instanceof ProbeError ? error.code : 'NETWORK_OR_BLOCKED_REDIRECT';
      return { ok: false, report: { schema: 'crm_care_probe_v1', code, path: error instanceof ProbeError ? error.path : null, status, elapsedMs: Math.round(now() - started), responseBytes } };
    } finally { controller?.abort(); clearTimeout(timer); clearInterval(watcher); }
  }
  const sourceReviewContract = Object.freeze({ activityEvents: Object.freeze([...REVIEWED_ACTIVITY_EVENTS].sort()), projectionRules: Object.freeze(CURRENT_PROJECTION_RULES) });
  const api = { sourceReviewContract, reviewCaseSources, embeddedCaseLookups, embeddedProviderLookups, transportDiagnostics, workLookupReferences, selectWorkLookupNames, caseLookupHandoff, identity, projectCare, projectCanonicalCare, snapshot, caseInputs, caseHandoff, CASE_INPUT_SCHEMA, run };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.__crmCaseProbe = api;
})(globalThis);
