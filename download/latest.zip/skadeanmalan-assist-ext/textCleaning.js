(function (root, factory) {
  const api = factory();

  // Expose in the injected execution context (isolated world) so executeScript() functions can use it.
  root.__crmTextCleaning = api;

  // Export for Node tests / tooling.
  if (typeof module === "object" && module && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const DEFAULT_UI_LINES = new Set([
    "Kopiera till urklipp",
    "Redigera",
    "Begär läkarintyg",
    "Begär journaler",
    "Välj sjukskrivning",
    "Välj filer att posta",
    "eller släpp dem här",
    "Rensa",
    "Lägg till vårdinrättning",
    "Be om fler ärrbilder",
    "Be om fler besökta vårdinrättningar",
    "Be om arbetsgivarintyg/lönespec"
  ]);

  function toUnixNewlines(text) {
    return String(text ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  }

  function normalizeSpaces(text) {
    return String(text ?? "").replace(/\u00a0/g, " ");
  }

  function stripAfterMarkerLine(text, marker) {
    const raw = normalizeSpaces(toUnixNewlines(text));
    const lines = raw.split("\n");
    const normalizedMarker = normalizeSpaces(String(marker ?? "")).trim().toLowerCase();

    const markerIndex = lines.findIndex((line) => {
      const normalizedLine = normalizeSpaces(line).trim();
      if (!normalizedLine) return false;

      if (normalizedMarker === "* * *") {
        return /^\*\s*\*\s*\*$/.test(normalizedLine);
      }

      const lower = normalizedLine.toLowerCase();
      return lower === normalizedMarker || lower.startsWith(`${normalizedMarker} `);
    });

    if (markerIndex !== -1) {
      return lines.slice(0, markerIndex).join("\n");
    }

    // Fallback: handle cases where the marker was flattened into a line.
    if (normalizedMarker === "* * *") {
      const match = raw.match(/\*\s*\*\s*\*/);
      if (match && typeof match.index === "number") {
        return raw.slice(0, match.index);
      }
      return raw;
    }

    const lowerRaw = raw.toLowerCase();
    const idx = lowerRaw.indexOf(normalizedMarker);
    if (idx === -1) return raw;

    const prevNl = lowerRaw.lastIndexOf("\n", idx);
    const cutAt = prevNl === -1 ? idx : prevNl;
    return raw.slice(0, cutAt);
  }

  function stripUiNoise(text) {
    let raw = normalizeSpaces(toUnixNewlines(text));

    // Remove toggle glyph + trailing UI text when inline (e.g. "… ▼ Visa alla kompletteringar").
    raw = raw.replace(/[▼▾]\s*Visa alla\b[^\n]*/gi, "");

    // Remove remaining toggle glyphs even when they end up inline.
    raw = raw.replace(/[▼▾]/g, "");

    return raw;
  }

  function normalizePreserveNewlines(
    text,
    { dropUiLines = true, hadToggleGlyph = false, cardId = null } = {}
  ) {
    const raw = normalizeSpaces(toUnixNewlines(text));
    const lines = raw
      .split("\n")
      .map((line) => line.replace(/[ \t\u00a0]+/g, " ").trim())
      .filter((line) => line.length > 0);

    if (!dropUiLines) return lines.join("\n").trim();

    const hasRequestActions = lines.some(
      (line) => line === "Begär journaler" || line === "Begär läkarintyg"
    );

    return lines
      .filter((line) => !DEFAULT_UI_LINES.has(line))
      // Treat "Försättsblad" as UI only when it appears together with known request actions.
      .filter((line) => !(line === "Försättsblad" && hasRequestActions))
      // Only drop “Visa alla …” lines when the card also contains a toggle glyph (typical UI pattern).
      .filter((line) => !(hadToggleGlyph && /^Visa alla\b/i.test(line)))
      // "Visa allt" is a UI toggle/link (seen in visited-healthcare-providers-card).
      .filter((line) => !/^Visa allt$/i.test(line))
      // Card-scoped: drop "Be om …" action buttons in known action-only cards.
      .filter((line) => {
        const id = String(cardId ?? "");
        if (id !== "scar-pictures-card" && id !== "employment-confirmation-card") return true;
        return !/^Be om\b/i.test(line);
      })
      .join("\n")
      .trim();
  }

  function cleanCollectorText(rawText, { stopMarkers = [], stripUi = true, cardId = null } = {}) {
    let text = normalizeSpaces(toUnixNewlines(rawText));

    for (const marker of Array.isArray(stopMarkers) ? stopMarkers : []) {
      text = stripAfterMarkerLine(text, marker);
    }

    const hadToggleGlyph = /[▼▾]/.test(text);

    if (stripUi) {
      text = stripUiNoise(text);
    }

    return normalizePreserveNewlines(text, {
      dropUiLines: Boolean(stripUi),
      hadToggleGlyph: Boolean(stripUi) && hadToggleGlyph,
      cardId
    });
  }

  return {
    cleanCollectorText,
    normalizePreserveNewlines,
    stripAfterMarkerLine,
    stripUiNoise
  };
});
